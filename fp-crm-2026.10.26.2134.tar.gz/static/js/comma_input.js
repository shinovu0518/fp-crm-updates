function formatComma(val) {
  const n = String(val).replace(/[^\d]/g, '');
  return n ? parseInt(n, 10).toLocaleString('ja-JP') : '';
}
function stripComma(val) {
  return String(val).replace(/,/g, '');
}
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.comma-input').forEach(function(el) {
    if (el.value) el.value = formatComma(el.value);
    el.addEventListener('input', function() {
      const pos = this.selectionStart;
      const raw = stripComma(this.value);
      if (raw === '' || isNaN(raw)) { this.value = raw === '' ? '' : this.value; return; }
      const formatted = parseInt(raw, 10).toLocaleString('ja-JP');
      const diff = formatted.length - this.value.length;
      this.value = formatted;
      this.setSelectionRange(pos + diff, pos + diff);
    });
  });
  document.querySelectorAll('form').forEach(function(form) {
    form.addEventListener('submit', function() {
      form.querySelectorAll('.comma-input').forEach(function(el) {
        el.value = stripComma(el.value);
      });
    });
  });
});
