// 全角→半角変換＋カンマ除去
function toHankaku(str) {
  return (str || '').replace(/[０-９]/g, s => String.fromCharCode(s.charCodeAt(0) - 0xFEE0))
                    .replace(/[,，]/g, '');
}

// ANP自動計算
function calcAnp() {
  const premiumRaw = toHankaku(document.getElementById('id_premium').value);
  const premium = parseFloat(premiumRaw) || 0;
  const method = document.getElementById('id_payment_method').value;
  const multiplier = method === 'monthly' ? 12 : method === 'lump' ? 0.1 : 1;
  const anpField = document.getElementById('id_anp');
  anpField.value = premium > 0 ? Math.round(premium * multiplier).toLocaleString('ja-JP') : '';
}

// 証券商品のAC（手数料）自動計算
window.FEE_MODE = 'exclusive'; // 'exclusive'=購入金額に手数料を含まない／'inclusive'=含む

function setFeeMode(mode) {
  window.FEE_MODE = mode;
  document.querySelectorAll('.fee-mode-btn').forEach(function(btn) {
    const active = btn.dataset.feeMode === mode;
    btn.classList.toggle('bg-blue-600', active);
    btn.classList.toggle('text-white', active);
    btn.classList.toggle('bg-white', !active);
    btn.classList.toggle('text-gray-500', !active);
  });
  calcAc();
}

function currentProduct() {
  const productSelect = document.getElementById('id_product');
  if (!productSelect || !productSelect.value) return null;
  const allProducts = window.DEAL_ALL_PRODUCTS || [];
  return allProducts.find(function(p) { return String(p.id) === String(productSelect.value); }) || null;
}

function calcAc() {
  const feeContainer = document.getElementById('fee_calc_options');
  const product = currentProduct();
  if (!product || product.purchase_fee === null || product.purchase_fee === undefined) {
    if (feeContainer) feeContainer.classList.add('hidden');
    return;
  }
  if (feeContainer) feeContainer.classList.remove('hidden');

  const premiumRaw = toHankaku(document.getElementById('id_premium').value);
  const premium = parseFloat(premiumRaw) || 0;
  const feeRate = parseFloat(product.purchase_fee) / 100;
  const ac = window.FEE_MODE === 'inclusive'
    ? premium * feeRate / (1 + feeRate)
    : premium * feeRate;
  const acField = document.getElementById('id_ac');
  acField.value = premium > 0 ? Math.round(ac).toLocaleString('ja-JP') : '';
}

// 数値フィールド: blur時にカンマ整形
function initNumericFields(ids) {
  ids.forEach(function(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('blur', function() {
      var raw = parseFloat(toHankaku(el.value));
      if (!isNaN(raw)) el.value = raw.toLocaleString('ja-JP');
    });
  });
}

// フォーム送信前にカンマ・全角を除去
function initFormSubmit(numericIds) {
  var form = document.querySelector('form');
  if (!form) return;
  form.addEventListener('submit', function() {
    numericIds.forEach(function(id) {
      var el = document.getElementById(id);
      if (el) el.value = toHankaku(el.value).replace(/,/g, '');
    });
  });
}

// 保険会社 → 商品ドロップダウン連動（JSONデータから毎回再構築）
function initProductDropdown() {
  var companySelect = document.getElementById('id_company');
  var productSelect = document.getElementById('id_product');
  if (!companySelect || !productSelect) return;

  var allProducts = window.DEAL_ALL_PRODUCTS || [];

  function filterProducts() {
    var companyId = companySelect.value ? String(companySelect.value) : null;
    var currentVal = productSelect.value;

    // selectを空にして空白optionだけ残す
    productSelect.innerHTML = '<option value="">--- 選択してください ---</option>';

    // 会社が一致する商品だけ追加
    allProducts.forEach(function(p) {
      if (!companyId || String(p.company_id) === companyId) {
        var opt = document.createElement('option');
        opt.value = p.id;
        opt.textContent = p.name;
        if (String(p.id) === String(currentVal)) opt.selected = true;
        productSelect.appendChild(opt);
      }
    });
  }

  companySelect.addEventListener('change', filterProducts);
  filterProducts();
}

// 契約者 → 被保険者ドロップダウン連動（本人＋登録済みの家族のみ選択可）
function initInsuredDropdown() {
  var customerSelect = document.getElementById('id_customer');
  var insuredSelect = document.getElementById('id_insured');
  if (!customerSelect || !insuredSelect) return;

  var insuredOptions = window.DEAL_INSURED_OPTIONS || {};

  function filterInsured() {
    var customerId = customerSelect.value;
    var currentVal = insuredSelect.value || window.DEAL_CURRENT_INSURED || '';

    insuredSelect.innerHTML = '<option value="">契約者と同一</option>';

    var options = insuredOptions[customerId] || [];
    options.forEach(function(o) {
      if (String(o.id) === String(customerId)) return; // 契約者本人は「契約者と同一」で表現
      var opt = document.createElement('option');
      opt.value = o.id;
      opt.textContent = o.name + '（' + o.relation + '）';
      if (String(o.id) === String(currentVal)) opt.selected = true;
      insuredSelect.appendChild(opt);
    });
  }

  customerSelect.addEventListener('change', filterInsured);
  filterInsured();
}

// メイン初期化
(function() {
  var numericIds = ['id_premium', 'id_anp', 'id_ac'];

  initProductDropdown();
  initInsuredDropdown();

  var premEl = document.getElementById('id_premium');
  var methodEl = document.getElementById('id_payment_method');
  var productEl = document.getElementById('id_product');
  if (premEl) premEl.addEventListener('input', calcAnp);
  if (methodEl) methodEl.addEventListener('change', calcAnp);

  if (premEl) premEl.addEventListener('input', calcAc);
  if (productEl) productEl.addEventListener('change', calcAc);
  document.querySelectorAll('.fee-mode-btn').forEach(function(btn) {
    btn.addEventListener('click', function() { setFeeMode(btn.dataset.feeMode); });
  });
  setFeeMode(window.FEE_MODE);

  initNumericFields(numericIds);
  initFormSubmit(numericIds);
})();
