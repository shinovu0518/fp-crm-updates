"""Mac用アプリの更新（「更新があります」表示と更新ボタン）。

案内ファイル（manifest.json、置き場所は FPCRM_UPDATE_URL）の形：
  {"version": "2026.10.27.0930",          ← 版。数字を . で区切ったもの。大きいほど新しい
   "url": "https://.../fp-crm-2026.10.27.0930.tar.gz",
   "sha256": "…",                          ← 更新ファイルの照合値。一致しなければ入れない
   "requires_launcher": 1,                  ← これより起動役が古ければ、アプリの入れ直しを案内する
   "notes": "顧客一覧の検索を速くしました"}
更新ファイルの中身はCRMのプログラム部分だけ（scripts/make_update.py で作る）。
"""
import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile
import threading
import time
import urllib.request
from pathlib import Path

from django.conf import settings

CHECK_INTERVAL = 6 * 3600
_cache = {'at': 0.0, 'manifest': None, 'error': None}
_lock = threading.Lock()


def enabled():
    return bool(settings.SERVE_FILES and os.environ.get('FPCRM_UPDATE_URL'))


def current_version():
    return os.environ.get('FPCRM_CODE_VERSION', 'unknown')


def _key(version):
    try:
        return tuple(int(x) for x in str(version).split('.'))
    except ValueError:
        return ()


def _fetch(url, timeout=10):
    req = urllib.request.Request(url, headers={'User-Agent': 'FP-CRM-updater'})
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return res.read()


def fetch_manifest():
    return json.loads(_fetch(os.environ['FPCRM_UPDATE_URL']).decode('utf-8'))


def _refresh():
    try:
        manifest, error = fetch_manifest(), None
    except Exception as e:  # ネットが無い・置き場が無い時は黙って次回また見る
        manifest, error = None, f'{type(e).__name__}'
    with _lock:
        _cache.update(at=time.time(), manifest=manifest, error=error)


def failed_before(version):
    """一度入れて起動できなかった版（起動役が前の版に戻した）は、もう案内しない"""
    d = Path(settings.DATA_DIR) / 'versions' / str(version)
    return (d / '.tried').exists() and not (d / '.ok').exists()


def available_update(wait=False):
    """新しい版があれば案内ファイルの中身を返す。確認は6時間に1回、裏で行う（画面を待たせない）"""
    if not enabled():
        return None
    stale = time.time() - _cache['at'] > CHECK_INTERVAL
    if stale:
        if wait:
            _refresh()
        else:
            _cache['at'] = time.time()  # 同時に何度も見に行かない
            threading.Thread(target=_refresh, daemon=True).start()
    m = _cache['manifest']
    if not m or _key(m.get('version')) <= _key(current_version()) or failed_before(m.get('version')):
        return None
    m = dict(m)
    m['needs_new_app'] = int(m.get('requires_launcher', 1)) > int(os.environ.get('FPCRM_LAUNCHER_API', '1'))
    return m


class UpdateError(Exception):
    pass


def install(manifest):
    """更新版をダウンロードして照合し、versions/<版>/ に置いて「今の版」にする"""
    from config.backup import run_backup
    version = manifest['version']
    if not _key(version):
        raise UpdateError('版の書き方が正しくありません')
    run_backup(force=True)
    data = _fetch(manifest['url'], timeout=120)
    if hashlib.sha256(data).hexdigest() != manifest.get('sha256'):
        raise UpdateError('ダウンロードした更新ファイルが壊れています（照合値が一致しません）')
    versions = Path(settings.DATA_DIR) / 'versions'
    versions.mkdir(parents=True, exist_ok=True)
    dest = versions / version
    tmp = versions / f'{version}.tmp'
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as tar:
        for m in tar.getmembers():  # 置き場の外に書き出すファイルは受け付けない
            if m.name.startswith('/') or '..' in Path(m.name).parts or not (m.isfile() or m.isdir()):
                raise UpdateError('更新ファイルの中身が正しくありません')
        tar.extractall(tmp)
    if not (tmp / 'manage.py').exists():
        raise UpdateError('更新ファイルにCRMが入っていません')
    shutil.rmtree(dest, ignore_errors=True)
    tmp.rename(dest)
    current = versions / 'current'
    if current.exists():
        (versions / 'previous').write_text(current.read_text())
    current.write_text(version)
    _prune(versions, keep={version, (versions / 'previous').read_text().strip() if (versions / 'previous').exists() else ''})
    return dest


def _prune(versions, keep):
    for p in versions.iterdir():
        if p.is_dir() and p.name not in keep:
            shutil.rmtree(p, ignore_errors=True)


def restart_app():
    """少し待ってアプリを開き直し、今のCRMは止まる（画面を返してから）"""
    bundle = os.environ.get('FPCRM_APP_BUNDLE')
    if bundle:
        subprocess.Popen(['/bin/sh', '-c', 'sleep 2; /usr/bin/open "$0"', bundle], start_new_session=True)
    threading.Timer(1.0, lambda: os._exit(0)).start()
