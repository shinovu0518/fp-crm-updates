"""初回の設定（最初のログインを作る）と、Mac用アプリの終了。"""
import os
import threading

from django import forms
from django.conf import settings
from django.contrib.auth import get_user_model, login
from django.contrib.auth.password_validation import validate_password
from django.http import Http404, HttpResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST


def needs_setup():
    return not get_user_model().objects.exists()


class SetupForm(forms.Form):
    username = forms.CharField(label='ユーザー名', max_length=150,
                               help_text='ログインの時に入れる名前（半角英数字がおすすめ）')
    password1 = forms.CharField(label='パスワード', widget=forms.PasswordInput)
    password2 = forms.CharField(label='パスワード（確認）', widget=forms.PasswordInput)

    def clean(self):
        data = super().clean()
        p1, p2 = data.get('password1'), data.get('password2')
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError('2つのパスワードが違います')
        if p1:
            try:
                validate_password(p1)
            except forms.ValidationError as e:
                self.add_error('password1', e)
        return data


def first_run_setup(request):
    """ログインが1つも無い時だけ開ける。作ったらそのままログインしてダッシュボードへ"""
    if not needs_setup():
        return redirect('login')
    form = SetupForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = get_user_model().objects.create_superuser(
            username=form.cleaned_data['username'], email='',
            password=form.cleaned_data['password1'])
        login(request, user)
        return redirect('/')
    return render(request, 'registration/setup.html', {'form': form})


@require_POST
def app_quit(request):
    """Mac用アプリの「終了」。画面を返してから少し待って止まる（アプリとして動いている時だけ）"""
    if not settings.SERVE_FILES:
        raise Http404
    threading.Timer(1.0, lambda: os._exit(0)).start()
    return HttpResponse(
        '<!doctype html><meta charset="utf-8"><title>FP CRM</title>'
        '<body style="font-family:sans-serif;padding:40px;color:#333">'
        '<h1 style="font-size:20px">FP CRMを終了しました</h1>'
        '<p>このタブは閉じて大丈夫です。もう一度使う時は、アプリのアイコンをダブルクリックしてください。</p>')


UPDATING_PAGE = '''<!doctype html><meta charset="utf-8"><title>FP CRM</title>
<body style="font-family:sans-serif;padding:40px;color:#333">
<h1 style="font-size:20px">更新しました。FP CRMを開き直しています…</h1>
<p>数秒で元の画面に戻ります。戻らない時は、アプリのアイコンをダブルクリックしてください。</p>
<script>
setTimeout(function wait(){
  fetch("/accounts/login/", {cache: "no-store"}).then(function(r){
    if (r.ok) { location.href = "/"; } else { setTimeout(wait, 1000); }
  }).catch(function(){ setTimeout(wait, 1000); });
}, 3000);
</script>'''


@require_POST
def app_update(request):
    """「更新する」ボタン：バックアップ → ダウンロードと照合 → 置く → 開き直す"""
    from django.contrib import messages
    from config import updates
    if not updates.enabled():
        raise Http404
    back = request.POST.get('next', '')
    if not back.startswith('/') or back.startswith('//'):
        back = '/'
    manifest = updates.available_update(wait=True)
    if not manifest or manifest['needs_new_app']:
        return redirect(back)
    try:
        updates.install(manifest)
    except Exception as e:
        messages.error(request, f'更新できませんでした：{e}（今の版のまま使えます）')
        return redirect(back)
    updates.restart_app()
    return HttpResponse(UPDATING_PAGE)
