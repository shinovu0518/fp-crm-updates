from django.conf import settings


def personal_features(request):
    """テンプレートで個人用機能のメニュー・カードを出し分けるためのフラグ"""
    return {"personal_features": settings.PERSONAL_FEATURES, "calendar_enabled": settings.CALENDAR_ENABLED}


def app_update(request):
    """Mac用アプリの「更新があります」表示（ログインしている時だけ、裏で6時間に1回確認）"""
    from config import updates
    if not updates.enabled() or not getattr(request, 'user', None) or not request.user.is_authenticated:
        return {}
    return {'app_update': updates.available_update(), 'app_version': updates.current_version()}
