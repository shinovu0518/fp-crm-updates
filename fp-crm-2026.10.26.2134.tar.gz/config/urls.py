from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static

from config import setup

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/", include("django.contrib.auth.urls")),
    path("setup/", setup.first_run_setup, name="first_run_setup"),
    path("app/quit/", setup.app_quit, name="app_quit"),
    path("app/update/", setup.app_update, name="app_update"),
    path("", include("apps.dashboard.urls")),
    path("customers/", include("apps.customers.urls")),
    path("interviews/", include("apps.interviews.urls")),
    path("tasks/", include("apps.tasks.urls")),
    path("deals/", include("apps.deals.urls")),
    path("settings/", include("apps.settings_app.urls")),
    path("calendar/", include("apps.calendar_sync.urls")),
    path("", include("apps.line_bot.urls")),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.SERVE_FILES:
    from django.contrib.staticfiles.views import serve as serve_static
    from django.views.static import serve as serve_media

    urlpatterns += [
        re_path(r"^static/(?P<path>.*)$", serve_static, {"insecure": True}),
        re_path(r"^media/(?P<path>.*)$", serve_media, {"document_root": settings.MEDIA_ROOT}),
    ]
