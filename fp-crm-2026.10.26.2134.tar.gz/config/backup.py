"""データ（DB・添付書類）のバックアップ。Mac用アプリは起動中に1日1回自動で取る。

  DATA_DIR/backups/2026-10-26/db.sqlite3   ← その日のDB（使用中でも壊れない取り方でコピー）
  DATA_DIR/backups/2026-10-26/media/       ← 添付書類
30日分を残し、それより古いものは消す。
"""
import datetime
import shutil
import sqlite3
from pathlib import Path

from django.conf import settings

KEEP_DAYS = 30


def backup_root() -> Path:
    return Path(settings.DATA_DIR) / 'backups'


def run_backup(force=False, today=None):
    """今日の分が無ければ取る。戻り値：取ったフォルダ（取らなかった時は None）"""
    today = today or datetime.date.today()
    dest = backup_root() / today.isoformat()
    if dest.exists() and not force:
        return None
    tmp = dest.with_name(dest.name + '.tmp')
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    src = sqlite3.connect(str(settings.DATABASES['default']['NAME']))
    dst = sqlite3.connect(str(tmp / 'db.sqlite3'))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    media = Path(settings.MEDIA_ROOT)
    if media.exists():
        shutil.copytree(media, tmp / 'media')
    shutil.rmtree(dest, ignore_errors=True)
    tmp.rename(dest)
    prune()
    return dest


def prune(keep=KEEP_DAYS):
    for old in list_backups()[keep:]:
        shutil.rmtree(old, ignore_errors=True)


def list_backups():
    """新しい順。日付の名前のフォルダだけ"""
    root = backup_root()
    if not root.exists():
        return []
    dirs = []
    for p in root.iterdir():
        try:
            datetime.date.fromisoformat(p.name)
        except ValueError:
            continue
        if p.is_dir():
            dirs.append(p)
    return sorted(dirs, key=lambda p: p.name, reverse=True)
