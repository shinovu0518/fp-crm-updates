# FP CRM

FP・保険募集人向けの顧客管理アプリ（顧客カルテ・面談記録・意向把握/比較推奨の記録・タスク・案件/AC管理・フォロー漏れの検知）。
各自のPCの中で動き、顧客データは外に預けません。

## 動かし方（開発用）

```bash
cp .env.example .env              # DJANGO_SECRET_KEY を書き換える
python3 -m pip install -r requirements.txt
python3 manage.py migrate
python3 manage.py loaddata companies products   # 保険会社・商品のマスタ
python3 manage.py createsuperuser
python3 manage.py runserver 8000
```

試用メンバー向けの導入手順・アプリの形は別途用意する。

## 顧客データの取り込み・書き出し

設定 → データの取り込み・書き出し から、手元の顧客一覧（Excel・CSV）を取り込み、全データをExcelで書き出せる。
