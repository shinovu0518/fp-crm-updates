#!/bin/bash
# db.sqlite3 の日次バックアップ（sqlite3 .backup で整合性を保ってコピー、30世代保持）
set -euo pipefail

DB="$HOME/fp-crm-system/db.sqlite3"
BACKUP_DIR="$HOME/fp-crm-backups"
STAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"
/usr/bin/sqlite3 "$DB" ".backup '$BACKUP_DIR/db_$STAMP.sqlite3'"

# 30世代を超えた古いバックアップを削除
ls -1t "$BACKUP_DIR"/db_*.sqlite3 2>/dev/null | tail -n +31 | xargs -I{} rm -f {}

echo "$(date '+%F %T') backup ok: db_$STAMP.sqlite3"
