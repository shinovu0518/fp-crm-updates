from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from apps.utils import json_body
from apps.customers.models import Customer
from .models import Task


@csrf_exempt
@require_http_methods(["POST"])
def api_task_create(request):
    data = json_body(request)
    title = data.get('title', '').strip()
    if not title:
        return JsonResponse({'error': 'タイトルは必須です'}, status=400)

    customer = None
    if data.get('customer_id'):
        try:
            customer = Customer.objects.get(pk=data['customer_id'])
        except Customer.DoesNotExist:
            pass

    priority_map = {'高': 1, '中': 2, '低': 3, '1': 1, '2': 2, '3': 3}
    priority = priority_map.get(str(data.get('priority', '中')), 2)

    task = Task.objects.create(
        customer=customer,
        title=title,
        description=data.get('description', ''),
        due_date=data.get('due_date') or None,
        planned_date=data.get('planned_date') or None,
        status=data.get('status', 'pending'),
        priority=priority,
    )
    return JsonResponse({
        'id': task.pk,
        'message': f'タスク「{task.title}」を登録しました',
    })


@csrf_exempt
@require_http_methods(["PATCH", "POST"])
def api_task_update(request, pk):
    """タスクの部分更新（完了にする・期日変更など）。"""
    try:
        task = Task.objects.get(pk=pk)
    except Task.DoesNotExist:
        return JsonResponse({'error': 'タスクが見つかりません'}, status=404)

    data = json_body(request)
    updated_fields = []

    if 'status' in data:
        task.status = data['status']
        updated_fields.append('status')
    if 'title' in data:
        task.title = data['title']
        updated_fields.append('title')
    if 'description' in data:
        task.description = data['description']
        updated_fields.append('description')
    if 'due_date' in data:
        task.due_date = data['due_date'] or None
        updated_fields.append('due_date')
    if 'planned_date' in data:
        task.planned_date = data['planned_date'] or None
        updated_fields.append('planned_date')
    if 'priority' in data:
        priority_map = {'高': 1, '中': 2, '低': 3, '1': 1, '2': 2, '3': 3}
        task.priority = priority_map.get(str(data['priority']), task.priority)
        updated_fields.append('priority')

    if not updated_fields:
        return JsonResponse({'error': '更新するフィールドがありません'}, status=400)

    task.save()
    return JsonResponse({
        'id': task.pk,
        'updated_fields': updated_fields,
        'message': f'タスク「{task.title}」を更新しました',
    })
