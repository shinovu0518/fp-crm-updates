from datetime import date
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import Task
from .forms import TaskForm


def task_list(request):
    qs = Task.objects.select_related('customer').exclude(status__in=['completed', 'cancelled'])
    filter_type = request.GET.get('filter', '')
    customer_pk = request.GET.get('customer', '')
    today = date.today()
    if filter_type == 'today':
        qs = qs.filter(due_date=today)
    elif filter_type == 'overdue':
        qs = qs.filter(due_date__lt=today)
    elif filter_type == 'all':
        qs = Task.objects.select_related('customer')
    if customer_pk:
        qs = qs.filter(customer_id=customer_pk)
    customer_obj = None
    if customer_pk:
        from apps.customers.models import Customer
        try:
            customer_obj = Customer.objects.get(pk=customer_pk)
        except Customer.DoesNotExist:
            pass
    return render(request, 'tasks/list.html', {
        'tasks': qs,
        'filter_type': filter_type,
        'customer_pk': customer_pk,
        'customer_obj': customer_obj,
        'today': today,
    })


def task_create(request):
    customer_pk = request.GET.get('customer')
    initial = {}
    if customer_pk:
        from apps.customers.models import Customer
        try:
            initial['customer'] = Customer.objects.get(pk=customer_pk)
        except Customer.DoesNotExist:
            pass
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save()
            messages.success(request, f'タスク「{task.title}」を登録しました。')
            return redirect('tasks:list')
    else:
        form = TaskForm(initial=initial)
    return render(request, 'tasks/form.html', {'form': form, 'action': '新規登録'})


def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, f'タスク「{task.title}」を更新しました。')
            return redirect('tasks:list')
    else:
        form = TaskForm(instance=task)
    return render(request, 'tasks/form.html', {'form': form, 'task': task, 'action': '編集'})


def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        title = task.title
        task.delete()
        messages.success(request, f'タスク「{title}」を削除しました。')
    return redirect('tasks:list')


def task_complete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        task.status = 'completed'
        task.save(update_fields=['status', 'updated_at'])
        messages.success(request, f'タスク「{task.title}」を完了にしました。')
    return redirect(request.POST.get('next_url', '/tasks/'))
