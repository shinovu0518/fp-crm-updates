from django.db import models


class Task(models.Model):
    STATUS_CHOICES = [
        ('pending', '未着手'),
        ('in_progress', '進行中'),
        ('completed', '完了'),
        ('cancelled', 'キャンセル'),
    ]
    PRIORITY_CHOICES = [
        (1, '高'),
        (2, '中'),
        (3, '低'),
    ]

    customer = models.ForeignKey(
        'customers.Customer', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='tasks', verbose_name='顧客'
    )
    title = models.CharField('タイトル', max_length=200)
    description = models.TextField('説明', blank=True)
    due_date = models.DateField('期日', null=True, blank=True)
    # 期日とは別に「この日にやる」と本人が決めた日（夜のブリーフィングへのLINE返信などで設定）
    planned_date = models.DateField('やる日', null=True, blank=True)
    status = models.CharField('ステータス', max_length=20, choices=STATUS_CHOICES, default='pending')
    priority = models.IntegerField('優先度', choices=PRIORITY_CHOICES, default=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['due_date', 'priority']
        verbose_name = 'タスク'
        verbose_name_plural = 'タスク一覧'

    def __str__(self):
        return self.title
