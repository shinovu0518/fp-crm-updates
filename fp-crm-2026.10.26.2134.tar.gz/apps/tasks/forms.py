from django import forms
from apps.deals.forms import DateInputISO
from .models import Task


class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['customer', 'title', 'description', 'due_date', 'planned_date', 'status', 'priority']
        widgets = {
            'due_date': DateInputISO(),
            'planned_date': DateInputISO(),
            'description': forms.Textarea(attrs={'rows': 12}),
        }
        help_texts = {
            'due_date': '空白の場合は期日なしとして登録されます',
            'planned_date': '設定するとその日のダッシュボード「今日やること」に表示されます',
            'customer': '顧客に紐づかないタスクは空白のままでOKです',
        }
