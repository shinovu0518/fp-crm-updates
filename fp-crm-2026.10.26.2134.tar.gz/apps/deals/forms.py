from django import forms
from .models import Deal, InsuranceCompany, InsuranceProduct


class DateInputISO(forms.DateInput):
    input_type = 'date'

    def format_value(self, value):
        if not value:
            return ''
        # date/datetime オブジェクト
        if hasattr(value, 'strftime'):
            return value.strftime('%Y-%m-%d')
        if isinstance(value, str):
            # すでに ISO 形式（YYYY-MM-DD）
            import re
            if re.match(r'^\d{4}-\d{2}-\d{2}', value):
                return value[:10]
            # ロケール形式（例: "6月 5, 2026"）をパース
            from datetime import datetime
            for fmt in ('%m月 %d, %Y', '%Y年%m月%d日', '%Y/%m/%d', '%m/%d/%Y'):
                try:
                    return datetime.strptime(value.strip(), fmt).strftime('%Y-%m-%d')
                except ValueError:
                    pass
        return ''


class MonthInput(forms.DateInput):
    input_type = 'month'

    def format_value(self, value):
        if value and hasattr(value, 'strftime'):
            return value.strftime('%Y-%m')
        if value and isinstance(value, str) and len(value) == 10:
            return value[:7]
        return value or ''


class DealForm(forms.ModelForm):
    class Meta:
        model = Deal
        fields = [
            'customer', 'insured', 'company', 'product',
            'premium', 'payment_method', 'anp', 'ac',
            'application_date', 'expected_close_month',
            'status', 'stage', 'policy_number', 'notes',
        ]
        widgets = {
            'application_date': DateInputISO(),
            'expected_close_month': DateInputISO(),
            'notes': forms.Textarea(attrs={'rows': 2}),
        }
        help_texts = {
            'anp': 'Annualized New Premium（年換算新契約保険料）',
            'ac': 'Annual Commission（年間手数料）',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['company'].queryset = InsuranceCompany.objects.all()
        self.fields['company'].empty_label = '--- 選択してください ---'
        self.fields['product'].queryset = InsuranceProduct.objects.select_related('company').all()
        self.fields['product'].empty_label = '--- 会社を選択後に選んでください ---'
        self.fields['company'].required = False
        self.fields['product'].required = False
        self.fields['insured'].empty_label = '契約者と同一'
        self.fields['insured'].required = False

    def _clean_number(self, field_name):
        from apps.utils import clean_number
        return clean_number(self.cleaned_data.get(field_name))

    def clean_premium(self):
        return self._clean_number('premium')

    def clean_anp(self):
        return self._clean_number('anp')

    def clean_ac(self):
        return self._clean_number('ac')

    def clean(self):
        cleaned = super().clean()
        company = cleaned.get('company')
        product = cleaned.get('product')
        # JS側でもフィルタリングしているが、サーバー側でも整合性を保証する
        if product and company and product.company_id != company.id:
            self.add_error('product', '選択した商品は保険会社と一致していません。')

        customer = cleaned.get('customer')
        insured = cleaned.get('insured')
        if insured and customer and insured.pk != customer.pk:
            from django.db.models import Q
            from apps.customers.models import CustomerRelationship
            linked = CustomerRelationship.objects.filter(
                Q(from_customer=customer, to_customer=insured) | Q(from_customer=insured, to_customer=customer)
            ).exists()
            if not linked:
                self.add_error('insured', '被保険者は契約者本人か、登録済みの家族から選択してください。')
        return cleaned


