from decimal import Decimal
from django.db import models


class InsuranceCompany(models.Model):
    CATEGORY_CHOICES = [
        ('life',       '生命保険'),
        ('non_life',   '損害保険'),
        ('securities', '証券'),
    ]
    name = models.CharField('会社名', max_length=100, unique=True)
    category = models.CharField('種別', max_length=20, choices=CATEGORY_CHOICES, default='life')
    order = models.IntegerField('表示順', default=0)

    class Meta:
        ordering = ['category', 'order', 'name']
        verbose_name = '会社'
        verbose_name_plural = '会社一覧'

    def __str__(self):
        return self.name


class InsuranceProduct(models.Model):
    company = models.ForeignKey(InsuranceCompany, on_delete=models.CASCADE,
                                related_name='products', verbose_name='会社')
    name = models.CharField('商品名／銘柄名', max_length=200)
    trust_fee = models.DecimalField('信託報酬（年率%）', max_digits=6, decimal_places=3, null=True, blank=True)
    purchase_fee = models.DecimalField('購入時手数料（%）', max_digits=6, decimal_places=3, null=True, blank=True)
    retention_fee = models.DecimalField('信託財産留保額（%）', max_digits=6, decimal_places=3, null=True, blank=True)
    order = models.IntegerField('表示順', default=0)

    class Meta:
        ordering = ['order', 'name']
        verbose_name = '商品／銘柄'
        verbose_name_plural = '商品／銘柄一覧'

    def __str__(self):
        return f"{self.company.name} - {self.name}"


class Deal(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ('monthly', '月払'),
        ('annual',  '年払'),
        ('lump',    '一時払'),
    ]
    STATUS_CHOICES = [
        ('in_progress', '推進中'),
        ('contracted',  '成約'),
        ('existing',    '既契約'),
        ('cancelled',   '解約'),
        ('lost',        '失注'),
    ]
    STAGE_CHOICES = [
        ('',           '─'),
        ('hearing',    'ヒアリング'),
        ('proposal',   '提案'),
        ('closing',    'クロージング'),
    ]

    ACTIVE_STATUSES = ['contracted', 'existing']
    INACTIVE_STATUSES = ['lost', 'cancelled']

    customer = models.ForeignKey(
        'customers.Customer', on_delete=models.CASCADE,
        related_name='deals', verbose_name='契約者'
    )
    insured = models.ForeignKey(
        'customers.Customer', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='insured_deals', verbose_name='被保険者'
    )
    company = models.ForeignKey(
        InsuranceCompany, on_delete=models.SET_NULL,
        null=True, blank=True, verbose_name='保険会社'
    )
    product = models.ForeignKey(
        InsuranceProduct, on_delete=models.SET_NULL,
        null=True, blank=True, verbose_name='商品名'
    )
    # 旧フィールド（移行用として残す）
    company_name = models.CharField('保険会社名（旧）', max_length=100, blank=True)
    product_name = models.CharField('商品名（旧）', max_length=200, blank=True)
    product_category = models.CharField('商品カテゴリ', max_length=20, blank=True)

    premium = models.DecimalField('保険料', max_digits=12, decimal_places=0,
                                  null=True, blank=True)
    payment_method = models.CharField('払方', max_length=10,
                                      choices=PAYMENT_METHOD_CHOICES, blank=True)
    anp = models.DecimalField('ANP', max_digits=12, decimal_places=0,
                              null=True, blank=True)
    ac = models.DecimalField('AC', max_digits=12, decimal_places=0,
                             null=True, blank=True)
    application_date = models.DateField('申込日', null=True, blank=True)
    expected_close_month = models.DateField('契約日', null=True, blank=True)
    status = models.CharField('ステータス', max_length=20, choices=STATUS_CHOICES,
                              default='in_progress')
    stage = models.CharField('ステージ', max_length=20, choices=STAGE_CHOICES, blank=True)
    policy_number = models.CharField('証券番号', max_length=100, blank=True)
    notes = models.TextField('備考', blank=True)

    # 旧フィールド（集計参照用として残す）
    expected_revenue = models.DecimalField('見込売上（旧）', max_digits=12, decimal_places=0,
                                           null=True, blank=True)
    confirmed_revenue = models.DecimalField('確定売上（旧）', max_digits=12, decimal_places=0,
                                            null=True, blank=True)
    lost_reason = models.TextField('失注理由（旧）', blank=True)

    joint_ratio = models.DecimalField('按分率', max_digits=4, decimal_places=2, default=Decimal('0.50'))

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = '案件'
        verbose_name_plural = '案件一覧'

    def __str__(self):
        company = self.company.name if self.company else self.company_name
        product = self.product.name if self.product else self.product_name
        return f"{self.customer.name} - {product or '（商品未設定）'}"

    @property
    def converted_ac(self):
        if not self.ac:
            return Decimal('0')
        route = self.customer.consultation_route if self.customer else None
        if not route or route.solicitation_type != 'joint':
            return self.ac
        fid = self.customer.effective_first_interview_date if self.customer else None
        if not fid:
            return self.ac * self.joint_ratio
        from datetime import date
        cutoff_year = fid.year + route.joint_years
        try:
            cutoff = fid.replace(year=cutoff_year)
        except ValueError:
            cutoff = fid.replace(year=cutoff_year, day=28)
        if date.today() <= cutoff:
            return self.ac * self.joint_ratio
        return self.ac

    @property
    def display_company(self):
        return self.company.name if self.company else self.company_name

    @property
    def display_product(self):
        return self.product.name if self.product else self.product_name


class DealJointCompany(models.Model):
    deal = models.ForeignKey(Deal, on_delete=models.CASCADE,
                             related_name='joint_companies', verbose_name='案件')
    company = models.ForeignKey(InsuranceCompany, on_delete=models.CASCADE,
                                verbose_name='保険会社')
    recruiter_code = models.CharField('募集人コード', max_length=50, blank=True)

    class Meta:
        unique_together = [('deal', 'company')]
        verbose_name = '案件別共同募集保険会社'
        verbose_name_plural = '案件別共同募集保険会社'

    def __str__(self):
        return f"{self.deal} / {self.company.name}"
