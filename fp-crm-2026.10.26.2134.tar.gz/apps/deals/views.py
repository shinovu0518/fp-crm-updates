import json
from datetime import date
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.views.decorators.http import require_http_methods
from .models import Deal, InsuranceCompany, InsuranceProduct, DealJointCompany
from .forms import DealForm

SORT_FIELDS = {
    'premium': lambda d: d.premium or 0,
    'anp': lambda d: d.anp or 0,
    'ac': lambda d: d.converted_ac,
    'application_date': lambda d: d.application_date or date.min,
}


def _insured_options_json():
    """契約者ごとに選択可能な被保険者（本人＋登録済みの家族）を返す。
    家族関係は双方向で登録されているため、from_customer側だけを見れば両方向を網羅できる。"""
    from apps.customers.models import Customer, CustomerRelationship

    options = {c.pk: [{'id': c.pk, 'name': c.name, 'relation': '本人'}] for c in Customer.objects.all()}
    seen = {pk: {pk} for pk in options}
    for rel in CustomerRelationship.objects.select_related('to_customer').all():
        if rel.from_customer_id in options and rel.to_customer_id not in seen[rel.from_customer_id]:
            options[rel.from_customer_id].append({
                'id': rel.to_customer_id,
                'name': rel.to_customer.name,
                'relation': rel.get_relation_display(),
            })
            seen[rel.from_customer_id].add(rel.to_customer_id)
    return json.dumps(options, ensure_ascii=False)


def deal_list(request):
    qs = Deal.objects.select_related('customer__consultation_route', 'insured', 'company', 'product')
    tab = request.GET.get('tab', 'all')
    if tab == 'active':
        qs = qs.filter(status='contracted')
    elif tab == 'existing':
        qs = qs.filter(status='existing')
    elif tab == 'inactive':
        qs = qs.filter(status__in=Deal.INACTIVE_STATUSES)

    sort = request.GET.get('sort')
    order = request.GET.get('order', 'desc')
    deals = list(qs)
    if sort in SORT_FIELDS:
        deals.sort(key=SORT_FIELDS[sort], reverse=(order != 'asc'))

    return render(request, 'deals/list.html', {
        'deals': deals,
        'tab': tab,
        'status_choices': Deal.STATUS_CHOICES,
        'sort': sort,
        'order': order,
    })


def deal_create(request):
    customer_pk = request.GET.get('customer')
    initial = {}
    if customer_pk:
        from apps.customers.models import Customer
        try:
            initial['customer'] = Customer.objects.get(pk=customer_pk)
        except Customer.DoesNotExist:
            pass
    if request.method == 'POST':
        form = DealForm(request.POST)
        if form.is_valid():
            deal = form.save()
            messages.success(request, '案件を登録しました。')
            return redirect('customers:detail', pk=deal.customer_id)
    else:
        form = DealForm(initial=initial)
    companies = list(InsuranceCompany.objects.values('id', 'name'))
    products = list(InsuranceProduct.objects.values('id', 'name', 'company_id', 'purchase_fee').order_by('order', 'name'))
    return render(request, 'deals/form.html', {
        'form': form, 'action': '新規登録',
        'companies_json': json.dumps(companies, ensure_ascii=False),
        'products_json': json.dumps(products, ensure_ascii=False, default=float),
        'insured_options_json': _insured_options_json(),
        'all_products': products,
        'current_product_id': '',
        'current_insured_id': '',
    })


def deal_edit(request, pk):
    deal = get_object_or_404(Deal, pk=pk)
    if request.method == 'POST':
        form = DealForm(request.POST, instance=deal)
        if form.is_valid():
            form.save()
            messages.success(request, '案件を更新しました。')
            return redirect('customers:detail', pk=deal.customer_id)
    else:
        form = DealForm(instance=deal)
    companies = list(InsuranceCompany.objects.values('id', 'name'))
    products = list(InsuranceProduct.objects.values('id', 'name', 'company_id', 'purchase_fee').order_by('order', 'name'))
    return render(request, 'deals/form.html', {
        'form': form, 'deal': deal, 'action': '編集',
        'companies_json': json.dumps(companies, ensure_ascii=False),
        'products_json': json.dumps(products, ensure_ascii=False, default=float),
        'insured_options_json': _insured_options_json(),
        'all_products': products,
        'current_product_id': deal.product_id or '',
        'current_insured_id': deal.insured_id or '',
    })


def deal_delete(request, pk):
    deal = get_object_or_404(Deal, pk=pk)
    if request.method == 'POST':
        customer_pk = deal.customer_id
        deal.delete()
        messages.success(request, '案件を削除しました。')
        return redirect('customers:detail', pk=customer_pk)
    return redirect('deals:list')


def products_by_company(request):
    company_id = request.GET.get('company_id')
    products = list(InsuranceProduct.objects.filter(company_id=company_id).values('id', 'name'))
    return JsonResponse({'products': products})


@require_http_methods(["POST"])
def deal_joint_company_save(request, deal_pk):
    deal = get_object_or_404(Deal, pk=deal_pk)
    company_id = request.POST.get('company_id')
    code = request.POST.get('recruiter_code', '').strip()
    if company_id:
        DealJointCompany.objects.update_or_create(
            deal=deal, company_id=company_id,
            defaults={'recruiter_code': code}
        )
    return redirect('customers:detail', pk=deal.customer_id)


@require_http_methods(["POST"])
def deal_joint_company_delete(request, pk):
    jc = get_object_or_404(DealJointCompany, pk=pk)
    customer_id = jc.deal.customer_id
    jc.delete()
    return redirect('customers:detail', pk=customer_id)
