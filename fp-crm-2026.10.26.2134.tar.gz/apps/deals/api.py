from datetime import date as date_type

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from apps.utils import json_body
from apps.customers.models import Customer
from .models import Deal, InsuranceCompany, InsuranceProduct


@csrf_exempt
@require_http_methods(["POST"])
def api_deal_create(request):
    data = json_body(request)
    customer_id = data.get('customer_id')
    product_name = data.get('product_name', '').strip()
    if not customer_id or not product_name:
        return JsonResponse({'error': 'customer_idとproduct_nameは必須です'}, status=400)

    try:
        customer = Customer.objects.get(pk=customer_id)
    except Customer.DoesNotExist:
        return JsonResponse({'error': '顧客が見つかりません'}, status=404)

    def parse_month(val):
        if not val:
            return None
        if isinstance(val, str) and len(val) == 7:
            y, m = val.split('-')
            return date_type(int(y), int(m), 1)
        return None

    # 保険会社FK解決
    company_obj = None
    company_name = data.get('company_name', '')
    if data.get('company_id'):
        company_obj = InsuranceCompany.objects.filter(pk=data['company_id']).first()
    elif company_name:
        company_obj = InsuranceCompany.objects.filter(name=company_name).first()

    # 商品FK解決
    product_obj = None
    if data.get('product_id'):
        product_obj = InsuranceProduct.objects.filter(pk=data['product_id']).first()
    elif company_obj:
        product_obj = InsuranceProduct.objects.filter(name=product_name, company=company_obj).first()

    # ANP自動計算
    premium = data.get('premium') or None
    payment_method = data.get('payment_method', '')
    anp = data.get('anp') or None
    if premium and not anp:
        multiplier = 12 if payment_method == 'monthly' else 0.1 if payment_method == 'lump' else 1
        anp = int(float(premium) * multiplier)

    deal = Deal.objects.create(
        customer=customer,
        company=company_obj,
        product=product_obj,
        product_name=product_name,
        product_category=data.get('product_category', 'insurance'),
        company_name=company_obj.name if company_obj else company_name,
        premium=premium,
        payment_method=payment_method,
        anp=anp,
        ac=data.get('ac') or None,
        application_date=data.get('application_date') or None,
        expected_revenue=data.get('expected_revenue') or None,
        confirmed_revenue=data.get('confirmed_revenue') or None,
        expected_close_month=parse_month(data.get('expected_close_month')),
        status=data.get('status', 'prospecting'),
        notes=data.get('notes', ''),
    )
    return JsonResponse({
        'id': deal.pk,
        'message': f'案件「{deal.product_name}」を登録しました',
    })
