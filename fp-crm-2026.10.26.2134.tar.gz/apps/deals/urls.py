from django.urls import path
from . import views

app_name = 'deals'

urlpatterns = [
    path('', views.deal_list, name='list'),
    path('new/', views.deal_create, name='create'),
    path('<int:pk>/edit/', views.deal_edit, name='edit'),
    path('<int:pk>/delete/', views.deal_delete, name='delete'),
    path('api/products-by-company/', views.products_by_company, name='products_by_company'),
    path('<int:deal_pk>/joint-companies/save/', views.deal_joint_company_save, name='deal_joint_company_save'),
    path('joint-companies/<int:pk>/delete/', views.deal_joint_company_delete, name='deal_joint_company_delete'),
]
