from django import forms
from .models import Interview


class InterviewForm(forms.ModelForm):
    class Meta:
        model = Interview
        fields = [
            'date', 'outcome', 'consultation_content', 'proposal_content',
            'next_schedule_type', 'next_schedule_date',
            'next_follow_up', 'assets_status', 'existing_insurance', 'proposal_detail', 'memo',
        ]
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
            'next_schedule_date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
            'consultation_content': forms.Textarea(attrs={'rows': 4}),
            'proposal_content': forms.Textarea(attrs={'rows': 4}),
            'next_follow_up': forms.Textarea(attrs={'rows': 3}),
            'assets_status': forms.Textarea(attrs={'rows': 3}),
            'existing_insurance': forms.Textarea(attrs={'rows': 3}),
            'proposal_detail': forms.Textarea(attrs={'rows': 3}),
            'memo': forms.Textarea(attrs={'rows': 3}),
        }
        help_texts = {
            'next_follow_up': '次回の面談や連絡で確認すべきこと',
            'memo': '社内メモ・備忘録など',
        }
