from django.contrib import admin
from .models import ComplianceRecord, Interview

admin.site.register(Interview)


@admin.register(ComplianceRecord)
class ComplianceRecordAdmin(admin.ModelAdmin):
    list_display = ('customer', 'date', 'domain', 'proposed_product', 'check_status')
    list_filter = ('domain', 'check_status')
    search_fields = ('customer__name', 'proposed_product')
