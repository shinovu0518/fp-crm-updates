from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from django.db import transaction
from django.views.decorators.http import require_POST
from django.views.generic.edit import CreateView, UpdateView
from django.urls import reverse
from apps.customers.models import Customer, CustomerRelationship
from .models import Interview, InterviewDraft
from .api import apply_interview_draft
from .forms import InterviewForm


class InterviewCreateView(CreateView):
    model = Interview
    form_class = InterviewForm
    template_name = 'interviews/form.html'

    def get_customer(self):
        return get_object_or_404(Customer, pk=self.kwargs['customer_pk'])

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['customer'] = self.get_customer()
        ctx['action'] = '面談履歴を追加'
        return ctx

    def form_valid(self, form):
        customer = self.get_customer()
        form.instance.customer = customer
        messages.success(self.request, '面談履歴を登録しました。')
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('customers:detail', kwargs={'pk': self.kwargs['customer_pk']})


class InterviewUpdateView(UpdateView):
    model = Interview
    form_class = InterviewForm
    template_name = 'interviews/form.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['customer'] = self.object.customer
        ctx['action'] = '面談履歴を編集'
        return ctx

    def form_valid(self, form):
        messages.success(self.request, '面談履歴を更新しました。')
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('customers:detail', kwargs={'pk': self.object.customer_id})


def interview_detail(request, pk):
    interview = get_object_or_404(Interview.objects.select_related('customer'), pk=pk)
    return render(request, 'interviews/detail.html', {'interview': interview})


def interview_delete(request, pk):
    interview = get_object_or_404(Interview, pk=pk)
    customer_pk = interview.customer_id
    if request.method == 'POST':
        interview.delete()
        messages.success(request, '面談履歴を削除しました。')
    return redirect('customers:detail', pk=customer_pk)


def _find_customer_by_name(name):
    """空白（全角・半角）の違いを無視して、同じ名前の顧客を探す。見つからなければNone。"""
    key = ''.join((name or '').split())
    if not key:
        return None
    for c in Customer.objects.filter(name__contains=key[0]):
        if ''.join(c.name.split()) == key:
            return c
    return None


def _link_referrer_and_family(customer, post):
    """承認画面で指定された紹介者・家族を顧客に紐付ける（どちらも任意）。"""
    referrer_id = post.get('referred_by')
    if referrer_id and referrer_id.isdigit() and int(referrer_id) != customer.pk:
        customer.referred_by = get_object_or_404(Customer, pk=referrer_id)
        customer.save(update_fields=['referred_by'])

    family_id, relation = post.get('family_customer'), post.get('family_relation')
    if family_id and family_id.isdigit() and int(family_id) != customer.pk \
            and relation in dict(CustomerRelationship.RELATION_CHOICES):
        family = get_object_or_404(Customer, pk=family_id)
        CustomerRelationship.objects.get_or_create(from_customer=customer, to_customer=family,
                                                   defaults={'relation': relation})
        CustomerRelationship.objects.get_or_create(
            from_customer=family, to_customer=customer,
            defaults={'relation': CustomerRelationship.INVERSE_RELATION.get(relation, 'other')})


def interview_draft_list(request):
    """Notta未処理チェックが自動生成した面談ドラフトの確認・承認画面。"""
    drafts = list(InterviewDraft.objects.filter(status='pending').select_related('customer'))
    # 候補名と同じ名前（空白違いを含む）の顧客がいれば、それを最初から選んでおく。いなければ「新規登録」を選んでおく
    for d in drafts:
        if d.customer_id is None:
            d.matched_customer = _find_customer_by_name(d.candidate_name)
    return render(request, 'interviews/draft_list.html', {
        'drafts': drafts,
        'relation_choices': CustomerRelationship.RELATION_CHOICES,
    })


@require_POST
def interview_draft_approve(request, pk):
    draft = get_object_or_404(InterviewDraft, pk=pk, status='pending')

    overrides = {
        field: request.POST[field]
        for field in ('consultation_content', 'proposal_content', 'memo', 'next_follow_up', 'prospect_score')
        if field in request.POST
    }

    created_customer = False
    try:
        with transaction.atomic():
            customer_id = request.POST.get('customer_id')
            if customer_id == 'new':
                name = (request.POST.get('new_customer_name') or draft.candidate_name).strip()
                if not name:
                    raise ValueError('新規登録する顧客の名前を入力してください')
                # 同じ名前の顧客がすでにいれば、二重に作らずそちらに紐付ける（同じ人のドラフトが2件ある場合など）
                draft.customer = _find_customer_by_name(name)
                if draft.customer is None:
                    draft.customer = Customer.objects.create(name=name, first_interview_date=draft.date)
                    created_customer = True
                draft.save(update_fields=['customer'])
            elif customer_id:
                draft.customer = get_object_or_404(Customer, pk=customer_id)
                draft.save(update_fields=['customer'])

            interview, created_tasks = apply_interview_draft(draft, overrides)
            _link_referrer_and_family(draft.customer, request.POST)
    except ValueError as e:
        messages.error(request, str(e))
        return redirect('interviews:draft_list')

    messages.success(
        request,
        f'{draft.customer.name}様の面談を登録しました（面談ID {interview.pk}、タスク{len(created_tasks)}件作成）。'
        + ('顧客ページも新しく作成しました。' if created_customer else '')
    )
    return redirect('interviews:draft_list')


@require_POST
def interview_draft_dismiss(request, pk):
    draft = get_object_or_404(InterviewDraft, pk=pk, status='pending')
    draft.status = 'dismissed'
    draft.save(update_fields=['status', 'updated_at'])
    messages.success(request, 'ドラフトを見送りにしました。')
    return redirect('interviews:draft_list')
