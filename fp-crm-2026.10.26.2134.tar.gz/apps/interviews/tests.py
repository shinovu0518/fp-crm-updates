"""面談ドラフトの承認で、候補の顧客がまだいなければ新しく登録する仕組みのテスト。"""
from datetime import date

from django.contrib.auth.models import User
from django.test import TestCase, override_settings

from apps.customers.models import Customer

from .models import Interview, InterviewDraft


@override_settings(PERSONAL_FEATURES=True)
class DraftNewCustomerTests(TestCase):
    def setUp(self):
        self.client.force_login(User.objects.create_user('u', password='p'))

    def _draft(self, name):
        return InterviewDraft.objects.create(candidate_name=name, date=date(2026, 10, 1),
                                             consultation_content='相談内容', tasks=[])

    def _approve(self, draft, **post):
        return self.client.post(f'/interviews/drafts/{draft.pk}/approve/', data=post)

    def test_creates_new_customer_and_interview(self):
        draft = self._draft('架空太郎')
        self._approve(draft, customer_id='new', new_customer_name='架空太郎')
        customer = Customer.objects.get(name='架空太郎')
        self.assertEqual(customer.first_interview_date, date(2026, 10, 1))
        self.assertTrue(Interview.objects.filter(customer=customer).exists())
        draft.refresh_from_db()
        self.assertEqual((draft.status, draft.customer), ('approved', customer))

    def test_reuses_existing_customer_with_same_name(self):
        existing = Customer.objects.create(name='架空太郎')
        before = Customer.objects.count()  # データ移行で入る顧客がいるので、増減で見る
        first, second = self._draft('架空太郎'), self._draft('架空太郎')
        self._approve(first, customer_id='new', new_customer_name='架空太郎')
        self._approve(second, customer_id='new', new_customer_name='架空太郎')
        self.assertEqual(Customer.objects.count(), before)
        self.assertEqual(Interview.objects.filter(customer=existing).count(), 2)

    def test_blank_name_creates_nothing(self):
        draft = self._draft('')
        before = Customer.objects.count()
        self._approve(draft, customer_id='new', new_customer_name=' ')
        self.assertEqual(Customer.objects.count(), before)
        draft.refresh_from_db()
        self.assertEqual(draft.status, 'pending')

    def test_list_preselects_new_or_matched(self):
        Customer.objects.create(name='架空次郎')
        self._draft('架空次郎')
        self._draft('架空花子')
        html = self.client.get('/interviews/drafts/').content.decode()
        kita = Customer.objects.get(name='架空次郎')
        # 松村様は未登録なので「新規登録」、喜多様は既存の顧客が選ばれた状態で出る
        self.assertIn('value="架空花子"', html)
        self.assertIn('name="customer_id" value="new"', html)
        self.assertIn(f'name="customer_id" value="{kita.pk}"', html)
        self.assertIn('customer-picker-data', html)


@override_settings(PERSONAL_FEATURES=True)
class DraftLinkingTests(TestCase):
    """承認時に紹介者・家族を紐付ける。"""
    def setUp(self):
        self.client.force_login(User.objects.create_user('u', password='p'))
        self.referrer = Customer.objects.create(name='紹介 太郎')
        self.family = Customer.objects.create(name='家族 花子')

    def test_links_referrer_and_family_to_new_customer(self):
        from apps.customers.models import CustomerRelationship
        draft = InterviewDraft.objects.create(candidate_name='新規 次郎', date=date(2026, 10, 1), tasks=[])
        self.client.post(f'/interviews/drafts/{draft.pk}/approve/', data={
            'customer_id': 'new', 'new_customer_name': '新規 次郎',
            'referred_by': self.referrer.pk, 'family_relation': 'spouse', 'family_customer': self.family.pk})
        new = Customer.objects.get(name='新規 次郎')
        self.assertEqual(new.referred_by, self.referrer)
        self.assertEqual(CustomerRelationship.objects.get(from_customer=new, to_customer=self.family).relation, 'spouse')
        self.assertEqual(CustomerRelationship.objects.get(from_customer=self.family, to_customer=new).relation, 'spouse')

    def test_set_referrer_from_customer_page(self):
        c = Customer.objects.create(name='対象 三郎')
        self.client.post(f'/customers/{c.pk}/referrer/', data={'referred_by': self.referrer.pk})
        c.refresh_from_db()
        self.assertEqual(c.referred_by, self.referrer)
        html = self.client.get(f'/customers/{self.referrer.pk}/').content.decode()
        self.assertIn('紹介したお客様', html)
        self.assertIn('対象 三郎様', html)
        self.client.post(f'/customers/{c.pk}/referrer/', data={'clear': '1'})
        c.refresh_from_db()
        self.assertIsNone(c.referred_by)
