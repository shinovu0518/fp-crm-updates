from django.urls import path
from . import views

app_name = 'interviews'

urlpatterns = [
    path('drafts/', views.interview_draft_list, name='draft_list'),
    path('drafts/<int:pk>/approve/', views.interview_draft_approve, name='draft_approve'),
    path('drafts/<int:pk>/dismiss/', views.interview_draft_dismiss, name='draft_dismiss'),
    path('<int:pk>/', views.interview_detail, name='detail'),
    path('<int:pk>/edit/', views.InterviewUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', views.interview_delete, name='delete'),
]
