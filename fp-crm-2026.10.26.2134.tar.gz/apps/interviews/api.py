from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from apps.utils import json_body
from apps.customers.models import Customer
from .models import Interview, ComplianceRecord, InterviewDraft


@csrf_exempt
@require_http_methods(["POST"])
def api_interview_create(request):
    data = json_body(request)
    customer_id = data.get('customer_id')
    if not customer_id:
        return JsonResponse({'error': 'customer_idは必須です'}, status=400)

    try:
        customer = Customer.objects.get(pk=customer_id)
    except Customer.DoesNotExist:
        return JsonResponse({'error': '顧客が見つかりません'}, status=404)

    # 冪等ガード：同じ原本ファイルIDの面談が既にあれば二重登録しない
    source_file_id = data.get('source_file_id', '')
    if source_file_id:
        existing = Interview.objects.filter(source_file_id=source_file_id).first()
        if existing:
            return JsonResponse({
                'id': existing.pk,
                'duplicate': True,
                'message': f'この原本（{source_file_id}）は既に登録済みです（面談ID {existing.pk}）',
            })

    interview = Interview.objects.create(
        customer=customer,
        date=data.get('date'),
        channel=data.get('channel', ''),
        meeting_type=data.get('meeting_type', ''),
        consultation_content=data.get('consultation_content', ''),
        proposal_content=data.get('proposal_content', ''),
        outcome=data.get('outcome', ''),
        next_schedule_type=data.get('next_schedule_type', ''),
        next_schedule_date=data.get('next_schedule_date') or None,
        next_follow_up=data.get('next_follow_up', ''),
        memo=data.get('memo', ''),
        assets_status=data.get('assets_status', ''),
        existing_insurance=data.get('existing_insurance', ''),
        proposal_detail=data.get('proposal_detail', ''),
        source_pdf_url=data.get('source_pdf_url', ''),
        source_file_id=source_file_id,
    )
    return JsonResponse({
        'id': interview.pk,
        'message': f'面談履歴を登録しました（{interview.date}）',
    })


@csrf_exempt
@require_http_methods(["POST"])
def api_compliance_create(request):
    data = json_body(request)
    customer_id = data.get('customer_id')
    if not customer_id:
        return JsonResponse({'error': 'customer_idは必須です'}, status=400)

    try:
        customer = Customer.objects.get(pk=customer_id)
    except Customer.DoesNotExist:
        return JsonResponse({'error': '顧客が見つかりません'}, status=404)

    interview = None
    if data.get('interview_id'):
        interview = Interview.objects.filter(pk=data['interview_id'], customer=customer).first()

    flags = data.get('compliance_flags') or []
    if isinstance(flags, str):
        flags = [flags] if flags else []

    record = ComplianceRecord.objects.create(
        customer=customer,
        interview=interview,
        date=data.get('date'),
        domain=data.get('domain', 'insurance'),
        applicable_framework=data.get('applicable_framework', ''),
        proposed_product=data.get('proposed_product', ''),
        compared_products=data.get('compared_products', ''),
        recommendation_reason=data.get('recommendation_reason', ''),
        intent_product_mapping=data.get('intent_product_mapping', ''),
        risk_explanation=data.get('risk_explanation', ''),
        intention_initial=data.get('intention_initial', ''),
        intention_final=data.get('intention_final', ''),
        intent_review=data.get('intent_review', ''),
        intent_confirmation_method=data.get('intent_confirmation_method', ''),
        intent_confirmation_status=data.get('intent_confirmation_status', ''),
        compliance_flags=flags,
    )
    return JsonResponse({
        'id': record.pk,
        'message': f'コンプライアンス記録を登録しました（{record.date}）',
    })


@csrf_exempt
@require_http_methods(["PATCH", "POST"])
def api_interview_update(request, pk):
    """面談履歴の部分更新（相談内容の整形・次回予定の修正など）。"""
    try:
        interview = Interview.objects.get(pk=pk)
    except Interview.DoesNotExist:
        return JsonResponse({'error': '面談が見つかりません'}, status=404)

    data = json_body(request)
    updatable = [
        'date', 'channel', 'meeting_type', 'consultation_content', 'proposal_content',
        'outcome', 'next_schedule_type', 'next_follow_up', 'memo',
        'assets_status', 'existing_insurance', 'proposal_detail', 'source_pdf_url',
    ]
    updated_fields = []
    for field in updatable:
        if field in data:
            setattr(interview, field, data[field])
            updated_fields.append(field)

    # 日付フィールドは空文字をNULL扱いにする
    if 'next_schedule_date' in data:
        interview.next_schedule_date = data['next_schedule_date'] or None
        updated_fields.append('next_schedule_date')

    if not updated_fields:
        return JsonResponse({'error': '更新するフィールドがありません'}, status=400)

    interview.save()
    return JsonResponse({
        'id': interview.pk,
        'updated_fields': updated_fields,
        'message': f'面談履歴を更新しました（面談ID {interview.pk}）',
    })


@csrf_exempt
@require_http_methods(["POST"])
def api_interview_draft_create(request):
    """Notta未処理チェック（夜間スケジュールタスク）が生成した面談ドラフトを登録する。
    ここではCRM本体（Interview等）には一切書き込まない。承認されるまでは下書きのまま。"""
    data = json_body(request)
    if not data.get('date'):
        return JsonResponse({'error': 'dateは必須です'}, status=400)

    source_file_id = data.get('source_file_id', '')
    if source_file_id:
        if Interview.objects.filter(source_file_id=source_file_id).exists():
            return JsonResponse({'error': 'この原本は既に面談履歴として登録済みです', 'duplicate': True}, status=400)
        if InterviewDraft.objects.filter(source_file_id=source_file_id).exclude(status='dismissed').exists():
            existing = InterviewDraft.objects.filter(source_file_id=source_file_id).exclude(status='dismissed').first()
            return JsonResponse({
                'id': existing.pk,
                'duplicate': True,
                'message': f'この原本のドラフトは既に登録済みです（ドラフトID {existing.pk}）',
            })

    customer = None
    if data.get('customer_id'):
        customer = Customer.objects.filter(pk=data['customer_id']).first()

    draft = InterviewDraft.objects.create(
        customer=customer,
        candidate_name=data.get('candidate_name', ''),
        date=data['date'],
        source_file_name=data.get('source_file_name', ''),
        source_file_id=source_file_id,
        consultation_content=data.get('consultation_content', ''),
        proposal_content=data.get('proposal_content', ''),
        memo=data.get('memo', ''),
        outcome=data.get('outcome', ''),
        next_schedule_type=data.get('next_schedule_type', ''),
        next_schedule_date=data.get('next_schedule_date') or None,
        next_follow_up=data.get('next_follow_up', ''),
        prospect_score=data.get('prospect_score', ''),
        line_message=data.get('line_message', ''),
        compliance=data.get('compliance') or None,
        tasks=data.get('tasks') or [],
    )
    return JsonResponse({
        'id': draft.pk,
        'message': f'面談ドラフトを登録しました（{draft.date}）',
    })


def apply_interview_draft(draft, overrides=None):
    """承認された面談ドラフトを、実際のInterview/ComplianceRecord/Task/Customerに反映する。
    面談保存コマンドの書き込み実行（手順4）と同じ処理をコードとして行う版。
    overridesで内容を確認画面での手直し分に差し替えられる。"""
    if not draft.customer:
        raise ValueError('顧客が未確定のドラフトは承認できません')

    data = overrides or {}

    def field(name):
        return data.get(name, getattr(draft, name))

    interview = Interview.objects.create(
        customer=draft.customer,
        date=draft.date,
        consultation_content=field('consultation_content'),
        proposal_content=field('proposal_content'),
        memo=field('memo'),
        outcome=field('outcome'),
        next_schedule_type=field('next_schedule_type'),
        next_schedule_date=field('next_schedule_date'),
        next_follow_up=field('next_follow_up'),
        source_file_id=draft.source_file_id,
    )

    if draft.compliance:
        c = draft.compliance
        ComplianceRecord.objects.create(
            customer=draft.customer,
            interview=interview,
            date=draft.date,
            domain=c.get('domain', 'insurance'),
            proposed_product=c.get('proposed_product', ''),
            compared_products=c.get('compared_products', ''),
            recommendation_reason=c.get('recommendation_reason', ''),
            risk_explanation=c.get('risk_explanation', ''),
            intention_initial=c.get('intention_initial', ''),
            intention_final=c.get('intention_final', ''),
        )

    created_tasks = []
    for t in (draft.tasks or []):
        from apps.tasks.models import Task
        priority_map = {'高': 1, '中': 2, '低': 3}
        created_tasks.append(Task.objects.create(
            customer=draft.customer,
            title=t.get('title', ''),
            description=t.get('description', ''),
            due_date=t.get('due_date') or None,
            priority=priority_map.get(t.get('priority', '中'), 2),
        ))

    if field('prospect_score'):
        draft.customer.prospect_score = field('prospect_score')
        draft.customer.save(update_fields=['prospect_score'])

    draft.status = 'approved'
    draft.save(update_fields=['status', 'updated_at'])

    return interview, created_tasks
