from django.db import models


class Interview(models.Model):
    OUTCOME_CHOICES = [
        ('', '─'),
        ('contracted', '成約'),
        ('followup', '継続フォロー'),
        ('proposal', '提案中'),
        ('other', 'その他'),
    ]
    CHANNEL_CHOICES = [
        ('in_person', '対面'),
        ('online', 'オンライン'),
        ('phone', '電話'),
        ('mail', 'メール'),
        ('other', 'その他'),
    ]
    MEETING_TYPE_CHOICES = [
        ('first', '初回'),
        ('hearing', 'ヒアリング'),
        ('proposal', '提案'),
        ('closing', 'クロージング'),
        ('followup', 'フォロー'),
    ]

    customer = models.ForeignKey(
        'customers.Customer', on_delete=models.CASCADE,
        related_name='interviews', verbose_name='顧客'
    )
    date = models.DateField('面談日')
    channel = models.CharField('面談様式', max_length=20, choices=CHANNEL_CHOICES, blank=True)
    meeting_type = models.CharField('面談種別', max_length=20, choices=MEETING_TYPE_CHOICES, blank=True)
    consultation_content = models.TextField('相談内容')
    proposal_content = models.TextField('提案内容', blank=True)
    outcome = models.CharField('面談結果', max_length=20, choices=OUTCOME_CHOICES, blank=True)
    NEXT_SCHEDULE_CHOICES = [
        ('scheduled', '日程あり'),
        ('undecided', '次回未定'),
        ('ended', '終了'),
    ]
    next_schedule_type = models.CharField(
        '次回区分', max_length=10, choices=NEXT_SCHEDULE_CHOICES,
        blank=True, default=''
    )
    next_schedule_date = models.DateField('次回日程', null=True, blank=True)
    next_follow_up = models.TextField('次回フォロー事項', blank=True)
    memo = models.TextField('メモ', blank=True)
    assets_status = models.TextField('保有資産状況', blank=True)
    existing_insurance = models.TextField('既契約保険状況', blank=True)
    proposal_detail = models.TextField('提案商品の詳細', blank=True)
    # 原本（証跡本体）へのリンク。面談メモPDF等の出所。source_file_idは自動取り込みの冪等キー
    source_pdf_url = models.URLField('原本PDFリンク', blank=True)
    source_file_id = models.CharField('原本ファイルID', max_length=200, blank=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date']
        verbose_name = '面談履歴'
        verbose_name_plural = '面談履歴一覧'

    def __str__(self):
        return f"{self.customer.name} - {self.date}"


class InterviewDraft(models.Model):
    """Notta議事録の自動検知から生成した面談レポートのドラフト。
    内容はスケジュールタスク側（Claude）が生成し、ここに保存するだけ。
    実際のInterview/ComplianceRecord/Task登録は、人間が確認して承認した時点で行う。"""

    STATUS_CHOICES = [
        ('pending',   '未確認'),
        ('approved',  '承認済み'),
        ('dismissed', '見送り'),
    ]

    customer = models.ForeignKey(
        'customers.Customer', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='interview_drafts', verbose_name='顧客'
    )
    candidate_name = models.CharField('顧客名（未特定時の手がかり）', max_length=100, blank=True)
    date = models.DateField('面談日')
    source_file_name = models.CharField('元ファイル名', max_length=255, blank=True)
    source_file_id = models.CharField('原本ファイルID', max_length=200, blank=True, db_index=True)

    # 面談保存コマンドと同じ構造の内容一式
    consultation_content = models.TextField('相談内容（①サマリ）', blank=True)
    proposal_content = models.TextField('提案内容', blank=True)
    memo = models.TextField('メモ（②カルテ＋③分析メモ）', blank=True)
    outcome = models.CharField('面談結果', max_length=20, blank=True)
    next_schedule_type = models.CharField('次回区分', max_length=10, blank=True, default='')
    next_schedule_date = models.DateField('次回日程', null=True, blank=True)
    next_follow_up = models.TextField('次回フォロー事項', blank=True)
    prospect_score = models.CharField('見込み度', max_length=1, blank=True)
    line_message = models.TextField('④顧客フォローLINE案', blank=True)

    # ⑤提案根拠（あれば）。api_compliance_createにそのまま渡せる形で保持
    compliance = models.JSONField('コンプラ記録案', null=True, blank=True)
    # ②の次回確認事項から起こすタスク案。[{title, description, due_date}, ...]
    tasks = models.JSONField('タスク案', default=list, blank=True)

    status = models.CharField('ステータス', max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date', '-created_at']
        verbose_name = '面談ドラフト'
        verbose_name_plural = '面談ドラフト一覧'

    def __str__(self):
        name = self.customer.name if self.customer else (self.candidate_name or '（顧客未特定）')
        return f"{name} - {self.date}"


class ComplianceRecord(models.Model):
    """対応記録＝証跡。保険（比較推奨販売＝ロ方式）・証券（適合性の原則）の両分野に対応"""

    CHECK_STATUS_CHOICES = [
        ('unchecked', '未確認'),
        ('checked', '確認済み'),
    ]
    DOMAIN_CHOICES = [
        ('insurance', '保険'),
        ('securities', '証券'),
    ]

    customer = models.ForeignKey(
        'customers.Customer', on_delete=models.CASCADE,
        related_name='compliance_records', verbose_name='顧客'
    )
    interview = models.ForeignKey(
        Interview, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='compliance_records', verbose_name='面談履歴'
    )
    date = models.DateField('記録日')
    domain = models.CharField('分野', max_length=20, choices=DOMAIN_CHOICES, default='insurance')
    applicable_framework = models.CharField('適用法令・枠組み', max_length=100, blank=True)
    proposed_product = models.TextField('提案商品', blank=True)
    compared_products = models.TextField('比較商品', blank=True)
    recommendation_reason = models.TextField('推奨理由', blank=True)
    intent_product_mapping = models.TextField('意向と提案の対応関係', blank=True)
    risk_explanation = models.TextField('リスク説明事項', blank=True)
    intention_initial = models.TextField('顧客意向（初回）', blank=True)
    intention_final = models.TextField('顧客意向（最終）', blank=True)
    intent_review = models.TextField('意向の振り返り（初回と最終の相違）', blank=True)
    intent_confirmation_method = models.CharField('意向確認の方法', max_length=50, blank=True)
    intent_confirmation_status = models.CharField('意向確認の状況', max_length=50, blank=True)
    compliance_flags = models.JSONField('コンプラフラグ', default=list, blank=True)
    check_status = models.CharField(
        '確認ステータス', max_length=20,
        choices=CHECK_STATUS_CHOICES, default='unchecked'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date']
        verbose_name = 'コンプライアンス記録'
        verbose_name_plural = 'コンプライアンス記録一覧'

    def __str__(self):
        return f"{self.customer.name} - {self.date}"
