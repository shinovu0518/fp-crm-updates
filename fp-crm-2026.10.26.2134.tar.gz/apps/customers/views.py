import json
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Count, Max, Min, OuterRef, Q, Subquery
from django.utils import timezone
from .models import Customer, CustomerRelationship, CustomerDocument, CommunicationLog
from .forms import CustomerForm


def _rep_addresses_json():
    reps = Customer.objects.filter(is_representative=True).exclude(postal_code='', address='').values('pk', 'name', 'postal_code', 'address')
    return json.dumps([
        {'pk': r['pk'], 'name': r['name'], 'postal_code': r['postal_code'] or '', 'address': r['address'] or ''}
        for r in reps
    ], ensure_ascii=False)


def _addresses_json_for(customer):
    """関連顧客（家族）の住所を返す。家族の代表者を先頭候補にする。"""
    seen = set()
    result = []

    def add(pk, name, postal_code, address):
        if pk not in seen and (postal_code or address):
            seen.add(pk)
            result.append({'pk': pk, 'name': name, 'postal_code': postal_code or '', 'address': address or ''})

    family = []
    for rel in customer.family_from.select_related('to_customer').all():
        family.append(rel.to_customer)
    for rel in customer.family_to.select_related('from_customer').all():
        family.append(rel.from_customer)

    # 家族の代表者を先頭候補にする
    for c in family:
        if c.is_representative:
            add(c.pk, c.name, c.postal_code, c.address)
    for c in family:
        add(c.pk, c.name, c.postal_code, c.address)

    return json.dumps(result, ensure_ascii=False)


def customer_list(request):
    from apps.interviews.models import Interview
    from apps.deals.models import Deal
    from django.db.models import Exists
    open_task_filter = Q(tasks__status__in=['pending', 'in_progress'])
    latest_interview = Interview.objects.filter(
        customer=OuterRef('pk')
    ).order_by('-date').values('next_schedule_type', 'next_schedule_date')[:1]
    contracted = Deal.objects.filter(customer=OuterRef('pk'), status='contracted')
    qs = Customer.objects.filter(is_archived=False).select_related('consultation_route').annotate(
        open_task_count=Count('tasks', filter=open_task_filter),
        next_task_date=Min('tasks__due_date', filter=open_task_filter),
        latest_next_type=Subquery(latest_interview.values('next_schedule_type')),
        latest_next_date=Subquery(latest_interview.values('next_schedule_date')),
        has_life=Exists(contracted.filter(company__category='life')),
        has_non_life=Exists(contracted.filter(company__category='non_life')),
        has_securities=Exists(contracted.filter(
            Q(company__category='securities') | Q(product_category__icontains='積立')
        )),
    )
    q = request.GET.get('q', '').strip()
    status = request.GET.get('status', '')
    rep = request.GET.get('rep', '1')
    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(phone__icontains=q) | Q(email__icontains=q))
    if status:
        qs = qs.filter(status=status)
    if rep == '1':
        qs = qs.filter(is_representative=True)

    sort = request.GET.get('sort', 'default')
    if sort == 'name':
        qs = qs.order_by('name_kana', 'name')
    elif sort == 'status':
        qs = qs.order_by('status', 'latest_next_date')
    else:
        # デフォルト：日程あり（近い順）→ 未定 → 終了 → 未記入、同日はタスクあり優先
        from django.db.models import Case, IntegerField, Value, When
        qs = qs.annotate(
            next_type_order=Case(
                When(latest_next_type='scheduled', then=Value(0)),
                When(latest_next_type='undecided', then=Value(1)),
                When(latest_next_type='ended',     then=Value(2)),
                default=Value(3),
                output_field=IntegerField(),
            )
        ).order_by('next_type_order', 'latest_next_date', '-open_task_count', 'name_kana')

    return render(request, 'customers/list.html', {
        'customers': qs,
        'q': q,
        'status': status,
        'rep': rep,
        'sort': sort,
        'status_choices': Customer.STATUS_CHOICES,
    })


def customer_detail(request, pk):
    from django.db.models import Count, Q, Max
    customer = get_object_or_404(
        Customer.objects.prefetch_related(
            'interviews', 'deals', 'deals__joint_companies__company', 'tasks', 'documents',
            'family_from__to_customer', 'family_to__from_customer', 'referrals'
        ).select_related('referred_by').annotate(
            open_task_count=Count('tasks', filter=Q(tasks__status__in=['pending', 'in_progress']), distinct=True),
            last_interview_date=Max('interviews__date'),
        ),
        pk=pk
    )
    from apps.deals.models import InsuranceCompany
    other_customers = Customer.objects.exclude(pk=pk).order_by('name')
    insurance_companies = InsuranceCompany.objects.all().order_by('order', 'name')
    return render(request, 'customers/detail.html', {
        'customer': customer,
        'other_customers': other_customers,
        'relation_choices': CustomerRelationship.RELATION_CHOICES,
        'relation_choices_json': json.dumps(CustomerRelationship.RELATION_CHOICES, ensure_ascii=False),
        'insurance_companies': insurance_companies,
    })


def customer_create(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save()
            messages.success(request, f'顧客「{customer.name}」を登録しました。')
            return redirect('customers:detail', pk=customer.pk)
    else:
        form = CustomerForm()
    return render(request, 'customers/form.html', {'form': form, 'action': '新規登録', 'rep_addresses_json': _rep_addresses_json()})


def _propagate_status_to_family(customer):
    """代表者のステータス変更を家族全員に伝播する"""
    if not customer.is_representative:
        return
    new_status = customer.status
    family_ids = list(
        customer.family_from.values_list('to_customer_id', flat=True)
    ) + list(
        customer.family_to.values_list('from_customer_id', flat=True)
    )
    if family_ids:
        updated = Customer.objects.filter(pk__in=family_ids).exclude(status=new_status)
        count = updated.update(status=new_status)
        return count
    return 0


def customer_edit(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            propagated = _propagate_status_to_family(customer)
            if propagated:
                messages.success(request, f'顧客「{customer.name}」の情報を更新しました。関連する{propagated}名のステータスも「{customer.get_status_display()}」に変更しました。')
            else:
                messages.success(request, f'顧客「{customer.name}」の情報を更新しました。')
            return redirect('customers:detail', pk=customer.pk)
    else:
        form = CustomerForm(instance=customer)
    # 非代表者の場合、家族内の代表者の初回面談日を取得して表示用に渡す
    rep_fid = None
    rep_name = None
    if not customer.is_representative:
        for rel in customer.family_from.select_related('to_customer').all():
            c = rel.to_customer
            if c.is_representative and c.first_interview_date:
                rep_fid = c.first_interview_date
                rep_name = c.name
                break
        if not rep_fid:
            for rel in customer.family_to.select_related('from_customer').all():
                c = rel.from_customer
                if c.is_representative and c.first_interview_date:
                    rep_fid = c.first_interview_date
                    rep_name = c.name
                    break
    return render(request, 'customers/form.html', {
        'form': form, 'customer': customer, 'action': '編集',
        'rep_addresses_json': _addresses_json_for(customer),
        'rep_first_interview_date': rep_fid,
        'rep_first_interview_name': rep_name,
    })


def customer_archive(request, pk):
    """顧客を非表示（アーカイブ）にする"""
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        customer.is_archived = True
        customer.archived_at = timezone.now()
        customer.save(update_fields=['is_archived', 'archived_at'])
        messages.success(request, f'顧客「{customer.name}」を非表示にしました。非表示リストから復元または削除できます。')
        return redirect('customers:list')
    return redirect('customers:detail', pk=pk)


def customer_restore(request, pk):
    """アーカイブ済み顧客を復元する"""
    customer = get_object_or_404(Customer, pk=pk, is_archived=True)
    if request.method == 'POST':
        customer.is_archived = False
        customer.archived_at = None
        customer.save(update_fields=['is_archived', 'archived_at'])
        messages.success(request, f'顧客「{customer.name}」を復元しました。')
    return redirect('customers:archived_list')


def customer_delete(request, pk):
    """アーカイブ済み顧客を完全削除する"""
    customer = get_object_or_404(Customer, pk=pk, is_archived=True)
    if request.method == 'POST':
        name = customer.name
        customer.delete()
        messages.success(request, f'顧客「{name}」のデータを完全に削除しました。')
        return redirect('customers:archived_list')
    return redirect('customers:archived_list')


def archived_list(request):
    """非表示顧客の一覧"""
    customers = Customer.objects.filter(is_archived=True).select_related('consultation_route').order_by('-archived_at')
    return render(request, 'customers/archived_list.html', {'customers': customers})


def family_add(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        to_id = request.POST.get('to_customer')
        relation = request.POST.get('relation')
        # メイン登録
        if to_id and relation:
            to_customer = get_object_or_404(Customer, pk=to_id)
            CustomerRelationship.objects.get_or_create(
                from_customer=customer,
                to_customer=to_customer,
                defaults={'relation': relation}
            )
            inverse = CustomerRelationship.INVERSE_RELATION.get(relation, 'other')
            CustomerRelationship.objects.get_or_create(
                from_customer=to_customer,
                to_customer=customer,
                defaults={'relation': inverse}
            )
            added = [to_customer.name]
            # 追加候補（チェックボックスで選択された同ネットワーク顧客）
            extra_ids = request.POST.getlist('extra_customers')
            for extra_id in extra_ids:
                extra = Customer.objects.filter(pk=extra_id).first()
                if not extra or extra.pk == customer.pk:
                    continue
                extra_rel = request.POST.get(f'extra_relation_{extra_id}', 'other')
                CustomerRelationship.objects.get_or_create(
                    from_customer=customer,
                    to_customer=extra,
                    defaults={'relation': extra_rel}
                )
                inv = CustomerRelationship.INVERSE_RELATION.get(extra_rel, 'other')
                CustomerRelationship.objects.get_or_create(
                    from_customer=extra,
                    to_customer=customer,
                    defaults={'relation': inv}
                )
                added.append(extra.name)
            messages.success(request, f'関連顧客を追加しました：{" / ".join(added)}')
    return redirect('customers:detail', pk=pk)


def set_referrer(request, pk):
    """顧客ページから紹介者を設定・変更・解除する。"""
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        referrer_id = request.POST.get('referred_by', '')
        if request.POST.get('clear'):
            customer.referred_by = None
        elif referrer_id.isdigit() and int(referrer_id) != customer.pk:
            customer.referred_by = get_object_or_404(Customer, pk=referrer_id)
        else:
            messages.error(request, '紹介者を一覧から選んでください')
            return redirect('customers:detail', pk=pk)
        customer.save(update_fields=['referred_by'])
        messages.success(request, '紹介者を更新しました')
    return redirect('customers:detail', pk=pk)


def family_network_api(request, pk):
    """選択した顧客の既存関連ネットワークをJSON返却（AJAX用）"""
    from django.http import JsonResponse
    customer = get_object_or_404(Customer, pk=pk)
    current_customer_pk = int(request.GET.get('current', 0))
    # すでにcurrent_customerと繋がっている人のIDセット
    existing_ids = set(
        CustomerRelationship.objects.filter(from_customer_id=current_customer_pk)
        .values_list('to_customer_id', flat=True)
    )
    existing_ids.add(current_customer_pk)
    results = []
    for rel in CustomerRelationship.objects.filter(from_customer=customer).select_related('to_customer'):
        if rel.to_customer_id in existing_ids:
            continue
        results.append({
            'id': rel.to_customer_id,
            'name': rel.to_customer.name,
            'relation': rel.relation,
            'relation_label': rel.get_relation_display(),
        })
    return JsonResponse({'network': results, 'source_name': customer.name})


def family_remove(request, pk, rel_pk):
    rel = get_object_or_404(CustomerRelationship, pk=rel_pk, from_customer_id=pk)
    to_id = rel.to_customer_id
    rel.delete()
    CustomerRelationship.objects.filter(from_customer_id=to_id, to_customer_id=pk).delete()
    return redirect('customers:detail', pk=pk)


def family_update_relation(request, pk, rel_pk):
    rel = get_object_or_404(CustomerRelationship, pk=rel_pk, from_customer_id=pk)
    if request.method == 'POST':
        new_relation = request.POST.get('relation')
        if new_relation in dict(CustomerRelationship.RELATION_CHOICES):
            rel.relation = new_relation
            rel.save(update_fields=['relation'])
            inverse = CustomerRelationship.INVERSE_RELATION.get(new_relation, 'other')
            CustomerRelationship.objects.filter(
                from_customer=rel.to_customer, to_customer_id=pk
            ).update(relation=inverse)
    return redirect('customers:detail', pk=pk)


def family_add_new(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        relation = request.POST.get('relation')
        if name and relation:
            new_customer = Customer.objects.create(
                name=name,
                name_kana=request.POST.get('name_kana', ''),
                phone=request.POST.get('phone', ''),
                dob=request.POST.get('dob') or None,
                postal_code=request.POST.get('postal_code', ''),
                address=request.POST.get('address', ''),
                is_representative=False,
            )
            CustomerRelationship.objects.create(
                from_customer=customer,
                to_customer=new_customer,
                relation=relation,
            )
            inverse = CustomerRelationship.INVERSE_RELATION.get(relation, 'other')
            CustomerRelationship.objects.create(
                from_customer=new_customer,
                to_customer=customer,
                relation=inverse,
            )
            messages.success(request, f'「{new_customer.name}」を新規登録して家族に追加しました。')
        else:
            messages.error(request, '氏名と続柄は必須です。')
    return redirect('customers:detail', pk=pk)


def document_upload(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST' and request.FILES.get('file'):
        title = request.POST.get('title', '').strip() or request.FILES['file'].name
        CustomerDocument.objects.create(customer=customer, title=title, file=request.FILES['file'])
        messages.success(request, f'「{title}」をアップロードしました。')
    return redirect('customers:detail', pk=pk)


def document_delete(request, pk, doc_pk):
    doc = get_object_or_404(CustomerDocument, pk=doc_pk, customer_id=pk)
    if request.method == 'POST':
        doc.file.delete(save=False)
        doc.delete()
        messages.success(request, 'ファイルを削除しました。')
    return redirect('customers:detail', pk=pk)


def communication_add(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        content = request.POST.get('content', '').strip()
        date = request.POST.get('date') or timezone.localdate()
        if content:
            CommunicationLog.objects.create(
                customer=customer,
                channel=request.POST.get('channel', 'line'),
                date=date,
                content=content,
            )
            messages.success(request, 'やり取りを記録しました。')
        else:
            messages.error(request, '内容は必須です。')
    return redirect('customers:detail', pk=pk)


def communication_delete(request, pk, comm_pk):
    log = get_object_or_404(CommunicationLog, pk=comm_pk, customer_id=pk)
    if request.method == 'POST':
        log.delete()
        messages.success(request, 'やり取り記録を削除しました。')
    return redirect('customers:detail', pk=pk)


def exclude_followup(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        customer.exclude_from_followup = True
        customer.save(update_fields=['exclude_from_followup'])
    next_url = request.POST.get('next_url', '/')
    return redirect(next_url)


def import_excel(request):
    result = None
    if request.method == 'POST' and request.FILES.get('file'):
        dry_run = bool(request.POST.get('dry_run'))
        result = _process_import(request.FILES['file'], dry_run)
        if not dry_run and result['deals_created']:
            messages.success(request, f"インポート完了：新規顧客 {result['new_customers']}件、契約登録 {result['deals_created']}件")
    return render(request, 'customers/import_excel.html', {'result': result})


def _parse_date(val):
    if not val:
        return None
    import datetime
    if isinstance(val, datetime.datetime):
        return val.date()
    if isinstance(val, datetime.date):
        return val
    s = str(val).strip()
    for fmt in ('%Y/%m/%d', '%Y-%m-%d', '%Y年%m月%d日', '%m/%d/%Y'):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def _parse_premium(val):
    if val is None or val == '':
        return None
    try:
        from decimal import Decimal
        cleaned = str(val).replace(',', '').replace('円', '').strip()
        if not cleaned:
            return None
        return Decimal(cleaned)
    except Exception:
        return None


PAYMENT_MAP = {
    '月払': 'monthly', '月次払': 'monthly',
    '年払': 'annual', '年次払': 'annual',
    '一時払': 'lump', '一括払': 'lump',
}

STATUS_MAP = {
    '有効': 'contracted', '契約中': 'contracted', '成約': 'contracted',
    '失効': 'lost', '解約': 'lost', '失注': 'lost',
    '推進中': 'in_progress',
}


def _process_import(file_obj, dry_run=False):
    import io
    from apps.deals.models import InsuranceCompany, Deal

    name = file_obj.name.lower()
    rows_data = []

    if name.endswith('.csv'):
        import csv
        content = file_obj.read().decode('utf-8-sig')
        reader = csv.DictReader(io.StringIO(content))
        for row in reader:
            rows_data.append(dict(row))
    else:
        try:
            import openpyxl
        except ImportError:
            return {'error': 'openpyxl がインストールされていません'}
        wb = openpyxl.load_workbook(file_obj, data_only=True)
        ws = wb.active
        headers = [str(c.value).strip() if c.value is not None else '' for c in next(ws.iter_rows(min_row=1, max_row=1))]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if all(v is None for v in row):
                continue
            rows_data.append(dict(zip(headers, row)))

    result = {
        'dry_run': dry_run,
        'new_customers': 0,
        'existing_customers': 0,
        'deals_created': 0,
        'deals_skipped': 0,
        'new_products': 0,
        'errors': [],
        'rows': [],
    }

    for i, row in enumerate(rows_data, start=2):
        row_num = i
        name_val = str(row.get('契約者名') or '').strip()
        dob_val = _parse_date(row.get('契約者生年月日'))

        if not name_val:
            result['errors'].append({'row': row_num, 'msg': '契約者名が空です'})
            continue

        company_name = str(row.get('保険会社(名称)') or row.get('保険会社') or '').strip()
        policy_number = str(row.get('証券番号') or '').strip()
        branch = str(row.get('証券番号枝番') or '').strip()
        if branch and branch != 'None':
            policy_number = f"{policy_number}-{branch}" if policy_number else branch

        row_summary = {
            'row': row_num,
            'name': name_val,
            'company': company_name,
            'policy_number': policy_number,
            'status': 'ok',
            'msg': '',
        }

        if not dry_run:
            # 顧客の get_or_create (契約者名 + 生年月日 で重複判定)
            lookup = {'name': name_val}
            if dob_val:
                lookup['dob'] = dob_val
            customer_defaults = {}
            kana = str(row.get('契約者名カナ') or '').strip()
            if kana:
                customer_defaults['name_kana'] = kana
            postal = str(row.get('郵便番号') or '').strip().replace('-', '')
            if postal:
                customer_defaults['postal_code'] = postal
            address = str(row.get('契約者住所') or '').strip()
            if address:
                customer_defaults['address'] = address
            phone = str(row.get('電話番号') or '').strip()
            if phone:
                customer_defaults['phone'] = phone
            if dob_val and 'dob' not in lookup:
                customer_defaults['dob'] = dob_val

            customer, created = Customer.objects.get_or_create(
                **lookup, defaults=customer_defaults
            )
            if created:
                result['new_customers'] += 1
            else:
                result['existing_customers'] += 1

            # 重複チェック（証券番号があれば）
            if policy_number and Deal.objects.filter(customer=customer, policy_number=policy_number).exists():
                result['deals_skipped'] += 1
                row_summary['status'] = 'skip'
                result['rows'].append(row_summary)
                continue

            # 保険会社 FK
            company_obj = None
            if company_name:
                company_obj = InsuranceCompany.objects.filter(name=company_name).first()
                if not company_obj:
                    company_obj = InsuranceCompany.objects.filter(name__icontains=company_name).first()

            # 商品（保険種類名で get_or_create）
            product_type_name = str(row.get('保険種類(名称)') or row.get('保険種類') or '').strip()
            product_obj = None
            if product_type_name and company_obj:
                from apps.deals.models import InsuranceProduct
                product_obj, prod_created = InsuranceProduct.objects.get_or_create(
                    company=company_obj,
                    name=product_type_name,
                )
                if prod_created:
                    result['new_products'] += 1

            payment_raw = str(row.get('払込方法(名称)') or row.get('払込方法') or '').strip()
            payment = PAYMENT_MAP.get(payment_raw, '')

            status_raw = str(row.get('契約状況(名称)') or row.get('契約状況') or '').strip()
            status = STATUS_MAP.get(status_raw, 'contracted')

            start_date = _parse_date(row.get('始期日'))

            Deal.objects.create(
                customer=customer,
                company=company_obj,
                company_name=company_name,
                product=product_obj,
                product_name=product_type_name,
                policy_number=policy_number,
                expected_close_month=start_date,
                payment_method=payment,
                premium=_parse_premium(row.get('合計保険料')),
                status=status,
            )
            result['deals_created'] += 1
        else:
            # dry_run: カウントのみ
            lookup = {'name': name_val}
            if dob_val:
                lookup['dob'] = dob_val
            exists = Customer.objects.filter(**lookup).exists()
            if exists:
                result['existing_customers'] += 1
            else:
                result['new_customers'] += 1

            if policy_number and exists:
                from apps.deals.models import Deal as _Deal
                customer_qs = Customer.objects.filter(**lookup)
                if _Deal.objects.filter(customer__in=customer_qs, policy_number=policy_number).exists():
                    result['deals_skipped'] += 1
                    row_summary['status'] = 'skip'
                    result['rows'].append(row_summary)
                    continue
            result['deals_created'] += 1

        result['rows'].append(row_summary)

    return result


# ── 顧客一覧のExcel・CSV取り込み／データの書き出し（data_io.py） ──

def import_customers(request):
    """顧客一覧の取り込み。ファイルを選ぶ → 確認画面で件数と中身を見る → 取り込む、の2段階"""
    from . import data_io
    plan = None
    if request.method == 'POST' and request.POST.get('confirm'):
        data = request.session.pop('customer_import_plan', None)
        if not data:
            messages.error(request, '確認画面の有効期限が切れました。もう一度ファイルを選んでください')
            return redirect('customers:import_customers')
        done = data_io.apply_customer_import(data_io.plan_from_session(data))
        messages.success(request, f"取り込みました：新しい顧客 {done['new']}件、空欄を埋めた顧客 {done['update']}件")
        return redirect('customers:list')
    if request.method == 'POST' and request.FILES.get('file'):
        try:
            headers, rows = data_io.read_table(request.FILES['file'])
            plan = data_io.plan_customer_import(headers, rows)
        except ValueError as e:
            messages.error(request, str(e))
        except Exception:
            messages.error(request, 'ファイルを読めませんでした。Excel（.xlsx）かCSVか確認してください')
        else:
            request.session['customer_import_plan'] = data_io.plan_to_session(plan)
    return render(request, 'customers/import_customers.html', {
        'plan': plan,
        'columns': data_io.CUSTOMER_COLUMNS,
    })


def _download(content, filename, content_type):
    from urllib.parse import quote
    from django.http import HttpResponse
    res = HttpResponse(content, content_type=content_type)
    res['Content-Disposition'] = f"attachment; filename*=UTF-8''{quote(filename)}"
    return res


XLSX_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'


def import_template(request):
    from . import data_io
    return _download(data_io.template_xlsx(), '顧客取り込みひな形.xlsx', XLSX_TYPE)


def export_data(request, kind):
    """書き出し：kind = customers.csv / customers.xlsx / all.xlsx"""
    from django.http import Http404
    from . import data_io
    stamp = timezone.localdate().strftime('%Y%m%d')
    if kind == 'customers.csv':
        return _download(data_io.write_csv(*data_io.customer_table()), f'顧客一覧_{stamp}.csv', 'text/csv; charset=utf-8')
    if kind == 'customers.xlsx':
        return _download(data_io.write_xlsx([('顧客',) + data_io.customer_table()]), f'顧客一覧_{stamp}.xlsx', XLSX_TYPE)
    if kind == 'all.xlsx':
        return _download(data_io.write_xlsx(data_io.export_sheets()), f'CRMデータ一式_{stamp}.xlsx', XLSX_TYPE)
    raise Http404
