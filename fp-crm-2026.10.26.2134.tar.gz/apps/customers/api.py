from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from apps.utils import json_body
from .models import Customer, ConsultationRoute, CommunicationLog


@csrf_exempt
@require_http_methods(["POST"])
def api_customer_create_or_find(request):
    data = json_body(request)
    name = data.get('name', '').strip()
    if not name:
        return JsonResponse({'error': '氏名は必須です'}, status=400)

    route_name = data.get('consultation_route', '')
    route = ConsultationRoute.objects.filter(name=route_name).first() if route_name else None

    customer, created = Customer.objects.get_or_create(
        name=name,
        defaults={
            'phone': data.get('phone', ''),
            'email': data.get('email', ''),
            'occupation': data.get('occupation', ''),
            'status': data.get('status', 'prospect'),
            'prospect_score': data.get('prospect_score', 'C'),
            'consultation_route': route,
            'notes': data.get('notes', ''),
        }
    )
    if not created:
        updated = False
        for field in ['phone', 'email', 'occupation', 'status', 'prospect_score', 'notes']:
            if field in data and data[field]:
                setattr(customer, field, data[field])
                updated = True
        if route:
            customer.consultation_route = route
            updated = True
        if updated:
            customer.save()

    return JsonResponse({
        'id': customer.pk,
        'name': customer.name,
        'created': created,
        'message': f'顧客「{customer.name}」を{"登録" if created else "更新"}しました',
    })


@csrf_exempt
@require_http_methods(["POST"])
def api_communication_create(request):
    data = json_body(request)
    customer_id = data.get('customer_id')
    content = data.get('content', '').strip()
    if not customer_id or not content:
        return JsonResponse({'error': 'customer_idとcontentは必須です'}, status=400)

    try:
        customer = Customer.objects.get(pk=customer_id)
    except Customer.DoesNotExist:
        return JsonResponse({'error': '顧客が見つかりません'}, status=404)

    log = CommunicationLog.objects.create(
        customer=customer,
        channel=data.get('channel', 'line'),
        date=data.get('date'),
        content=content,
    )
    return JsonResponse({
        'id': log.pk,
        'message': f'やり取り記録を登録しました（{customer.name}・{log.get_channel_display()}・{log.date}）',
    })


@require_http_methods(["GET"])
def api_customers_list(request):
    customers = Customer.objects.values('id', 'name', 'status', 'prospect_score', 'line_name')
    return JsonResponse({'customers': list(customers)})


@csrf_exempt
@require_http_methods(["PATCH", "POST"])
def api_customer_update(request, customer_id):
    try:
        customer = Customer.objects.get(pk=customer_id)
    except Customer.DoesNotExist:
        return JsonResponse({'error': '顧客が見つかりません'}, status=404)

    data = json_body(request)
    # only_if_empty=True のときは、既に値が入っているフィールドは上書きしない（カルテ自動追記用の安全策）
    only_if_empty = bool(data.get('only_if_empty'))
    updatable = [
        'status', 'prospect_score', 'phone', 'email', 'occupation', 'notes', 'line_name',
        'name_kana', 'postal_code', 'address', 'dob', 'workplace_memo', 'assets', 'income',
    ]
    nullable_fields = ('dob', 'assets', 'income')
    updated_fields = []
    skipped_fields = []
    for field in updatable:
        if field not in data:
            continue
        if only_if_empty and getattr(customer, field):
            skipped_fields.append(field)
            continue
        value = data[field]
        if value == '' and field in nullable_fields:
            value = None  # 空文字は数値・日付フィールドではNULL扱い
        setattr(customer, field, value)
        updated_fields.append(field)

    # notes_append: 既存の備考を消さずに追記する（面談で得た情報の積み上げ用）
    if data.get('notes_append'):
        existing = customer.notes or ''
        customer.notes = (existing + '\n' if existing else '') + data['notes_append']
        updated_fields.append('notes(追記)')

    if data.get('consultation_route'):
        route = ConsultationRoute.objects.filter(name=data['consultation_route']).first()
        if route:
            customer.consultation_route = route
            updated_fields.append('consultation_route')

    if not updated_fields:
        return JsonResponse({'error': '更新するフィールドがありません'}, status=400)

    customer.save()
    return JsonResponse({
        'id': customer.pk,
        'name': customer.name,
        'updated_fields': updated_fields,
        'skipped_fields': skipped_fields,
        'message': f'顧客「{customer.name}」を更新しました',
    })
