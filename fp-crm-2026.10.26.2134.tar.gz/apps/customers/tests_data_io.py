"""顧客一覧のExcel・CSV取り込みと、データ書き出しのテスト。"""
import datetime
import io

import openpyxl
from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase

from . import data_io
from .models import Customer


def _csv(text, enc='utf-8-sig', name='list.csv'):
    return SimpleUploadedFile(name, text.encode(enc), content_type='text/csv')


def _xlsx(rows, name='list.xlsx'):
    wb = openpyxl.Workbook()
    for r in rows:
        wb.active.append(r)
    buf = io.BytesIO()
    wb.save(buf)
    return SimpleUploadedFile(name, buf.getvalue())


class ReadAndPlanTests(TestCase):
    def test_shift_jis_csv_with_alias_headers(self):
        f = _csv('お名前,ふりがな,携帯,誕生日,職業,見込み度\n山田花子,ヤマダハナコ,09012345678,1985/4/1,会社員,B\n', enc='cp932')
        plan = data_io.plan_customer_import(*data_io.read_table(f))
        self.assertEqual(plan['counts']['new'], 1)
        v = plan['rows'][0]['values']
        self.assertEqual(v['name'], '山田花子')
        self.assertEqual(v['dob'], datetime.date(1985, 4, 1))
        self.assertEqual(v['occupation'], 'employee')
        self.assertEqual(v['prospect_score'], 'B')

    def test_xlsx_numbers_and_unused_columns(self):
        f = _xlsx([['氏名', '郵便番号', '年収', '好きな食べ物'], ['佐藤一郎', 4600001, '600万', 'カレー']])
        plan = data_io.plan_customer_import(*data_io.read_table(f))
        v = plan['rows'][0]['values']
        self.assertEqual(v['postal_code'], '4600001')
        self.assertEqual(v['income'], 600)
        self.assertEqual(plan['unused'], ['好きな食べ物'])

    def test_existing_customer_only_fills_blanks(self):
        Customer.objects.create(name='鈴木次郎', dob=datetime.date(1990, 1, 2), phone='0521111111')
        f = _csv('氏名,生年月日,電話番号,メールアドレス\n鈴木次郎,1990-01-02,0529999999,jiro@example.com\n')
        plan = data_io.plan_customer_import(*data_io.read_table(f))
        row = plan['rows'][0]
        self.assertEqual(row['action'], 'update')
        self.assertEqual(row['fills'], ['email'])
        data_io.apply_customer_import(data_io.plan_from_session(data_io.plan_to_session(plan)))
        c = Customer.objects.get(name='鈴木次郎')
        self.assertEqual(c.phone, '0521111111')  # 上書きしない
        self.assertEqual(c.email, 'jiro@example.com')
        self.assertEqual(Customer.objects.count(), 1)

    def test_row_without_name_is_not_imported(self):
        f = _csv('氏名,生年月日\n,1990-01-01\n')
        plan = data_io.plan_customer_import(*data_io.read_table(f))
        self.assertEqual(plan['counts']['error'], 1)
        self.assertEqual(data_io.apply_customer_import(plan), {'new': 0, 'update': 0})

    def test_unreadable_field_is_skipped_with_warning(self):
        f = _csv('氏名,生年月日,職業\n田中,昭和の頃,宇宙飛行士\n')
        plan = data_io.plan_customer_import(*data_io.read_table(f))
        row = plan['rows'][0]
        self.assertEqual(row['action'], 'new')
        self.assertEqual(row['values'], {'name': '田中'})
        self.assertEqual(len(row['warnings']), 2)

    def test_missing_name_column(self):
        with self.assertRaises(ValueError):
            data_io.plan_customer_import(*data_io.read_table(_csv('電話番号\n090\n')))


class ImportExportViewTests(TestCase):
    def setUp(self):
        User.objects.create_user('fp', password='pw')
        self.client.login(username='fp', password='pw')

    def test_preview_then_confirm(self):
        res = self.client.post('/customers/import/customers/', {'file': _csv('氏名,電話番号\n伊藤三郎,0901112222\n')})
        self.assertContains(res, '1件を取り込む')
        self.assertFalse(Customer.objects.exists())  # 確認画面では登録しない
        res = self.client.post('/customers/import/customers/', {'confirm': '1'})
        self.assertRedirects(res, '/customers/', fetch_redirect_response=False)
        self.assertTrue(Customer.objects.filter(name='伊藤三郎', phone='0901112222').exists())

    def test_confirm_without_preview_does_nothing(self):
        self.client.post('/customers/import/customers/', {'confirm': '1'})
        self.assertFalse(Customer.objects.exists())

    def test_export_all_xlsx_has_sheets(self):
        Customer.objects.create(name='渡辺四郎', occupation='public')
        res = self.client.get('/customers/export/all.xlsx')
        self.assertEqual(res.status_code, 200)
        wb = openpyxl.load_workbook(io.BytesIO(res.content))
        self.assertEqual(wb.sheetnames, ['顧客', '面談', '意向把握・比較推奨', '案件', 'タスク', 'やり取り'])
        ws = wb['顧客']
        headers = [c.value for c in ws[1]]
        row = dict(zip(headers, [c.value for c in ws[2]]))
        self.assertEqual(row['氏名・法人名'], '渡辺四郎')
        self.assertEqual(row['職業'], '公務員')

    def test_export_csv_opens_in_excel_and_reimports(self):
        Customer.objects.create(name='小林五郎', phone='0803334444')
        res = self.client.get('/customers/export/customers.csv')
        self.assertTrue(res.content.startswith('﻿'.encode('utf-8')))
        plan = data_io.plan_customer_import(*data_io.read_table(SimpleUploadedFile('a.csv', res.content)))
        self.assertEqual(plan['counts']['skip'], 1)  # 書き出したものを戻しても重複しない

    def test_template_and_unknown_export(self):
        self.assertEqual(self.client.get('/customers/import/template.xlsx').status_code, 200)
        self.assertEqual(self.client.get('/customers/export/secret.txt').status_code, 404)

    def test_requires_login(self):
        self.client.logout()
        self.assertEqual(self.client.get('/customers/export/all.xlsx').status_code, 302)
