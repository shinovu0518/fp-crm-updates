from django import forms
from apps.deals.forms import DateInputISO
from .models import Customer, ConsultationRoute


class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = [
            'customer_type', 'corporate_type',
            'name', 'name_kana',
            'representative_name', 'contact_name', 'contact_phone', 'contact_email',
            'phone', 'email', 'postal_code', 'address', 'dob',
            'occupation', 'workplace_memo', 'assets', 'income',
            'status', 'consultation_route', 'first_interview_date', 'notes',
            'is_representative',
        ]
        widgets = {
            'dob': DateInputISO(),
            'first_interview_date': DateInputISO(),
            'address': forms.Textarea(attrs={'rows': 2}),
            'notes': forms.Textarea(attrs={'rows': 3}),
        }
        help_texts = {
'assets': '概算で構いません（万円単位）',
            'income': '概算で構いません（万円単位）',
            'consultation_route': 'どこから知ってもらったか',
            'first_interview_date': '共同募集の場合、換算AC計算の基準日になります',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault('class', '')

    def _clean_number(self, field_name):
        from apps.utils import clean_number
        return clean_number(self.cleaned_data.get(field_name))

    def clean_assets(self):
        return self._clean_number('assets')

    def clean_income(self):
        return self._clean_number('income')
