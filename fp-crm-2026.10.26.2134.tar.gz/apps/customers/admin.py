from django.contrib import admin
from .models import Customer, CommunicationLog

admin.site.register(Customer)


@admin.register(CommunicationLog)
class CommunicationLogAdmin(admin.ModelAdmin):
    list_display = ('customer', 'channel', 'date')
    list_filter = ('channel',)
    search_fields = ('customer__name', 'content')
