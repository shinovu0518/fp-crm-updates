from django.db import models


class CoRecruiter(models.Model):
    code = models.CharField('募集人コード', max_length=50, unique=True)
    name = models.CharField('氏名', max_length=100)
    memo = models.TextField('メモ（共同募集コード等）', blank=True)

    class Meta:
        ordering = ['name']
        verbose_name = '共同募集人'
        verbose_name_plural = '共同募集人一覧'

    def __str__(self):
        return f"{self.name}（{self.code}）"


class RouteCompanyCode(models.Model):
    route = models.ForeignKey('ConsultationRoute', on_delete=models.CASCADE,
                              related_name='company_codes', verbose_name='相談経路')
    company = models.ForeignKey('deals.InsuranceCompany', on_delete=models.CASCADE,
                                verbose_name='保険会社')
    code = models.CharField('募集人コード', max_length=50)

    class Meta:
        unique_together = [('route', 'company')]
        verbose_name = '経路別保険会社コード'
        verbose_name_plural = '経路別保険会社コード'

    def __str__(self):
        return f"{self.route.name} / {self.company.name}：{self.code}"


class ConsultationRoute(models.Model):
    SOLICITATION_CHOICES = [
        ('solo',  '単独募集'),
        ('joint', '共同募集'),
    ]
    name = models.CharField('相談経路名', max_length=100)
    solicitation_type = models.CharField('募集区分', max_length=10,
                                         choices=SOLICITATION_CHOICES, default='solo')
    joint_years = models.IntegerField('共同募集期間（年）', default=2)
    co_recruiter = models.ForeignKey(CoRecruiter, null=True, blank=True,
                                     on_delete=models.SET_NULL, verbose_name='共同募集人（旧）')
    co_recruiter_name = models.CharField('共同募集人', max_length=100, blank=True)
    recruiter_code = models.CharField('募集人コード', max_length=100, blank=True)
    codes_memo = models.TextField('保険会社別コード', blank=True)
    notes = models.TextField('備考', blank=True)
    order = models.IntegerField('表示順', default=0)

    class Meta:
        ordering = ['order', 'name']
        verbose_name = '相談経路'
        verbose_name_plural = '相談経路一覧'

    def __str__(self):
        return self.name


class Customer(models.Model):
    STATUS_CHOICES = [
        ('in_progress', '推進中'),
        ('contracted',  '成約'),
        ('lost',        '失注'),
    ]
    SCORE_CHOICES = [
        ('A', 'A（最優先）'),
        ('B', 'B（優先）'),
        ('C', 'C（通常）'),
        ('D', 'D（長期）'),
    ]
    TYPE_CHOICES = [
        ('individual', '個人'),
        ('corporate',  '法人'),
    ]
    CORPORATE_TYPE_CHOICES = [
        ('kabushiki_go',  '後株（〇〇株式会社）'),
        ('kabushiki_mae', '前株（株式会社〇〇）'),
        ('godo_go',       '後合（〇〇合同会社）'),
        ('godo_mae',      '前合（合同会社〇〇）'),
        ('yugen',         '有限会社'),
        ('other',         'その他法人'),
    ]

    OCCUPATION_CHOICES = [
        ('employee',     '会社員'),
        ('executive',    '経営者・役員'),
        ('self_employed','個人事業主'),
        ('public',       '公務員'),
        ('homemaker',    '専業主婦・主夫'),
        ('part_time',    'パート・アルバイト'),
        ('student',      '学生'),
        ('pensioner',    '年金生活者'),
        ('investor',     '資産生活者'),
        ('unemployed',   '無職'),
    ]

    customer_type = models.CharField('区分', max_length=20, choices=TYPE_CHOICES, default='individual')
    corporate_type = models.CharField('法人種別', max_length=20, choices=CORPORATE_TYPE_CHOICES, blank=True)
    name = models.CharField('氏名・法人名', max_length=100)
    name_kana = models.CharField('フリガナ', max_length=100, blank=True)
    representative_name = models.CharField('代表取締役', max_length=100, blank=True)
    contact_name = models.CharField('窓口担当者', max_length=100, blank=True)
    contact_phone = models.CharField('担当者電話番号', max_length=20, blank=True)
    contact_email = models.EmailField('担当者メール', blank=True)
    phone = models.CharField('電話番号', max_length=20, blank=True)
    email = models.EmailField('メールアドレス', blank=True)
    postal_code = models.CharField('郵便番号', max_length=8, blank=True)
    address = models.TextField('住所（市区町村以降）', blank=True)
    dob = models.DateField('生年月日', null=True, blank=True)
    occupation = models.CharField('職業', max_length=30, choices=OCCUPATION_CHOICES, blank=True)
    workplace_memo = models.CharField('勤務先メモ', max_length=200, blank=True)
    assets = models.DecimalField('資産（万円）', max_digits=10, decimal_places=0, null=True, blank=True)
    income = models.DecimalField('年収（万円）', max_digits=8, decimal_places=0, null=True, blank=True)
    status = models.CharField('ステータス', max_length=20, choices=STATUS_CHOICES, default='in_progress')
    prospect_score = models.CharField('見込みスコア', max_length=10, choices=SCORE_CHOICES, default='C')
    consultation_route = models.ForeignKey('ConsultationRoute', null=True, blank=True,
                                           on_delete=models.SET_NULL, verbose_name='相談経路')
    first_interview_date = models.DateField('初回面談日', null=True, blank=True)
    referred_by = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL,
                                    related_name='referrals', verbose_name='紹介者')
    notes = models.TextField('備考', blank=True)
    is_representative = models.BooleanField(
        '代表者', default=True,
        help_text='一覧にメインで表示する顧客にチェックを入れてください'
    )
    exclude_from_followup = models.BooleanField('フォローリストから除外', default=False)
    line_name = models.CharField('LINE表示名', max_length=100, blank=True,
                                 help_text='公式LINEのトーク一覧に表示される名前（アーカイブの自動マッチに使用）')
    is_archived = models.BooleanField('非表示', default=False)
    archived_at = models.DateTimeField('非表示日時', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = '顧客'
        verbose_name_plural = '顧客一覧'

    @property
    def age(self):
        if not self.dob:
            return None
        from datetime import date
        today = date.today()
        return today.year - self.dob.year - ((today.month, today.day) < (self.dob.month, self.dob.day))

    @property
    def effective_first_interview_date(self):
        """初回面談日：自分に登録があればそれを、なければ家族内の代表者の日付を参照"""
        if self.first_interview_date:
            return self.first_interview_date
        for rel in self.family_from.select_related('to_customer').all():
            c = rel.to_customer
            if c.is_representative and c.first_interview_date:
                return c.first_interview_date
        for rel in self.family_to.select_related('from_customer').all():
            c = rel.from_customer
            if c.is_representative and c.first_interview_date:
                return c.first_interview_date
        return None

    @property
    def contract_tags(self):
        """成約済みDealから生保/損保/証券タグを返す（deals prefetch済み前提）"""
        contracted = [d for d in self.deals.all() if d.status == 'contracted']
        cats = set()
        for d in contracted:
            if d.company:
                cats.add(d.company.category)
            # 積立型商品（product_categoryに「積立」を含む）は証券扱い
            if d.product_category and '積立' in d.product_category:
                cats.add('securities')
        tags = []
        if 'life' in cats:
            tags.append(('life', '生保'))
        if 'non_life' in cats:
            tags.append(('non_life', '損保'))
        if 'securities' in cats:
            tags.append(('securities', '証券'))
        return tags

    def __str__(self):
        return self.name


class CustomerRelationship(models.Model):
    RELATION_CHOICES = [
        ('spouse', '配偶者'),
        ('child', '子'),
        ('parent', '親'),
        ('sibling', '兄弟姉妹'),
        ('other', 'その他'),
    ]
    INVERSE_RELATION = {
        'spouse': 'spouse',
        'child': 'parent',
        'parent': 'child',
        'sibling': 'sibling',
        'other': 'other',
    }
    from_customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='family_from', verbose_name='顧客')
    to_customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='family_to', verbose_name='家族')
    relation = models.CharField('続柄', max_length=20, choices=RELATION_CHOICES)

    class Meta:
        unique_together = ('from_customer', 'to_customer')
        verbose_name = '家族関係'
        verbose_name_plural = '家族関係'

    def __str__(self):
        return f"{self.from_customer.name} → {self.get_relation_display()}：{self.to_customer.name}"


class CustomerDocument(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='documents', verbose_name='顧客')
    title = models.CharField('タイトル', max_length=200)
    file = models.FileField('ファイル', upload_to='customer_docs/%Y/%m/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-uploaded_at']
        verbose_name = '契約設計書'
        verbose_name_plural = '契約設計書'

    def __str__(self):
        return f"{self.customer.name} - {self.title}"


class CommunicationLog(models.Model):
    """顧客とのやり取り記録（LINE・メール・電話のアーカイブ）"""

    CHANNEL_CHOICES = [
        ('line',  'LINE'),
        ('mail',  'メール'),
        ('phone', '電話'),
        ('other', 'その他'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE,
                                 related_name='communications', verbose_name='顧客')
    channel = models.CharField('チャネル', max_length=10, choices=CHANNEL_CHOICES, default='line')
    date = models.DateField('日付')
    content = models.TextField('内容')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date', '-created_at']
        verbose_name = 'やり取り記録'
        verbose_name_plural = 'やり取り記録一覧'

    def __str__(self):
        return f"{self.customer.name} - {self.get_channel_display()} {self.date}"
