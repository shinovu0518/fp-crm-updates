"""顧客を名前で検索して選ぶ入力欄（検索ピッカー）。

使い方（テンプレート）:
    {% load customer_picker %}
    {% customer_picker_assets %}   … ページに1回だけ。顧客の一覧データと動きのスクリプトを出す
    {% customer_picker "referred_by" placeholder="紹介者を検索" %}
    {% customer_picker "customer_id" initial=draft.matched_customer allow_new=True new_name_field="new_customer_name" new_name=draft.candidate_name %}

allow_new=True のときは、一覧にない名前を打つと「新しい顧客として登録」になり、
隠し欄の値が "new"、new_name_field に打った名前が入る。
"""
import itertools

from django import template

from apps.customers.models import Customer

register = template.Library()
_seq = itertools.count(1)


@register.inclusion_tag('components/customer_picker_assets.html')
def customer_picker_assets():
    customers = Customer.objects.filter(is_archived=False).order_by('name').values('id', 'name', 'name_kana')
    return {'picker_customers': [{'id': c['id'], 'name': c['name'], 'kana': c['name_kana']} for c in customers]}


@register.inclusion_tag('components/customer_picker.html')
def customer_picker(name, initial=None, placeholder='名前で検索', allow_new=False,
                    new_name_field='', new_name='', exclude=None):
    if initial is None and allow_new and new_name:
        value, text = 'new', new_name
    else:
        value, text = (initial.pk, initial.name) if initial else ('', '')
    return {
        'uid': f'cp{next(_seq)}', 'name': name, 'value': value, 'text': text,
        'placeholder': placeholder, 'allow_new': allow_new, 'new_name_field': new_name_field,
        'exclude': getattr(exclude, 'pk', exclude) or '',
    }
