# 外販版では中身を空にしている（自分用の取引先メモを入れるデータ移行だった）
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("customers", "0017_add_corecruiter_memo"),
    ]

    operations = []
