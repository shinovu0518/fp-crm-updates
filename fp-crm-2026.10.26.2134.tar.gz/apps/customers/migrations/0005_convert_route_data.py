from django.db import migrations

def convert_routes(apps, schema_editor):
    Customer = apps.get_model('customers', 'Customer')
    Customer.objects.filter(consultation_route='sns').update(consultation_route='other')
    Customer.objects.filter(consultation_route='walk_in').update(consultation_route='other')

class Migration(migrations.Migration):
    dependencies = [
        ('customers', '0004_change_consultation_route'),
    ]
    operations = [
        migrations.RunPython(convert_routes, migrations.RunPython.noop),
    ]
