from django.db import migrations

def convert_scores(apps, schema_editor):
    Customer = apps.get_model('customers', 'Customer')
    mapping = {'hot': 'A', 'warm': 'B', 'cold': 'C'}
    for old, new in mapping.items():
        Customer.objects.filter(prospect_score=old).update(prospect_score=new)

class Migration(migrations.Migration):
    dependencies = [
        ('customers', '0002_score_abcd'),
    ]
    operations = [
        migrations.RunPython(convert_scores, migrations.RunPython.noop),
    ]
