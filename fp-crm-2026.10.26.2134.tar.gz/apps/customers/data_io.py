"""顧客一覧のExcel・CSV取り込みと、CRMデータの書き出し。

外販版を使い始めるFPが、手元の顧客一覧をそのまま入れられること、
いつでも中身を持ち出せること（乗り換え・バックアップ・解約時）を目的にしている。
契約内容移管リストの取り込み（views._process_import）とは別物。
"""
import csv
import datetime
import io
from decimal import Decimal, InvalidOperation

from .models import Customer

# (項目名, ひな形の見出し, 見出しとして受け付ける別名)
CUSTOMER_COLUMNS = [
    ('name', '氏名', ['氏名・法人名', '名前', '顧客名', 'お名前', '契約者名', '法人名']),
    ('name_kana', 'フリガナ', ['ふりがな', 'カナ', '氏名カナ', '氏名（カナ）', 'よみがな', '契約者名カナ']),
    ('customer_type', '区分', ['個人/法人', '個人・法人']),
    ('phone', '電話番号', ['電話', 'TEL', '携帯', '携帯電話', '携帯番号']),
    ('email', 'メールアドレス', ['メール', 'Email', 'E-mail', 'mail']),
    ('postal_code', '郵便番号', ['〒']),
    ('address', '住所', ['住所（市区町村以降）', '契約者住所']),
    ('dob', '生年月日', ['誕生日', '契約者生年月日']),
    ('occupation', '職業', []),
    ('workplace_memo', '勤務先', ['勤務先メモ', '会社名']),
    ('income', '年収（万円）', ['年収']),
    ('assets', '資産（万円）', ['資産', '金融資産']),
    ('status', 'ステータス', ['状況']),
    ('prospect_score', '見込み', ['見込みスコア', '見込み度', 'ランク']),
    ('first_interview_date', '初回面談日', ['初回面談']),
    ('line_name', 'LINE表示名', ['LINE名']),
    ('notes', '備考', ['メモ', '備考欄']),
]
FIELD_LABELS = {f: h for f, h, _ in CUSTOMER_COLUMNS}
DATE_FIELDS = {'dob', 'first_interview_date'}
NUMBER_FIELDS = {'income', 'assets'}
# 表示名→保存値（「会社員」でも「employee」でも受け付ける）
CHOICE_FIELDS = {
    'customer_type': Customer.TYPE_CHOICES,
    'occupation': Customer.OCCUPATION_CHOICES,
    'status': Customer.STATUS_CHOICES,
    'prospect_score': Customer.SCORE_CHOICES,
}


def _norm_header(h):
    return str(h or '').strip().replace(' ', '').replace('　', '').lower()


HEADER_LOOKUP = {}
for _field, _header, _aliases in CUSTOMER_COLUMNS:
    for _h in [_header, _field] + _aliases:
        HEADER_LOOKUP[_norm_header(_h)] = _field


# ── 読み込み ──────────────────────────────

def read_table(file_obj):
    """Excel（.xlsx）・CSVの1枚目を [見出し], [[値...]] で返す。CSVはUTF-8とShift_JIS（Excel保存）に対応"""
    name = (file_obj.name or '').lower()
    if name.endswith('.csv'):
        raw = file_obj.read()
        for enc in ('utf-8-sig', 'cp932'):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        else:
            raise ValueError('CSVの文字コードが読めません（UTF-8かShift_JISで保存してください）')
        rows = list(csv.reader(io.StringIO(text)))
    elif name.endswith('.xlsx'):
        import openpyxl
        wb = openpyxl.load_workbook(file_obj, data_only=True, read_only=True)
        rows = [list(r) for r in wb.worksheets[0].iter_rows(values_only=True)]
    else:
        raise ValueError('.xlsx か .csv のファイルを選んでください（古い .xls はExcelで .xlsx に保存し直してください）')
    rows = [r for r in rows if any(v not in (None, '') for v in r)]
    if not rows:
        raise ValueError('ファイルに行がありません')
    return [str(h or '').strip() for h in rows[0]], rows[1:]


def map_headers(headers):
    """見出しを項目に対応づける。戻り値: (列番号→項目, 使わない見出しの一覧)"""
    mapping, unused = {}, []
    for i, h in enumerate(headers):
        field = HEADER_LOOKUP.get(_norm_header(h))
        if field and field not in mapping.values():
            mapping[i] = field
        elif h:
            unused.append(h)
    return mapping, unused


def _parse_date(val):
    if val in (None, ''):
        return None
    if isinstance(val, datetime.datetime):
        return val.date()
    if isinstance(val, datetime.date):
        return val
    s = str(val).strip()
    for fmt in ('%Y/%m/%d', '%Y-%m-%d', '%Y年%m月%d日', '%Y.%m.%d', '%Y%m%d'):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise ValueError(f'日付として読めません：{s}')


def _parse_number(val):
    if val in (None, ''):
        return None
    s = str(val).replace(',', '').replace('万円', '').replace('万', '').replace('円', '').strip()
    if not s:
        return None
    try:
        return Decimal(s).quantize(Decimal('1'))
    except InvalidOperation:
        raise ValueError(f'数字として読めません：{val}')


def _parse_choice(field, val):
    s = str(val).strip()
    for value, label in CHOICE_FIELDS[field]:
        if s in (value, label) or label.startswith(s + '（') or label.startswith(s + '('):
            return value
    raise ValueError(f'「{s}」は選べる値にありません')


def _clean(field, val):
    if field in DATE_FIELDS:
        return _parse_date(val)
    if field in NUMBER_FIELDS:
        return _parse_number(val)
    if val in (None, ''):
        return None
    if isinstance(val, float) and val.is_integer():
        val = int(val)  # Excelで数字扱いになった電話番号・郵便番号
    if field in CHOICE_FIELDS:
        return _parse_choice(field, val)
    s = str(val).strip()
    if field == 'postal_code':
        s = s.replace('-', '').replace('〒', '').strip()
    return s or None


def _find_existing(values):
    """重複判定：氏名＋生年月日 → 氏名＋電話番号 → 氏名だけ（1人に決まる時のみ）"""
    qs = Customer.objects.filter(name=values['name'])
    if values.get('dob'):
        return qs.filter(dob=values['dob']).first()
    if values.get('phone'):
        hit = qs.filter(phone=values['phone']).first()
        if hit:
            return hit
    return qs.first() if qs.count() == 1 else None


def plan_customer_import(headers, rows):
    """取り込み前の確認用に、各行をどう扱うかを決める（書き込みはしない）。

    既にいる顧客は空欄の項目だけ埋める（入っている値は上書きしない）。
    """
    mapping, unused = map_headers(headers)
    if 'name' not in mapping.values():
        raise ValueError('「氏名」の列が見つかりません（見出しを「氏名」にしてください）')
    plan = []
    for n, row in enumerate(rows, start=2):
        item = {'row': n, 'action': 'new', 'values': {}, 'fills': [], 'msg': '', 'warnings': []}
        for i, field in mapping.items():
            if i >= len(row):
                continue
            try:
                v = _clean(field, row[i])
            except ValueError as e:
                # 読めない項目だけ飛ばし、行は取り込む
                item['warnings'].append(f'{FIELD_LABELS[field]}は読めないので空のまま（{e}）')
                continue
            if v is not None:
                item['values'][field] = v
        if not item['values'].get('name'):
            item.update(action='error', msg='氏名が空です')
            plan.append(item)
            continue
        existing = _find_existing(item['values'])
        if existing:
            item['customer_id'] = existing.pk
            item['fills'] = [f for f, v in item['values'].items()
                             if f != 'name' and getattr(existing, f) in (None, '')]
            item['fill_labels'] = [FIELD_LABELS[f] for f in item['fills']]
            item['action'] = 'update' if item['fills'] else 'skip'
        plan.append(item)
    return {'mapping': {i: FIELD_LABELS[f] for i, f in mapping.items()}, 'unused': unused, 'rows': plan,
            'counts': {a: sum(1 for p in plan if p['action'] == a) for a in ('new', 'update', 'skip', 'error')}}


def apply_customer_import(plan):
    """plan_customer_import の結果を書き込む。戻り値: {'new': 件数, 'update': 件数}"""
    done = {'new': 0, 'update': 0}
    for item in plan['rows']:
        if item['action'] == 'new':
            Customer.objects.create(**item['values'])
            done['new'] += 1
        elif item['action'] == 'update':
            c = Customer.objects.get(pk=item['customer_id'])
            for f in item['fills']:
                setattr(c, f, item['values'][f])
            c.save(update_fields=item['fills'] + ['updated_at'])
            done['update'] += 1
    return done


# 確認画面からPOSTし直すまでの間、セッションに置くための変換
def plan_to_session(plan):
    def enc(v):
        if isinstance(v, datetime.date):
            return {'d': v.isoformat()}
        if isinstance(v, Decimal):
            return {'n': str(v)}
        return v
    out = dict(plan)
    out['rows'] = [dict(r, values={k: enc(v) for k, v in r['values'].items()}) for r in plan['rows']]
    return out


def plan_from_session(data):
    def dec(v):
        if isinstance(v, dict) and 'd' in v:
            return datetime.date.fromisoformat(v['d'])
        if isinstance(v, dict) and 'n' in v:
            return Decimal(v['n'])
        return v
    out = dict(data)
    out['rows'] = [dict(r, values={k: dec(v) for k, v in r['values'].items()}) for r in data['rows']]
    return out


# ── 書き出し ──────────────────────────────

def _display(obj, field):
    if field.choices:
        return getattr(obj, f'get_{field.name}_display')()
    v = getattr(obj, field.name)
    if v is None:
        return ''
    if field.is_relation:
        return str(v)
    if isinstance(v, datetime.datetime):
        return v.astimezone().strftime('%Y-%m-%d %H:%M') if v.tzinfo else v.strftime('%Y-%m-%d %H:%M')
    if isinstance(v, bool):
        return 'はい' if v else ''
    return v


def model_table(model, queryset):
    """モデルの全項目を、日本語の見出しつきの表にする（選択肢は表示名、関連は名前）"""
    fields = [f for f in model._meta.concrete_fields]
    headers = ['ID' if f.primary_key else str(f.verbose_name) for f in fields]
    rows = [[_display(obj, f) for f in fields] for obj in queryset]
    return headers, rows


def customer_table():
    return model_table(Customer, Customer.objects.select_related('consultation_route', 'referred_by').order_by('pk'))


def export_sheets():
    """全データ書き出しのシート一覧 [(シート名, 見出し, 行)]"""
    from apps.deals.models import Deal
    from apps.interviews.models import ComplianceRecord, Interview
    from apps.tasks.models import Task
    from .models import CommunicationLog
    sheets = [('顧客',) + customer_table()]
    for title, model, qs in [
        ('面談', Interview, Interview.objects.select_related('customer').order_by('pk')),
        ('意向把握・比較推奨', ComplianceRecord, ComplianceRecord.objects.select_related('customer').order_by('pk')),
        ('案件', Deal, Deal.objects.select_related('customer', 'company', 'product').order_by('pk')),
        ('タスク', Task, Task.objects.select_related('customer').order_by('pk')),
        ('やり取り', CommunicationLog, CommunicationLog.objects.select_related('customer').order_by('pk')),
    ]:
        sheets.append((title,) + model_table(model, qs))
    return sheets


def write_xlsx(sheets):
    import openpyxl
    from openpyxl.styles import Font
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for title, headers, rows in sheets:
        ws = wb.create_sheet(title)
        ws.append(headers)
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in rows:
            ws.append([v if isinstance(v, (int, float, Decimal, datetime.date)) or v == '' else str(v) for v in r])
        ws.freeze_panes = 'A2'
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def write_csv(headers, rows):
    """Excelでそのまま開けるよう、BOMつきUTF-8で書く"""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(headers)
    w.writerows(rows)
    return ('﻿' + buf.getvalue()).encode('utf-8')


def template_xlsx():
    """取り込み用のひな形（見出しだけ）"""
    return write_xlsx([('顧客', [h for _, h, _ in CUSTOMER_COLUMNS], [])])
