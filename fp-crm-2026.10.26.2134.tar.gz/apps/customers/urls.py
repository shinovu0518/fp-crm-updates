from django.urls import path
from . import views
from apps.interviews.views import InterviewCreateView

app_name = 'customers'

urlpatterns = [
    path('', views.customer_list, name='list'),
    path('new/', views.customer_create, name='create'),
    path('<int:pk>/', views.customer_detail, name='detail'),
    path('<int:pk>/edit/', views.customer_edit, name='edit'),
    path('archived/', views.archived_list, name='archived_list'),
    path('<int:pk>/archive/', views.customer_archive, name='archive'),
    path('<int:pk>/restore/', views.customer_restore, name='restore'),
    path('<int:pk>/delete/', views.customer_delete, name='delete'),
    path('<int:customer_pk>/interviews/new/', InterviewCreateView.as_view(), name='interview_create'),
    path('<int:pk>/family/add/', views.family_add, name='family_add'),
    path('<int:pk>/family/network/', views.family_network_api, name='family_network_api'),
    path('<int:pk>/family/add-new/', views.family_add_new, name='family_add_new'),
    path('<int:pk>/family/<int:rel_pk>/remove/', views.family_remove, name='family_remove'),
    path('<int:pk>/family/<int:rel_pk>/update/', views.family_update_relation, name='family_update_relation'),
    path('<int:pk>/documents/upload/', views.document_upload, name='document_upload'),
    path('<int:pk>/documents/<int:doc_pk>/delete/', views.document_delete, name='document_delete'),
    path('<int:pk>/communications/add/', views.communication_add, name='communication_add'),
    path('<int:pk>/communications/<int:comm_pk>/delete/', views.communication_delete, name='communication_delete'),
    path('<int:pk>/exclude-followup/', views.exclude_followup, name='exclude_followup'),
    path('<int:pk>/referrer/', views.set_referrer, name='set_referrer'),
    path('import/', views.import_excel, name='import_excel'),
    path('import/customers/', views.import_customers, name='import_customers'),
    path('import/template.xlsx', views.import_template, name='import_template'),
    path('export/<str:kind>', views.export_data, name='export_data'),
]
