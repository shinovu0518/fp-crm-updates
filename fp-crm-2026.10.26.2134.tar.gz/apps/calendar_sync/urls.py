from django.urls import path
from . import views

app_name = "calendar_sync"

urlpatterns = [
    path("", views.calendar_settings, name="settings"),
    path("auth/", views.auth_start, name="auth_start"),
    path("callback/", views.auth_callback, name="callback"),
    path("accounts/<int:pk>/calendars/", views.save_calendars, name="save_calendars"),
    path("accounts/<int:pk>/disconnect/", views.disconnect, name="disconnect"),
]
