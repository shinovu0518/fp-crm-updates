import os
from datetime import datetime, timedelta, timezone as dt_tz

import requests
from django.conf import settings
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build

from .models import GoogleCalendarToken

SCOPES = ["https://www.googleapis.com/auth/calendar.readonly"]
CREDENTIALS_PATH = getattr(settings, "GOOGLE_CREDENTIALS_PATH", settings.BASE_DIR / "credentials.json")
REDIRECT_URI = getattr(settings, "GOOGLE_CALENDAR_REDIRECT_URI", "http://localhost:8000/calendar/callback/")
REVOKE_URI = "https://oauth2.googleapis.com/revoke"

# ローカル（http://localhost）でのOAuthを許可し、Googleが過去に許可済みのスコープを
# 合わせて返してきても「Scope has changed」で落ちないようにする
os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"
os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"


def _get_credentials(account):
    creds = Credentials(
        token=account.access_token,
        refresh_token=account.refresh_token,
        token_uri=account.token_uri,
        client_id=account.client_id,
        client_secret=account.client_secret,
        scopes=account.scopes.split(",") if account.scopes else SCOPES,
    )
    if account.expiry:
        creds.expiry = account.expiry.replace(tzinfo=None)
    return creds


def _save_credentials(account, creds):
    expiry = None
    if creds.expiry:
        expiry = creds.expiry.replace(tzinfo=dt_tz.utc) if creds.expiry.tzinfo is None else creds.expiry
    account.access_token = creds.token
    account.refresh_token = creds.refresh_token or account.refresh_token
    account.token_uri = creds.token_uri
    account.client_id = creds.client_id
    account.client_secret = creds.client_secret
    account.scopes = ",".join(creds.scopes) if creds.scopes else ""
    account.expiry = expiry
    account.save()


def _build_service(account):
    """有効な認証情報でCalendar APIクライアントを返す。期限切れはリフレッシュする。
    リフレッシュできない（取り消し・期限切れ）場合は None。"""
    creds = _get_credentials(account)
    if not creds.valid:
        if not (creds.expired and creds.refresh_token):
            return None
        try:
            creds.refresh(Request())
        except Exception:
            return None
        _save_credentials(account, creds)
    return build("calendar", "v3", credentials=creds, cache_discovery=False)


def _account_label(account):
    return account.email or "（アカウント不明）"


def _fetch_items(user, time_min, time_max, max_results):
    """ユーザーが連携した全アカウントの選択中カレンダーから予定を集める。
    戻り値: (items, failed, any_success)。未連携なら items=None。
    同じ予定が複数カレンダーに載っている場合（招待された予定など）は1件にまとめる。"""
    accounts = list(GoogleCalendarToken.for_user(user))
    if not accounts:
        return None, [], False

    items, failed, seen = [], [], set()
    any_success = False
    for account in accounts:
        service = _build_service(account)
        if service is None:
            failed.append(_account_label(account))
            continue
        calendars = account.selected_calendars or [{"id": "primary", "summary": account.email, "color": ""}]
        for cal in calendars:
            try:
                result = service.events().list(
                    calendarId=cal["id"],
                    timeMin=time_min.isoformat(),
                    timeMax=time_max.isoformat(),
                    singleEvents=True,
                    orderBy="startTime",
                    maxResults=max_results,
                ).execute()
            except Exception:
                failed.append(f"{_account_label(account)}（{cal.get('summary') or cal['id']}）")
                continue
            any_success = True
            for item in result.get("items", []):
                if item.get("status") == "cancelled":
                    continue
                start_raw = item["start"].get("dateTime", item["start"].get("date", ""))
                key = (item.get("iCalUID") or item.get("id"), start_raw)
                if key in seen:
                    continue
                seen.add(key)
                item["_calendar"] = cal
                items.append(item)
    return items, failed, any_success


def _jst_today_start():
    import pytz
    jst = pytz.timezone("Asia/Tokyo")
    return jst, datetime.now(jst).replace(hour=0, minute=0, second=0, microsecond=0)


# ── OAuth ───────────────────────────────────────────────

def _flow(state=None):
    return Flow.from_client_secrets_file(
        str(CREDENTIALS_PATH), scopes=SCOPES, redirect_uri=REDIRECT_URI, state=state
    )


def auth_start(request):
    if not os.path.exists(CREDENTIALS_PATH):
        messages.error(request, "credentials.json がプロジェクトルートに見つかりません。Google Cloud ConsoleからOAuth認証情報をダウンロードしてください。")
        return redirect("calendar_sync:settings")
    flow = _flow()
    # select_account: 複数のGoogleアカウントを追加できるよう、毎回アカウント選択を出す
    auth_url, state = flow.authorization_url(access_type="offline", prompt="consent select_account")
    request.session["oauth_state"] = state
    request.session["oauth_code_verifier"] = flow.code_verifier
    return redirect(auth_url)


def auth_callback(request):
    if not os.path.exists(CREDENTIALS_PATH):
        messages.error(request, "credentials.json が見つかりません。")
        return redirect("calendar_sync:settings")
    if request.GET.get("error"):
        messages.error(request, f"Googleでの認証がキャンセルまたは拒否されました（{request.GET['error']}）。")
        return redirect("calendar_sync:settings")
    try:
        flow = _flow(state=request.session.pop("oauth_state", None))
        callback_url = request.build_absolute_uri()
        callback_url = callback_url.replace("http://127.0.0.1:8000", "http://localhost:8000")
        code_verifier = request.session.pop("oauth_code_verifier", None)
        flow.fetch_token(authorization_response=callback_url, code_verifier=code_verifier)
        creds = flow.credentials

        # primaryカレンダーのIDがGoogleアカウントのメールアドレスになる
        service = build("calendar", "v3", credentials=creds, cache_discovery=False)
        primary = service.calendarList().get(calendarId="primary").execute()
        email = primary["id"]

        account, created = GoogleCalendarToken.objects.get_or_create(
            user=request.user, email=email, defaults={"access_token": creds.token}
        )
        if created or not account.selected_calendars:
            account.selected_calendars = [{
                "id": "primary",
                "summary": primary.get("summary") or email,
                "color": primary.get("backgroundColor", ""),
            }]
        _save_credentials(account, creds)
        messages.success(request, f"Googleカレンダー（{email}）と連携しました。表示するカレンダーを選んでください。")
    except Exception as e:
        messages.error(request, f"認証に失敗しました: {e}")
    return redirect("calendar_sync:settings")


# ── 設定画面 ─────────────────────────────────────────────

def _calendar_list(account):
    """アカウントから見えるカレンダー一覧。取得できなければ None。"""
    service = _build_service(account)
    if service is None:
        return None
    try:
        result = service.calendarList().list(minAccessRole="reader").execute()
    except Exception:
        return None
    calendars = []
    for item in result.get("items", []):
        calendars.append({
            "id": "primary" if item.get("primary") else item["id"],
            "summary": item.get("summaryOverride") or item.get("summary") or item["id"],
            "color": item.get("backgroundColor", ""),
            "primary": bool(item.get("primary")),
        })
    calendars.sort(key=lambda c: (not c["primary"], c["summary"]))
    return calendars


def calendar_settings(request):
    accounts = []
    for account in GoogleCalendarToken.for_user(request.user):
        selected_ids = {c["id"] for c in (account.selected_calendars or [])}
        calendars = _calendar_list(account)
        if calendars is not None:
            for cal in calendars:
                cal["selected"] = cal["id"] in selected_ids
        accounts.append({"account": account, "calendars": calendars})
    return render(request, "calendar_sync/settings.html", {
        "accounts": accounts,
        "credentials_missing": not os.path.exists(CREDENTIALS_PATH),
    })


@require_POST
def save_calendars(request, pk):
    account = get_object_or_404(GoogleCalendarToken, pk=pk, user=request.user)
    calendars = _calendar_list(account)
    if calendars is None:
        messages.error(request, f"{_account_label(account)} のカレンダー一覧を取得できませんでした。再連携してください。")
        return redirect("calendar_sync:settings")
    wanted = set(request.POST.getlist("calendar_ids"))
    account.selected_calendars = [
        {"id": c["id"], "summary": c["summary"], "color": c["color"]}
        for c in calendars if c["id"] in wanted
    ]
    account.save(update_fields=["selected_calendars", "updated_at"])
    if account.selected_calendars:
        messages.success(request, f"{_account_label(account)} の表示カレンダーを保存しました。")
    else:
        messages.success(request, f"{_account_label(account)} はメインカレンダーのみ表示します（何も選択されていないため）。")
    return redirect("calendar_sync:settings")


@require_POST
def disconnect(request, pk):
    account = get_object_or_404(GoogleCalendarToken, pk=pk, user=request.user)
    label = _account_label(account)
    # Google側の許可も取り消す（失敗してもCRM側の連携解除は進める）
    try:
        requests.post(REVOKE_URI, data={"token": account.refresh_token or account.access_token}, timeout=5)
    except Exception:
        pass
    account.delete()
    messages.success(request, f"{label} の連携を解除しました。")
    return redirect("calendar_sync:settings")


# ── 予定の取得（ダッシュボード用） ─────────────────────────

def get_week_events(user):
    """今日から7日間の予定を時間軸絶対配置用のデータで返す。(data, error)
    一部のアカウントだけ失敗した場合は、取得できた分を返しつつ data['failed_accounts'] に載せる。"""
    import dateutil.parser
    import datetime as dt_mod

    GRID_START = 8   # 表示開始時刻
    GRID_END = 24    # 表示終了時刻（24時まで）
    PX_PER_HOUR = 48 # 1時間あたりのピクセル高さ

    jst, today_start = _jst_today_start()
    week_end = today_start + timedelta(days=7)
    items, failed, any_success = _fetch_items(user, today_start, week_end, max_results=200)
    if items is None:
        return None, False
    if not any_success:
        return None, True

    WEEKDAY_NAMES = ['月', '火', '水', '木', '金', '土', '日']
    day_dates = [(today_start + timedelta(days=i)).date() for i in range(7)]

    days_info = []
    for i, d in enumerate(day_dates):
        days_info.append({
            'date': d,
            'date_str': f'{d.month}/{d.day}',
            'weekday': WEEKDAY_NAMES[d.weekday()],
            'is_today': i == 0,
            'is_saturday': d.weekday() == 5,
            'is_sunday': d.weekday() == 6,
            'all_day_events': [],
            'events': [],
        })

    for item in items:
        start_raw = item["start"].get("dateTime", item["start"].get("date", ""))
        end_raw = item["end"].get("dateTime", item["end"].get("date", ""))
        is_all_day = "T" not in start_raw
        title = item.get("summary", "（タイトルなし）")
        html_link = item.get("htmlLink", "")
        location = item.get("location", "")
        cal = item["_calendar"]

        if is_all_day:
            event_date = dt_mod.date.fromisoformat(start_raw)
            if event_date in day_dates:
                d_idx = day_dates.index(event_date)
                days_info[d_idx]['all_day_events'].append({
                    'title': title, 'html_link': html_link,
                    'color': cal.get('color', ''), 'calendar_name': cal.get('summary', ''),
                })
        else:
            start_dt = dateutil.parser.parse(start_raw).astimezone(jst)
            end_dt = dateutil.parser.parse(end_raw).astimezone(jst)
            event_date = start_dt.date()
            if event_date not in day_dates:
                continue
            # グリッド範囲外は除外
            if start_dt.hour >= GRID_END or (end_dt.date() == event_date and end_dt.hour < GRID_START):
                continue
            d_idx = day_dates.index(event_date)

            # グリッド範囲にクランプして px 計算
            clamped_start_min = max((start_dt.hour - GRID_START) * 60 + start_dt.minute, 0)
            # 日付をまたぐ予定（例：23:00〜翌1:00）はその日の24:00で打ち切る
            if end_dt.date() > event_date:
                end_min = (GRID_END - GRID_START) * 60
            else:
                end_min = (end_dt.hour - GRID_START) * 60 + end_dt.minute
            clamped_end_min = min(end_min, (GRID_END - GRID_START) * 60)
            duration_min = max(clamped_end_min - clamped_start_min, 15)  # 最低15分分の高さ

            top_px = int(clamped_start_min / 60 * PX_PER_HOUR)
            height_px = max(int(duration_min / 60 * PX_PER_HOUR), 22)

            days_info[d_idx]['events'].append({
                'title': title,
                'start': start_dt.strftime('%H:%M'),
                'end': end_dt.strftime('%H:%M'),
                'html_link': html_link,
                'location': location,
                'top_px': top_px,
                'height_px': height_px,
                'color': cal.get('color', ''),
                'calendar_name': cal.get('summary', ''),
            })

    # 長い予定（居場所・訪問先などのブロック）を下、短い予定を上に重ねる。
    # TimeRexの空き枠つぶし用の長い予定に、実際の面談が隠れないようにするため
    for day in days_info:
        day['events'].sort(key=lambda e: (-e['height_px'], e['top_px']))
        for i, event in enumerate(day['events']):
            event['z_index'] = i + 1

    hours_range = list(range(GRID_START, GRID_END))
    hours_with_px = [
        {'label': f'{h:02d}:00', 'top_px': (h - GRID_START) * PX_PER_HOUR}
        for h in hours_range
    ]
    grid_total_px = (GRID_END - GRID_START) * PX_PER_HOUR

    return {
        'days': days_info,
        'hours_with_px': hours_with_px,
        'grid_total_px': grid_total_px,
        'failed_accounts': failed,
    }, False


def get_upcoming_events(user, days=14):
    """今日から days 日先までの予定をフラットなリストで返す。(events, error)
    次回フォロー予定（Interview.next_schedule_date）とGoogleカレンダーの突合に使う。
    一部でも取得に失敗したら「カレンダーに無い」と誤警告しないよう None を返す。"""
    import datetime as dt_mod
    import dateutil.parser

    jst, start = _jst_today_start()
    items, failed, _ = _fetch_items(user, start, start + timedelta(days=days), max_results=250)
    if items is None:
        return None, False
    if failed:
        return None, True

    events = []
    for item in items:
        start_raw = item["start"].get("dateTime", item["start"].get("date", ""))
        if "T" not in start_raw:
            event_date = dt_mod.date.fromisoformat(start_raw)
        else:
            event_date = dateutil.parser.parse(start_raw).astimezone(jst).date()
        events.append({
            "title": item.get("summary", "（タイトルなし）"),
            "date": event_date,
            "html_link": item.get("htmlLink", ""),
        })
    events.sort(key=lambda e: e["date"])
    return events, False


def get_today_events(user):
    import dateutil.parser

    jst, today_start = _jst_today_start()
    today_end = today_start.replace(hour=23, minute=59, second=59)
    items, failed, any_success = _fetch_items(user, today_start, today_end, max_results=20)
    if items is None:
        return None, False
    if not any_success:
        return None, True

    events = []
    for item in items:
        start = item["start"].get("dateTime", item["start"].get("date", ""))
        end = item["end"].get("dateTime", item["end"].get("date", ""))
        is_all_day = "T" not in start
        if not is_all_day:
            start_dt = dateutil.parser.parse(start).astimezone(jst)
            end_dt = dateutil.parser.parse(end).astimezone(jst)
            start_str = start_dt.strftime("%H:%M")
            end_str = end_dt.strftime("%H:%M")
        else:
            start_str = "終日"
            end_str = ""
        events.append({
            "title": item.get("summary", "（タイトルなし）"),
            "start": start_str,
            "end": end_str,
            "is_all_day": is_all_day,
            "location": item.get("location", ""),
            "description": item.get("description", ""),
            "html_link": item.get("htmlLink", ""),
        })
    # 終日を先頭に、残りは開始時刻順（複数カレンダーをまとめたため並べ直す）
    events.sort(key=lambda e: (not e["is_all_day"], e["start"]))
    return events, False
