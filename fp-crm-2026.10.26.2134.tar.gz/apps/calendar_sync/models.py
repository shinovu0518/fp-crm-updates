from django.conf import settings
from django.db import models


class GoogleCalendarToken(models.Model):
    """ログインユーザーごとに連携したGoogleアカウント1件分のトークン。
    1ユーザーが複数のGoogleアカウント（個人用・仕事用など）を連携でき、
    selected_calendars に入っているカレンダーだけを予定表示・突合に使う。"""
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True,
        related_name="google_calendar_accounts",
    )
    email = models.CharField("Googleアカウント", max_length=254, blank=True)
    # [{"id": ..., "summary": ..., "color": ...}]。空なら primary のみを読む
    selected_calendars = models.JSONField(default=list, blank=True)
    access_token = models.TextField()
    refresh_token = models.TextField(blank=True)
    token_uri = models.TextField(default="https://oauth2.googleapis.com/token")
    client_id = models.TextField(blank=True)
    client_secret = models.TextField(blank=True)
    scopes = models.TextField(blank=True)
    expiry = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Googleカレンダートークン"
        constraints = [
            models.UniqueConstraint(fields=["user", "email"], name="unique_calendar_account_per_user"),
        ]

    def __str__(self):
        return f"GoogleCalendarToken ({self.email or '未取得'})"

    @classmethod
    def for_user(cls, user):
        if not user or not user.is_authenticated:
            return cls.objects.none()
        return cls.objects.filter(user=user).order_by("id")
