from django.db import models


class PlanRequest(models.Model):
    """夜のブリーフィングで送った「明日やることは？」の問いかけ。
    返信の「1と3」などの番号は、この candidate_task_ids の並び順（1始まり）に対応する。"""
    target_date = models.DateField('対象日')
    candidate_task_ids = models.JSONField('候補タスクID', default=list)
    message = models.TextField('送信内容')
    sent_at = models.DateTimeField('送信日時', auto_now_add=True)

    class Meta:
        ordering = ['-sent_at']
        verbose_name = '明日やることの問いかけ'

    def __str__(self):
        return f'{self.target_date} の問いかけ'


class PlanReply(models.Model):
    """本人からのLINE返信と、AIによる解釈・CRMへの反映結果の記録。"""
    STATUS_CHOICES = [
        ('applied', '反映済み'),
        ('nothing', '反映なし'),
        ('failed', '失敗'),
    ]
    plan_request = models.ForeignKey(PlanRequest, on_delete=models.SET_NULL, null=True, blank=True, related_name='replies')
    text = models.TextField('受信内容')
    interpretation = models.JSONField('解釈結果', default=dict, blank=True)
    result_message = models.TextField('返信内容', blank=True)
    status = models.CharField('状態', max_length=20, choices=STATUS_CHOICES, default='nothing')
    error = models.TextField('エラー', blank=True)
    received_at = models.DateTimeField('受信日時', auto_now_add=True)

    class Meta:
        ordering = ['-received_at']
        verbose_name = 'LINE返信の反映履歴'

    def __str__(self):
        return f'{self.received_at:%Y-%m-%d %H:%M} {self.get_status_display()}'
