import json
import threading

from django.db import close_old_connections
from django.http import HttpResponse, HttpResponseForbidden, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from . import line_api
from .models import PlanRequest
from .planner import build_plan_request, handle_message


def _process(text, reply_token):
    close_old_connections()
    try:
        line_api.reply_or_push(reply_token, handle_message(text))
    finally:
        close_old_connections()


@csrf_exempt
@require_http_methods(["POST"])
def webhook(request):
    """LINE公式アカウントのWebhook。本人（LINE_PUSH_USER_ID）からのテキストだけを処理する。
    顧客からのメッセージも届くが、ここでは一切保存・処理しない。"""
    if not line_api.verify_signature(request.body, request.headers.get('X-Line-Signature', '')):
        return HttpResponseForbidden('invalid signature')

    try:
        events = json.loads(request.body.decode('utf-8')).get('events', [])
    except ValueError:
        return HttpResponse(status=400)

    owner = line_api.owner_user_id()
    for event in events:
        if event.get('type') != 'message' or event.get('message', {}).get('type') != 'text':
            continue
        if not owner or event.get('source', {}).get('userId') != owner:
            continue
        # LINEは数秒以内の応答を求めるため、AIの解釈は別スレッドで行い、すぐ200を返す
        threading.Thread(
            target=_process,
            args=(event['message']['text'], event.get('replyToken')),
            daemon=True,
        ).start()
    return HttpResponse('OK')


@csrf_exempt
@require_http_methods(["POST"])
def api_plan_ask(request):
    """夜のブリーフィングから呼ぶ：「明日やることは？」を候補付きでLINE送信し、候補の並びを記録する。
    dry_run=true なら送信・記録せず文面だけ返す。"""
    try:
        data = json.loads(request.body or b'{}')
    except ValueError:
        data = {}
    target, candidates, message = build_plan_request()
    if data.get('dry_run'):
        return JsonResponse({'target_date': target.isoformat(), 'message': message, 'sent': False})

    if not line_api.push(message):
        return JsonResponse({'error': 'LINE送信に失敗しました', 'message': message}, status=502)
    req = PlanRequest.objects.create(
        target_date=target,
        candidate_task_ids=[t.pk for t in candidates],
        message=message,
    )
    return JsonResponse({'id': req.pk, 'target_date': target.isoformat(), 'message': message, 'sent': True})
