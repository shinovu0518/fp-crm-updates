from django.urls import path
from . import views

app_name = "line_bot"

urlpatterns = [
    path("line/webhook/", views.webhook, name="webhook"),
    path("api/planning/ask/", views.api_plan_ask, name="api_plan_ask"),
]
