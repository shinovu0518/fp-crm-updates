"""「明日やること」の問いかけと、LINE返信（音声入力の文章）をタスク操作に変換して反映する処理。"""
import json
from datetime import date, datetime, timedelta

import anthropic
import pytz
from django.db import transaction

from apps.customers.models import Customer
from apps.tasks.models import Task

from .models import PlanReply, PlanRequest

JST = pytz.timezone('Asia/Tokyo')
MODEL = 'claude-opus-5-5'
CANDIDATE_LIMIT = 8
WEEKDAYS = ['月', '火', '水', '木', '金', '土', '日']
PRIORITY_MAP = {'高': 1, '中': 2, '低': 3}


def now_jst():
    return datetime.now(JST)


def fmt_date(d):
    return f'{d.month}/{d.day}（{WEEKDAYS[d.weekday()]}）'


def _open_tasks():
    return Task.objects.exclude(status__in=['completed', 'cancelled']).select_related('customer')


def _task_label(task):
    return f'{task.customer.name}様 {task.title}' if task.customer else task.title


def _task_reason(task, target):
    if task.planned_date == target:
        return 'やる日に設定済み'
    if task.due_date:
        if task.due_date < target:
            return f'期限切れ{(target - task.due_date).days}日'
        if task.due_date == target:
            return '当日期限'
        return f'期限{fmt_date(task.due_date)}'
    return '期日なし'


# ── 問いかけ ──────────────────────────────────────────────

def plan_candidates(target):
    """対象日にやる候補：やる日設定済み→期限切れ→当日期限→1週間以内の期限→期日なしの高優先度。"""
    active = _open_tasks()
    ordered, seen = [], set()

    def add(qs):
        for t in qs:
            if t.pk not in seen and len(ordered) < CANDIDATE_LIMIT:
                seen.add(t.pk)
                ordered.append(t)

    add(active.filter(planned_date=target).order_by('priority'))
    # 別の日にやると決めてあるもの（対象日より後）は候補から外す
    pending = active.exclude(planned_date__gt=target)
    add(pending.filter(due_date__lt=target).order_by('due_date', 'priority'))
    add(pending.filter(due_date=target).order_by('priority'))
    add(pending.filter(due_date__gt=target, due_date__lte=target + timedelta(days=7)).order_by('due_date', 'priority'))
    add(pending.filter(due_date__isnull=True, priority=1).order_by('created_at'))
    return ordered


def build_plan_request(target=None):
    target = target or (now_jst().date() + timedelta(days=1))
    candidates = plan_candidates(target)
    lines = [f'【{fmt_date(target)}にやることは？】']
    if candidates:
        for i, t in enumerate(candidates, 1):
            lines.append(f'{i}. {_task_label(t)}（{_task_reason(t, target)}）')
        lines.append('')
        lines.append('やるものの番号と、新しく増えたことを話しかける感じで返信してください。')
        lines.append('例：「1と3。あと田中様に保険証券のコピー依頼」')
    else:
        lines.append('期限が近いタスクはありません。やることがあれば、そのまま返信してください。')
    return target, candidates, '\n'.join(lines)


# ── 返信の解釈（Claude） ─────────────────────────────────────

SYSTEM_PROMPT = """あなたはFP・IFA（保険・資産運用の個人向けアドバイザー）の秘書「DONNA」です。
本人からLINEで届いたメッセージを読み、CRMのタスク操作に変換します。

メッセージは音声入力で書かれているため、誤変換・句読点の欠落・言い直しが含まれます。意図を汲んで読み取ってください。
数字は「いち」「1番」「一つ目」のように書かれることもあります。

ルール:
- 番号は、直近の問いかけ（latest_request）の候補リストの番号です
- 「明日」「明後日」「来週月曜」などは now を基準に日付（YYYY-MM-DD）へ変換します
- やる日の指定がなければ、latest_request の target_date をやる日にします。問いかけが無い・古い場合は now の翌日にします
- 既存タスク（open_tasks）と同じ内容なら新規作成せず、その task_id を plan に入れます
- 顧客名が出てきたら customers から該当者の id を選びます（敬称や誤変換を考慮）。確信が持てなければ null にします
- 「終わった」「済んだ」「完了」は complete に入れます
- 「〇〇はやめ」「やっぱり外して」は unplan（やる日を外すだけで、タスクは消しません）
- 新規タスクのタイトルは簡潔な体言止めにします（例：「保険証券のコピー依頼」）。顧客名はタイトルに入れず customer_id で紐づけます
- タスクと関係ない内容や、自信を持って解釈できない部分は、どの操作にも入れず unclear に短く書きます（実行しない方が安全です）
- 本人の発言にない操作は作りません"""

_NULLABLE_INT = {'anyOf': [{'type': 'integer'}, {'type': 'null'}]}
_NULLABLE_DATE = {'anyOf': [{'type': 'string', 'description': 'YYYY-MM-DD'}, {'type': 'null'}]}

OUTPUT_SCHEMA = {
    'type': 'object',
    'properties': {
        'plan': {
            'type': 'array',
            'description': '既存タスクにやる日を設定する',
            'items': {
                'type': 'object',
                'properties': {
                    'task_id': {'type': 'integer'},
                    'planned_date': {'type': 'string', 'description': 'YYYY-MM-DD'},
                },
                'required': ['task_id', 'planned_date'],
                'additionalProperties': False,
            },
        },
        'create': {
            'type': 'array',
            'description': '新しいタスクを作る',
            'items': {
                'type': 'object',
                'properties': {
                    'title': {'type': 'string'},
                    'customer_id': _NULLABLE_INT,
                    'planned_date': _NULLABLE_DATE,
                    'due_date': _NULLABLE_DATE,
                    'priority': {'type': 'string', 'enum': ['高', '中', '低']},
                    'description': {'type': 'string'},
                },
                'required': ['title', 'customer_id', 'planned_date', 'due_date', 'priority', 'description'],
                'additionalProperties': False,
            },
        },
        'complete': {'type': 'array', 'description': '完了にする既存タスクのID', 'items': {'type': 'integer'}},
        'unplan': {'type': 'array', 'description': 'やる日を外す既存タスクのID', 'items': {'type': 'integer'}},
        'unclear': {'type': 'string', 'description': '解釈できなかった・実行しなかった内容。なければ空文字'},
    },
    'required': ['plan', 'create', 'complete', 'unplan', 'unclear'],
    'additionalProperties': False,
}


def _latest_request():
    req = PlanRequest.objects.first()
    # 2日以上前の問いかけは番号の対応が当てにならないので使わない
    if req and req.sent_at >= now_jst() - timedelta(days=2):
        return req
    return None


def _context(text, req):
    open_tasks = list(_open_tasks().order_by('due_date', 'priority')[:150])
    by_id = {t.pk: t for t in open_tasks}
    latest = None
    if req:
        latest = {
            'target_date': req.target_date.isoformat(),
            'candidates': [
                {'number': i, 'task_id': tid, 'label': _task_label(by_id[tid]) if tid in by_id else '（完了済み・削除済み）'}
                for i, tid in enumerate(req.candidate_task_ids, 1)
            ],
        }
    return {
        'now': now_jst().strftime('%Y-%m-%d %H:%M (%a)'),
        'latest_request': latest,
        'open_tasks': [
            {
                'task_id': t.pk,
                'title': t.title,
                'customer': t.customer.name if t.customer else None,
                'due_date': t.due_date.isoformat() if t.due_date else None,
                'planned_date': t.planned_date.isoformat() if t.planned_date else None,
            }
            for t in open_tasks
        ],
        'customers': [{'id': c.pk, 'name': c.name} for c in Customer.objects.filter(is_archived=False).order_by('pk')],
        'message': text,
    }


def interpret(text, req):
    client = anthropic.Anthropic()
    response = client.beta.messages.create(
        model=MODEL,
        max_tokens=16000,
        betas=['server-side-fallback-2026-07-01'],
        fallbacks='default',
        output_config={
            'effort': 'medium',
            'format': {'type': 'json_schema', 'schema': OUTPUT_SCHEMA},
        },
        system=SYSTEM_PROMPT,
        messages=[{
            'role': 'user',
            'content': json.dumps(_context(text, req), ensure_ascii=False),
        }],
    )
    if response.stop_reason == 'refusal':
        raise RuntimeError('AIが解釈を辞退しました')
    if response.stop_reason == 'max_tokens':
        raise RuntimeError('AIの出力が途中で切れました')
    body = next((b.text for b in response.content if b.type == 'text'), '')
    return json.loads(body)


# ── 反映 ─────────────────────────────────────────────────

def _parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return None


@transaction.atomic
def apply(result):
    """AIの解釈結果をCRMに反映する。存在しないID・不正な日付は反映せず notes に残す。"""
    open_by_id = {t.pk: t for t in _open_tasks()}
    planned, created, completed, unplanned, notes = [], [], [], [], []

    for item in result.get('plan', []):
        task = open_by_id.get(item.get('task_id'))
        d = _parse_date(item.get('planned_date'))
        if not task or not d:
            notes.append(f'タスクID {item.get("task_id")} は見つからないため反映していません')
            continue
        task.planned_date = d
        task.save(update_fields=['planned_date', 'updated_at'])
        planned.append(task)

    for item in result.get('create', []):
        title = (item.get('title') or '').strip()
        if not title:
            continue
        customer = None
        if item.get('customer_id'):
            customer = Customer.objects.filter(pk=item['customer_id']).first()
        task = Task.objects.create(
            title=title[:200],
            customer=customer,
            description=item.get('description', ''),
            planned_date=_parse_date(item.get('planned_date')),
            due_date=_parse_date(item.get('due_date')),
            priority=PRIORITY_MAP.get(item.get('priority'), 2),
        )
        created.append(task)

    for task_id in result.get('complete', []):
        task = open_by_id.get(task_id)
        if not task:
            continue
        task.status = 'completed'
        task.save(update_fields=['status', 'updated_at'])
        completed.append(task)

    for task_id in result.get('unplan', []):
        task = open_by_id.get(task_id)
        if not task or task in completed:
            continue
        task.planned_date = None
        task.save(update_fields=['planned_date', 'updated_at'])
        unplanned.append(task)

    return {'planned': planned, 'created': created, 'completed': completed, 'unplanned': unplanned, 'notes': notes}


def format_result(applied, unclear):
    by_date = {}
    for t in applied['planned'] + [t for t in applied['created'] if t.planned_date]:
        by_date.setdefault(t.planned_date, []).append(t)

    lines = []
    for d in sorted(by_date):
        lines.append(f'【{fmt_date(d)}にやること】')
        for t in by_date[d]:
            mark = '（新規）' if t in applied['created'] else ''
            lines.append(f'・{mark}{_task_label(t)}')
    undated = [t for t in applied['created'] if not t.planned_date]
    if undated:
        lines.append('【タスクに追加（やる日なし）】')
        lines += [f'・{_task_label(t)}' for t in undated]
    if applied['completed']:
        lines.append('【完了にしました】')
        lines += [f'・{_task_label(t)}' for t in applied['completed']]
    if applied['unplanned']:
        lines.append('【やる日を外しました】')
        lines += [f'・{_task_label(t)}' for t in applied['unplanned']]

    if lines:
        lines.insert(0, 'セットしました。')
    else:
        lines.append('タスクとして反映できる内容が見つかりませんでした。')
    notes = applied['notes'] + ([unclear] if unclear else [])
    if notes:
        lines.append('')
        lines.append('※ 反映していないこと：' + ' / '.join(notes))
    lines.append('')
    lines.append('違っていたら、直したい内容をそのまま返信してください。')
    return '\n'.join(lines)


def handle_message(text):
    """返信1通を解釈→反映し、LINEで返す文面を返す。結果は PlanReply に記録する。"""
    req = _latest_request()
    log = PlanReply.objects.create(plan_request=req, text=text)
    try:
        result = interpret(text, req)
        applied = apply(result)
        message = format_result(applied, result.get('unclear', '').strip())
        log.interpretation = result
        log.status = 'applied' if any(applied[k] for k in ('planned', 'created', 'completed', 'unplanned')) else 'nothing'
        log.result_message = message
        log.save()
        return message
    except Exception as e:
        log.status = 'failed'
        log.error = f'{type(e).__name__}: {e}'
        log.save()
        return 'ごめんなさい、うまく読み取れませんでした。少し時間をおいてもう一度送るか、CRMのタスク画面から登録してください。'
