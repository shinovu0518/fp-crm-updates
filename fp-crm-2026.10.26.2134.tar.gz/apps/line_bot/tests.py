"""LINE返信で「明日やること」を反映する仕組みのテスト。AI呼び出しとLINE送信はモックする。"""
import base64
import hashlib
import hmac
import json
import os
from datetime import date, timedelta
from unittest import mock

from django.contrib.auth.models import User
from django.test import TestCase, override_settings

from apps.customers.models import Customer
from apps.dashboard.views import _today_plan, _top_tasks
from apps.tasks.models import Task

from . import views
from .models import PlanReply, PlanRequest
from .planner import apply, format_result, handle_message, plan_candidates

TODAY = date.today()
TOMORROW = TODAY + timedelta(days=1)
SECRET = 'test-secret'
OWNER = 'Uowner'
ENV = {'LINE_CHANNEL_SECRET': SECRET, 'LINE_PUSH_USER_ID': OWNER, 'LINE_CHANNEL_ACCESS_TOKEN': 'x'}


def _sign(body):
    return base64.b64encode(hmac.new(SECRET.encode(), body, hashlib.sha256).digest()).decode()


def _event(user_id, text='1と3'):
    return {'events': [{
        'type': 'message', 'replyToken': 'rt',
        'source': {'userId': user_id},
        'message': {'type': 'text', 'text': text},
    }]}


@mock.patch.dict(os.environ, ENV)
@override_settings(PERSONAL_FEATURES=True)
class WebhookTests(TestCase):
    def _post(self, payload, signature=None):
        body = json.dumps(payload).encode()
        return self.client.post('/line/webhook/', data=body, content_type='application/json',
                                HTTP_X_LINE_SIGNATURE=signature if signature is not None else _sign(body))

    def test_rejects_bad_signature_without_login(self):
        self.assertEqual(self._post(_event(OWNER), signature='bad').status_code, 403)

    @mock.patch.object(views.threading, 'Thread')
    def test_only_owner_messages_are_processed(self, thread):
        self.assertEqual(self._post(_event('Ucustomer')).status_code, 200)
        thread.assert_not_called()
        self.assertEqual(self._post(_event(OWNER)).status_code, 200)
        thread.assert_called_once()
        self.assertEqual(thread.call_args.kwargs['args'], ('1と3', 'rt'))


class PlannerTests(TestCase):
    def setUp(self):
        self.c = Customer.objects.create(name='田中一郎')
        self.overdue = Task.objects.create(title='設計書送付', customer=self.c, due_date=TODAY - timedelta(days=2))
        self.due_tomorrow = Task.objects.create(title='日程調整', due_date=TOMORROW)
        self.later = Task.objects.create(title='来週の件', due_date=TOMORROW + timedelta(days=3),
                                         planned_date=TOMORROW + timedelta(days=2))
        self.far = Task.objects.create(title='来月の件', due_date=TODAY + timedelta(days=40))

    def test_candidates_order_and_exclusions(self):
        ids = [t.pk for t in plan_candidates(TOMORROW)]
        self.assertEqual(ids, [self.overdue.pk, self.due_tomorrow.pk])  # 先の日に予定済み・遠い期限は除外

    def test_apply_plan_create_complete_and_ignore_unknown(self):
        result = {
            'plan': [{'task_id': self.overdue.pk, 'planned_date': TOMORROW.isoformat()},
                     {'task_id': 99999, 'planned_date': TOMORROW.isoformat()}],
            'create': [{'title': '保険証券のコピー依頼', 'customer_id': self.c.pk, 'planned_date': TOMORROW.isoformat(),
                        'due_date': None, 'priority': '高', 'description': ''}],
            'complete': [self.due_tomorrow.pk],
            'unplan': [self.later.pk],
            'unclear': '',
        }
        applied = apply(result)
        self.overdue.refresh_from_db(); self.due_tomorrow.refresh_from_db(); self.later.refresh_from_db()
        self.assertEqual(self.overdue.planned_date, TOMORROW)
        self.assertEqual(self.due_tomorrow.status, 'completed')
        self.assertIsNone(self.later.planned_date)
        new = Task.objects.get(title='保険証券のコピー依頼')
        self.assertEqual((new.customer, new.planned_date, new.priority), (self.c, TOMORROW, 1))
        self.assertEqual(len(applied['notes']), 1)
        msg = format_result(applied, '')
        self.assertIn('（新規）田中一郎様 保険証券のコピー依頼', msg)
        self.assertIn('反映していないこと', msg)

    @mock.patch('apps.line_bot.planner.interpret', side_effect=RuntimeError('boom'))
    def test_failure_is_logged_and_nothing_changes(self, _):
        msg = handle_message('1')
        self.assertIn('うまく読み取れませんでした', msg)
        self.assertEqual(PlanReply.objects.get().status, 'failed')
        self.overdue.refresh_from_db()
        self.assertIsNone(self.overdue.planned_date)


@override_settings(API_TOKEN='testtoken', PERSONAL_FEATURES=True)
@mock.patch.dict(os.environ, ENV)
class PlanAskApiTests(TestCase):
    def setUp(self):
        Task.objects.create(title='日程調整', due_date=TOMORROW)

    def test_requires_token(self):
        self.assertEqual(self.client.post('/api/planning/ask/').status_code, 401)

    @mock.patch('apps.line_bot.line_api.push', return_value=True)
    def test_sends_and_records_candidates(self, push):
        resp = self.client.post('/api/planning/ask/', data='{}', content_type='application/json',
                                HTTP_X_API_TOKEN='testtoken')
        self.assertEqual(resp.status_code, 200)
        push.assert_called_once()
        self.assertIn('1. 日程調整', push.call_args.args[0])
        self.assertEqual(PlanRequest.objects.get().target_date, TOMORROW)

    @mock.patch('apps.line_bot.line_api.push')
    def test_dry_run_does_not_send(self, push):
        self.client.post('/api/planning/ask/', data='{"dry_run": true}', content_type='application/json',
                         HTTP_X_API_TOKEN='testtoken')
        push.assert_not_called()
        self.assertFalse(PlanRequest.objects.exists())


class DashboardPlanTests(TestCase):
    def setUp(self):
        self.today = Task.objects.create(title='今日やる', planned_date=TODAY)
        self.carry = Task.objects.create(title='持ち越し', planned_date=TODAY - timedelta(days=1))
        self.future = Task.objects.create(title='明日やる', planned_date=TOMORROW, due_date=TODAY + timedelta(days=5))
        self.overdue_future = Task.objects.create(title='期限切れだが明日やる', planned_date=TOMORROW,
                                                  due_date=TODAY - timedelta(days=1))

    def test_today_plan_and_top_tasks_split(self):
        plan = _today_plan(TODAY)
        self.assertEqual([t.title for t in plan], ['持ち越し', '今日やる'])
        self.assertEqual(plan[0].plan_label, '1日前から持ち越し')
        top = [t.title for t in _top_tasks(TODAY, limit=10, exclude_ids=[t.pk for t in plan])]
        self.assertNotIn('今日やる', top)
        self.assertNotIn('明日やる', top)          # 先の日に予定済みは出さない
        self.assertIn('期限切れだが明日やる', top)  # 期限切れは残す

    def test_dashboard_renders_section(self):
        user = User.objects.create_user('u', password='p')
        self.client.force_login(user)
        html = self.client.get('/').content.decode()
        self.assertIn('今日やること', html)
        self.assertIn('ほかに気にしておくこと', html)
