from django.contrib import admin

from .models import PlanReply, PlanRequest


@admin.register(PlanRequest)
class PlanRequestAdmin(admin.ModelAdmin):
    list_display = ('target_date', 'sent_at')


@admin.register(PlanReply)
class PlanReplyAdmin(admin.ModelAdmin):
    list_display = ('received_at', 'status', 'text')
    list_filter = ('status',)
