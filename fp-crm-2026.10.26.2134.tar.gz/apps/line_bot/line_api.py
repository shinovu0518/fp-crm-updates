"""LINE Messaging API の薄いラッパー（署名検証・返信・push）。"""
import base64
import hashlib
import hmac
import os

import requests

# LINEのiconUrlはリダイレクトなしで直接返るHTTPSのPNG（1:1・1MB以下）である必要がある。
# Driveの uc?export=view はリダイレクト＋JPEGになるため、lh3の画像配信URL（PNG変換）を使う
DONNA_SENDER = {
    'name': 'DONNA',
    'iconUrl': 'https://lh3.googleusercontent.com/d/1LklPoxCelmkHSM6NB2m_nZD7dxnf2SQt=s256-rp',
}
MAX_TEXT = 5000  # LINEのテキストメッセージ上限


def _token():
    return os.environ.get('LINE_CHANNEL_ACCESS_TOKEN', '')


def owner_user_id():
    return os.environ.get('LINE_PUSH_USER_ID', '')


def verify_signature(body: bytes, signature: str) -> bool:
    secret = os.environ.get('LINE_CHANNEL_SECRET', '')
    if not secret or not signature:
        return False
    digest = hmac.new(secret.encode('utf-8'), body, hashlib.sha256).digest()
    return hmac.compare_digest(base64.b64encode(digest).decode('utf-8'), signature)


def _message(text):
    return {'type': 'text', 'text': text[:MAX_TEXT], 'sender': DONNA_SENDER}


def _post(url, payload):
    resp = requests.post(
        url,
        json=payload,
        headers={'Authorization': f'Bearer {_token()}'},
        timeout=10,
    )
    return resp.status_code == 200


def reply(reply_token, text):
    """replyTokenで返信（無料枠を消費しない）。失敗したら False。"""
    if not reply_token:
        return False
    return _post('https://api.line.me/v2/bot/message/reply',
                 {'replyToken': reply_token, 'messages': [_message(text)]})


def push(text, to=None):
    return _post('https://api.line.me/v2/bot/message/push',
                 {'to': to or owner_user_id(), 'messages': [_message(text)]})


def reply_or_push(reply_token, text):
    # AIの解釈に時間がかかってreplyTokenが失効していたらpushで送る
    return reply(reply_token, text) or push(text)
