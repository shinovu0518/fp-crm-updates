import json
from decimal import Decimal, InvalidOperation


def json_body(request):
    """リクエストボディをJSONとして読む。失敗時は空dict。"""
    try:
        return json.loads(request.body)
    except Exception:
        return {}


def clean_number(val):
    """カンマ・全角数字を正規化して Decimal に変換する。変換不能な場合は元の値を返す。"""
    if val is None:
        return val
    s = str(val).translate(str.maketrans('０１２３４５６７８９', '0123456789')).replace(',', '').replace('，', '')
    try:
        return Decimal(s)
    except (InvalidOperation, ValueError):
        return val
