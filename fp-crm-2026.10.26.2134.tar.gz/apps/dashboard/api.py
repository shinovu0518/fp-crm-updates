from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from apps.utils import json_body
from apps.customers.models import Customer
from .models import FollowUpSuggestion, BriefingLog


@csrf_exempt
@require_http_methods(["POST"])
def api_followup_suggestion_create(request):
    data = json_body(request)
    customer_id = data.get('customer_id')
    line_message = data.get('line_message', '').strip()
    if not customer_id or not line_message:
        return JsonResponse({'error': 'customer_idとline_messageは必須です'}, status=400)

    try:
        customer = Customer.objects.get(pk=customer_id)
    except Customer.DoesNotExist:
        return JsonResponse({'error': '顧客が見つかりません'}, status=404)

    # 送信トレイは一時置き場。同一顧客の古い未送信下書きは削除して最新1件だけ残す
    FollowUpSuggestion.objects.filter(customer=customer, status='pending').delete()

    suggestion = FollowUpSuggestion.objects.create(
        customer=customer,
        reason=data.get('reason', ''),
        line_message=line_message,
    )
    return JsonResponse({
        'id': suggestion.pk,
        'message': f'フォロー提案を登録しました（{customer.name}）',
    })


@csrf_exempt
@require_http_methods(["POST"])
def api_briefing_log_create(request):
    """朝/夜のブリーフィングで実際にLINE送信した内容の履歴を残す。"""
    data = json_body(request)
    summary = data.get('summary', '').strip()
    if not data.get('date') or not summary:
        return JsonResponse({'error': 'dateとsummaryは必須です'}, status=400)

    log = BriefingLog.objects.create(
        date=data['date'],
        channel=data.get('channel', 'line'),
        summary=summary,
    )
    return JsonResponse({
        'id': log.pk,
        'message': f'ブリーフィング履歴を登録しました（{log.date}）',
    })


@require_http_methods(["GET"])
def briefing_snapshot(request):
    """夜の報告（クラウド側）が読みに来る、CRMの状況のまとめ。
    Tailscale Funnel でこのパスだけを外に出すので、ログインではなく専用の読み取りトークン
    （Authorization: Bearer {BRIEFING_SNAPSHOT_TOKEN}）で認証する。書き込み用のAPIトークンとは別物。"""
    import hmac
    import os
    from .briefing import build_snapshot

    expected = os.environ.get('BRIEFING_SNAPSHOT_TOKEN', '')
    given = request.headers.get('Authorization', '').removeprefix('Bearer ').strip()
    if not expected or not hmac.compare_digest(given, expected):
        return JsonResponse({'error': '認証が必要です'}, status=401)
    return JsonResponse(build_snapshot(), json_dumps_params={'ensure_ascii': False})
