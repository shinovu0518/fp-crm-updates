from django.contrib import admin
from .models import FollowUpSuggestion


@admin.register(FollowUpSuggestion)
class FollowUpSuggestionAdmin(admin.ModelAdmin):
    list_display = ('customer', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('customer__name', 'line_message')
