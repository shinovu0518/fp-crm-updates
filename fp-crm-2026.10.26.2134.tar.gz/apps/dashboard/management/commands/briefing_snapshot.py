"""夜の報告用のCRMの状況のまとめ（apps/dashboard/briefing.py）を画面に出す。確認用。"""
import json

from django.core.management.base import BaseCommand

from apps.dashboard.briefing import build_snapshot


class Command(BaseCommand):
    help = "夜の報告用に、CRMの状況のまとめをJSONで出す（確認用）"

    def handle(self, *args, **opts):
        self.stdout.write(json.dumps(build_snapshot(), ensure_ascii=False, indent=1))
