from django.db import models


class FollowUpSuggestion(models.Model):
    """フォロー漏れ顧客へのフォロー提案（Claudeが生成したLINE文面案）"""

    STATUS_CHOICES = [
        ('pending',   '未対応'),
        ('sent',      '送信済み'),
        ('dismissed', '見送り'),
    ]

    customer = models.ForeignKey(
        'customers.Customer', on_delete=models.CASCADE,
        related_name='followup_suggestions', verbose_name='顧客'
    )
    reason = models.TextField('提案理由', blank=True)
    line_message = models.TextField('LINE文面案')
    status = models.CharField('ステータス', max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'フォロー提案'
        verbose_name_plural = 'フォロー提案一覧'

    def __str__(self):
        return f"{self.customer.name} - {self.get_status_display()} {self.created_at:%Y-%m-%d}"


class BriefingLog(models.Model):
    """DONNAが送った朝/夜のブリーフィングの履歴（LINE送信内容の記録）。"""

    date = models.DateField('対象日')
    channel = models.CharField('チャネル', max_length=20, default='line')
    summary = models.TextField('送信内容')
    sent_at = models.DateTimeField('送信日時', auto_now_add=True)

    class Meta:
        ordering = ['-date', '-sent_at']
        verbose_name = 'ブリーフィング履歴'
        verbose_name_plural = 'ブリーフィング履歴一覧'

    def __str__(self):
        return f"{self.date} ({self.channel})"
