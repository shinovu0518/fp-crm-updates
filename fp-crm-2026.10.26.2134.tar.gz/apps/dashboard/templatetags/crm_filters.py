from django import template

register = template.Library()


@register.filter
def yen(value):
    """Format a number with comma thousands separator. Works regardless of locale."""
    if value is None or value == '':
        return ''
    try:
        return '{:,}'.format(int(value))
    except (ValueError, TypeError):
        return value


@register.filter
def filter_status(deals, statuses):
    """カンマ区切りのstatus一覧に一致するdealだけを抽出する。"""
    wanted = set(statuses.split(','))
    return [d for d in deals if d.status in wanted]
