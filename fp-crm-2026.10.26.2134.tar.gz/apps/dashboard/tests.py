"""最小テスト（25件）。コンプラ書き込み系＋今回追加したロジックの回帰を守る。

対象：
- _top_tasks（やること面：窓・穴埋め・並び）
- _followup_missed（フォロー漏れ：スコア別閾値・除外）
- api_customer_update（only_if_empty / notes_append / 新項目 / バリデーション）
- api_interview_create（冪等ガード）
- api_compliance_create（分野・flags）
- 送信トレイ（作成dedup / 削除）
- api_task_create（優先度マップ）
- 認証（ログイン必須・APIトークン）
"""
import json
from datetime import date, timedelta

from django.test import TestCase, override_settings
from django.urls import reverse
from django.contrib.auth.models import User

from apps.customers.models import Customer
from apps.tasks.models import Task
from apps.interviews.models import Interview, ComplianceRecord
from apps.deals.models import Deal
from apps.dashboard.models import FollowUpSuggestion
from apps.dashboard.views import _top_tasks, _followup_missed

TODAY = date.today()
TOKEN = "testtoken"


def api_post(client, name, payload, args=None, token=TOKEN):
    return client.post(
        reverse(name, args=args or []), data=json.dumps(payload),
        content_type="application/json", HTTP_X_API_TOKEN=token,
    )


class TopTasksTests(TestCase):
    def setUp(self):
        self.c = Customer.objects.create(name="テスト太郎")

    def _task(self, title, due=None, priority=2, status="pending"):
        return Task.objects.create(title=title, due_date=due, priority=priority, status=status, customer=self.c)

    def test_overdue_appears_with_reason(self):
        self._task("期限切れタスク", due=TODAY - timedelta(days=2))
        result = _top_tasks(TODAY)
        self.assertEqual(len(result), 1)
        self.assertTrue(result[0].top_reason.startswith("期限切れ"))
        self.assertEqual(result[0].top_reason_color, "red")

    def test_far_future_excluded(self):
        self._task("遠い期日", due=TODAY + timedelta(days=40))
        self.assertEqual(_top_tasks(TODAY), [])

    def test_within_window_included(self):
        self._task("2週間後", due=TODAY + timedelta(days=14))
        result = _top_tasks(TODAY)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].top_reason, "あと14日")

    def test_nodue_is_filler_after_dated(self):
        self._task("期限切れ", due=TODAY - timedelta(days=1))
        self._task("期日なし", due=None)
        result = _top_tasks(TODAY, limit=5)
        self.assertEqual(len(result), 2)
        self.assertTrue(result[0].top_reason.startswith("期限切れ"))
        self.assertEqual(result[1].top_reason, "手が空いたら")

    def test_nodue_pushed_out_by_limit(self):
        self._task("期限切れ", due=TODAY - timedelta(days=1))
        self._task("期日なし", due=None)
        result = _top_tasks(TODAY, limit=1)
        self.assertEqual(len(result), 1)
        self.assertTrue(result[0].top_reason.startswith("期限切れ"))

    def test_completed_excluded(self):
        self._task("完了済み", due=TODAY, status="completed")
        self.assertEqual(_top_tasks(TODAY), [])


class FollowupMissedTests(TestCase):
    def _prospect(self, name, score="B"):
        c = Customer.objects.create(name=name, status="in_progress", prospect_score=score)
        Deal.objects.create(customer=c, status="in_progress")
        return c

    def test_over_threshold_is_missed(self):
        c = self._prospect("Bさん超過")  # B=30日
        Interview.objects.create(customer=c, date=TODAY - timedelta(days=40), consultation_content="x")
        self.assertIn(c, _followup_missed(TODAY, 30))

    def test_under_threshold_not_missed(self):
        c = self._prospect("Bさん最近")
        Interview.objects.create(customer=c, date=TODAY - timedelta(days=20), consultation_content="x")
        self.assertNotIn(c, _followup_missed(TODAY, 30))

    def test_no_interview_is_missed(self):
        c = self._prospect("面談なし")
        missed = _followup_missed(TODAY, 30)
        self.assertIn(c, missed)
        self.assertIsNone([m for m in missed if m.pk == c.pk][0].days_since)

    def test_excluded_flag_not_missed(self):
        c = self._prospect("除外")
        c.exclude_from_followup = True
        c.save()
        self.assertNotIn(c, _followup_missed(TODAY, 30))


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=["testserver"], PERSONAL_FEATURES=True)
class CustomerUpdateApiTests(TestCase):
    def setUp(self):
        self.c = Customer.objects.create(name="更新対象", occupation="employee")

    def _update(self, payload):
        return api_post(self.client, "dashboard:api_customer_update", payload, args=[self.c.pk])

    def test_only_if_empty_protects_and_fills(self):
        r = self._update({"occupation": "self_employed", "workplace_memo": "新規メモ", "only_if_empty": True})
        self.assertEqual(r.status_code, 200)
        self.c.refresh_from_db()
        self.assertEqual(self.c.occupation, "employee")       # 既存は保護
        self.assertEqual(self.c.workplace_memo, "新規メモ")   # 空欄は埋まる
        self.assertIn("occupation", r.json()["skipped_fields"])

    def test_notes_append(self):
        self.c.notes = "既存メモ"
        self.c.save()
        self._update({"notes_append": "追記分"})
        self.c.refresh_from_db()
        self.assertEqual(self.c.notes, "既存メモ\n追記分")

    def test_new_fields_update(self):
        self._update({"postal_code": "989-1623", "address": "宮城県..."})
        self.c.refresh_from_db()
        self.assertEqual(self.c.postal_code, "989-1623")
        self.assertEqual(self.c.address, "宮城県...")

    def test_empty_numeric_becomes_none(self):
        self._update({"assets": ""})
        self.c.refresh_from_db()
        self.assertIsNone(self.c.assets)

    def test_no_updatable_fields_returns_400(self):
        r = self._update({"unknown_field": "x"})
        self.assertEqual(r.status_code, 400)


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=["testserver"], PERSONAL_FEATURES=True)
class InterviewApiTests(TestCase):
    def setUp(self):
        self.c = Customer.objects.create(name="面談対象")

    def test_create_persists(self):
        r = api_post(self.client, "dashboard:api_interview_create",
                     {"customer_id": self.c.pk, "date": "2026-07-06", "consultation_content": "内容"})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(Interview.objects.filter(pk=r.json()["id"]).exists())

    def test_idempotency_guard(self):
        payload = {"customer_id": self.c.pk, "date": "2026-07-06", "source_file_id": "FILE1"}
        r1 = api_post(self.client, "dashboard:api_interview_create", payload)
        r2 = api_post(self.client, "dashboard:api_interview_create", payload)
        self.assertTrue(r2.json().get("duplicate"))
        self.assertEqual(r1.json()["id"], r2.json()["id"])
        self.assertEqual(Interview.objects.filter(source_file_id="FILE1").count(), 1)

    def test_missing_customer_returns_400(self):
        r = api_post(self.client, "dashboard:api_interview_create", {"date": "2026-07-06"})
        self.assertEqual(r.status_code, 400)


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=["testserver"], PERSONAL_FEATURES=True)
class ComplianceApiTests(TestCase):
    def setUp(self):
        self.c = Customer.objects.create(name="コンプラ対象")

    def _create(self, extra):
        payload = {"customer_id": self.c.pk, "date": "2026-07-06"}
        payload.update(extra)
        return api_post(self.client, "dashboard:api_compliance_create", payload)

    def test_securities_domain_and_framework(self):
        r = self._create({"domain": "securities", "applicable_framework": "金商法"})
        rec = ComplianceRecord.objects.get(pk=r.json()["id"])
        self.assertEqual(rec.domain, "securities")
        self.assertEqual(rec.applicable_framework, "金商法")

    def test_flags_accepts_list_and_string(self):
        r1 = self._create({"compliance_flags": ["親族同席", "乗換募集"]})
        self.assertEqual(ComplianceRecord.objects.get(pk=r1.json()["id"]).compliance_flags, ["親族同席", "乗換募集"])
        r2 = self._create({"compliance_flags": "単一フラグ"})
        self.assertEqual(ComplianceRecord.objects.get(pk=r2.json()["id"]).compliance_flags, ["単一フラグ"])

    def test_domain_defaults_insurance(self):
        r = self._create({})
        self.assertEqual(ComplianceRecord.objects.get(pk=r.json()["id"]).domain, "insurance")


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=["testserver"], PERSONAL_FEATURES=True)
class FollowupTrayTests(TestCase):
    def setUp(self):
        self.c = Customer.objects.create(name="トレイ対象")

    def test_create_dedup_deletes_old_pending(self):
        api_post(self.client, "dashboard:api_followup_suggestion_create",
                 {"customer_id": self.c.pk, "line_message": "1通目"})
        api_post(self.client, "dashboard:api_followup_suggestion_create",
                 {"customer_id": self.c.pk, "line_message": "2通目"})
        drafts = FollowUpSuggestion.objects.filter(customer=self.c, status="pending")
        self.assertEqual(drafts.count(), 1)
        self.assertEqual(drafts.first().line_message, "2通目")

    def test_remove_deletes_row(self):
        r = api_post(self.client, "dashboard:api_followup_suggestion_create",
                     {"customer_id": self.c.pk, "line_message": "消す下書き"})
        pk = r.json()["id"]
        # remove はダッシュボードのボタン（ログイン必須ビュー）なので認証ユーザーで叩く
        User.objects.create_user("tester", password="x")
        self.client.force_login(User.objects.get(username="tester"))
        self.client.post(reverse("dashboard:followup_suggestion_remove", args=[pk]))
        self.assertFalse(FollowUpSuggestion.objects.filter(pk=pk).exists())

    def test_missing_message_returns_400(self):
        r = api_post(self.client, "dashboard:api_followup_suggestion_create", {"customer_id": self.c.pk})
        self.assertEqual(r.status_code, 400)


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=["testserver"], PERSONAL_FEATURES=True)
class TaskApiTests(TestCase):
    def test_priority_label_mapped(self):
        r = api_post(self.client, "dashboard:api_task_create", {"title": "高優先タスク", "priority": "高"})
        self.assertEqual(Task.objects.get(pk=r.json()["id"]).priority, 1)


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=["testserver"], PERSONAL_FEATURES=True)
class AuthTests(TestCase):
    def test_page_requires_login(self):
        User.objects.create_user("someone", password="x")  # ログインが1つも無いと初回の設定画面へ行く
        r = self.client.get(reverse("dashboard:index"))
        self.assertEqual(r.status_code, 302)
        self.assertIn("/accounts/login", r["Location"])

    def test_api_without_token_401(self):
        r = self.client.post(reverse("dashboard:api_task_create"),
                             data=json.dumps({"title": "x"}), content_type="application/json")
        self.assertEqual(r.status_code, 401)

    def test_api_with_valid_token_ok(self):
        r = api_post(self.client, "dashboard:api_task_create", {"title": "認証OK"})
        self.assertEqual(r.status_code, 200)
