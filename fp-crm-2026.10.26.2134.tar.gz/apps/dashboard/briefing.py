"""夜の報告（クラウド側）に渡す、CRMの状況のまとめ。

Macがスリープしていても夜の報告が届くように、報告はクラウドで組み立てて送る。
クラウドは Tailscale Funnel 経由で /briefing/snapshot/ を読みに来る（Macが寝ていれば届かず、
クラウド側はカレンダーだけで報告する）。件数と、報告に書く短い項目名だけを返し、面談内容などの詳細は出さない。
"""
from datetime import date, datetime, timedelta

from django.db.models import Prefetch

from apps.customers.models import Customer
from apps.deals.models import Deal
from apps.interviews.models import Interview, InterviewDraft
from apps.tasks.models import Task

from .models import FollowUpSuggestion

OPEN = ("completed", "cancelled")


def _task_label(task):
    return f"{task.customer.name}様 {task.title}" if task.customer else task.title


def build_snapshot():
    today = date.today()
    tomorrow = today + timedelta(days=1)
    open_tasks = Task.objects.exclude(status__in=OPEN).select_related("customer")

    done = Task.objects.filter(status="completed", updated_at__date=today).select_related("customer")
    interviews = Interview.objects.filter(created_at__date=today).select_related("customer")
    deals = Deal.objects.filter(created_at__date=today).select_related("customer")
    drafts = InterviewDraft.objects.filter(status="pending").select_related("customer")

    promises = []
    customers = Customer.objects.filter(status="in_progress", family_to__isnull=True).prefetch_related(
        Prefetch("interviews", queryset=Interview.objects.order_by("-date")))
    for c in customers:
        last = next(iter(c.interviews.all()), None)
        if (last and last.next_schedule_type == "scheduled" and last.next_schedule_date
                and today <= last.next_schedule_date <= today + timedelta(days=3)):
            promises.append({"name": c.name, "date": last.next_schedule_date.isoformat()})
    promises.sort(key=lambda p: p["date"])

    return {
        "generated_at": datetime.now().astimezone().isoformat(timespec="minutes"),
        "date": today.isoformat(),
        "today": {
            "tasks_done": [_task_label(t) for t in done],
            "interviews": [i.customer.name for i in interviews if i.customer],
            "deals": [f"{d.customer.name}様 {d.product_name}" if d.customer else d.product_name for d in deals],
        },
        "tomorrow": {
            "date": tomorrow.isoformat(),
            "tasks_due": [_task_label(t) for t in open_tasks.filter(due_date=tomorrow)],
            "tasks_planned": [_task_label(t) for t in open_tasks.filter(planned_date=tomorrow)],
        },
        "promises_within_3_days": promises,
        "attention": {
            "overdue_tasks": [_task_label(t) for t in open_tasks.filter(due_date__lt=today).order_by("due_date")],
            "pending_drafts": [d.customer.name if d.customer else (d.candidate_name or "顧客未特定")
                               for d in drafts.order_by("date")],
            "outbox_pending": FollowUpSuggestion.objects.filter(status="pending").count(),
        },
    }
