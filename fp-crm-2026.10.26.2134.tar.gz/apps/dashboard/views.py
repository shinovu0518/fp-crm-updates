import calendar
from datetime import date, timedelta
from decimal import Decimal
import json
from django.conf import settings as django_settings
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Prefetch
from django.views.decorators.http import require_POST
from apps.tasks.models import Task
from apps.deals.models import Deal
from apps.customers.models import Customer
from apps.interviews.models import Interview
from apps.settings_app.models import SystemSettings, MonthlyTarget, AnnualSetting
from apps.calendar_sync.models import GoogleCalendarToken
from apps.calendar_sync.views import get_week_events, get_today_events, get_upcoming_events
from .models import FollowUpSuggestion, BriefingLog
from apps.interviews.models import InterviewDraft

# 見込みスコア別のフォロー閾値（日）。未設定スコアはSystemSettingsの値を使う
SCORE_FOLLOWUP_DAYS = {'A': 14, 'B': 30, 'C': 60, 'D': 90}

# 「今日やるべき3件」に載せる期日の先読み幅（日）。これより先の期日はまだ出さない
TOP_TASK_WINDOW_DAYS = 30

# 「次回面談の約束」を先読みする幅（日）。この日数以内の next_schedule_date を対象にする
FOLLOWUP_LOOKAHEAD_DAYS = 14

# Googleカレンダーの予定と next_schedule_date を突合する際の許容誤差（日）
CALENDAR_MATCH_TOLERANCE_DAYS = 1


def _get_month_deals(year, month):
    return Deal.objects.filter(
        application_date__year=year,
        application_date__month=month,
        status__in=['in_progress', 'contracted'],
    ).select_related('company', 'customer__consultation_route')


def _aggregate_deals(month_deals):
    ac_life = Decimal('0')
    ac_non_life = Decimal('0')
    ac_securities = Decimal('0')
    solo_count = 0
    joint_count = 0
    total_ac = Decimal('0')
    total_anp = Decimal('0')
    solo_ac = Decimal('0')
    joint_ac = Decimal('0')
    solo_anp = Decimal('0')
    joint_anp = Decimal('0')

    for deal in month_deals:
        cat = deal.company.category if deal.company_id else 'life'
        val = deal.converted_ac
        anp_val = deal.anp or Decimal('0')
        total_ac += val
        total_anp += anp_val
        if cat == 'life':
            ac_life += val
        elif cat == 'non_life':
            ac_non_life += val
        else:
            ac_securities += val
        route = deal.customer.consultation_route if deal.customer_id else None
        if route and route.solicitation_type == 'joint':
            joint_count += 1
            joint_ac += val
            joint_anp += anp_val
        else:
            solo_count += 1
            solo_ac += val
            solo_anp += anp_val

    return {
        'total_ac': total_ac,
        'total_anp': total_anp,
        'ac_life': ac_life,
        'ac_non_life': ac_non_life,
        'ac_securities': ac_securities,
        'solo_count': solo_count,
        'joint_count': joint_count,
        'solo_ac': solo_ac,
        'joint_ac': joint_ac,
        'solo_anp': solo_anp,
        'joint_anp': joint_anp,
    }


def _today_plan(today):
    """本人が「この日にやる」と決めたタスク（やる日が今日、または過ぎたのに未完了の持ち越し）。"""
    plan = list(
        Task.objects.exclude(status__in=['completed', 'cancelled'])
        .filter(planned_date__lte=today)
        .select_related('customer')
        .order_by('planned_date', 'priority', 'due_date')
    )
    for t in plan:
        if t.planned_date < today:
            t.plan_label = f'{(today - t.planned_date).days}日前から持ち越し'
            t.plan_label_color = 'amber'
        elif t.due_date and t.due_date <= today:
            t.plan_label = '今日期限' if t.due_date == today else f'期限切れ {(today - t.due_date).days}日'
            t.plan_label_color = 'red'
        else:
            t.plan_label = ''
            t.plan_label_color = ''
    return plan


def _top_tasks(today, limit=3, exclude_ids=()):
    """今日やるべきタスク厳選：期限切れ→今日期限→期日が近い順に理由ラベル付きで返す。
    期日が1ヶ月より先／期日なしのタスクは、まだ「今日やるべき」ではないので出さない。
    「今日やること」に載せたもの（exclude_ids）と、先の日にやると決めたものは除く（期限切れ・今日期限は残す）。"""
    active = (
        Task.objects.exclude(status__in=['completed', 'cancelled'])
        .exclude(pk__in=exclude_ids)
        .select_related('customer')
    )
    not_scheduled = active.exclude(planned_date__gt=today)

    overdue = list(active.filter(due_date__lt=today).order_by('due_date', 'priority'))
    for t in overdue:
        t.top_reason = f'期限切れ {(today - t.due_date).days}日'
        t.top_reason_color = 'red'

    due_today = list(active.filter(due_date=today).order_by('priority'))
    for t in due_today:
        t.top_reason = '今日期限'
        t.top_reason_color = 'blue'

    # 期日が近いもの（今日〜1ヶ月先）だけを対象にする
    window_end = today + timedelta(days=TOP_TASK_WINDOW_DAYS)
    upcoming = list(
        not_scheduled.filter(due_date__gt=today, due_date__lte=window_end)
        .order_by('due_date', 'priority')
    )
    for t in upcoming:
        t.top_reason = f'あと{(t.due_date - today).days}日'
        t.top_reason_color = 'gray'

    # 期日なしは最下位の穴埋め。上位が3件に満たない時だけ「手が空いたら」で出す
    no_due = list(not_scheduled.filter(due_date__isnull=True).order_by('priority'))
    for t in no_due:
        t.top_reason = '手が空いたら'
        t.top_reason_color = 'gray'

    return (overdue + due_today + upcoming + no_due)[:limit]


def _normalize_name(text):
    return text.replace(' ', '').replace('　', '')


def _today_meeting_prep(user):
    """今日の予定に顧客を突合し、面談準備情報（前回面談・次回フォロー事項）を添えて返す。
    カレンダー未連携・取得失敗時はNone。"""
    events, error = get_today_events(user)
    if events is None:
        return None

    customers = list(
        Customer.objects.filter(is_archived=False)
        .prefetch_related(Prefetch('interviews', queryset=Interview.objects.order_by('-date')))
    )
    prep = []
    for event in events:
        title_norm = _normalize_name(event['title'])
        matched = None
        for c in customers:
            name_norm = _normalize_name(c.name)
            if name_norm and name_norm in title_norm:
                matched = c
                break
        entry = {'event': event, 'customer': matched, 'last_interview': None}
        if matched:
            interviews = list(matched.interviews.all())
            entry['last_interview'] = interviews[0] if interviews else None
        prep.append(entry)
    return prep


def _followup_missed(today, threshold):
    """フォロー漏れ顧客（見込みスコア別閾値を超えて面談がない推進中顧客）を新しい順で返す。
    各顧客に days_since / score_threshold を付与する。"""
    candidates = Customer.objects.filter(
        status='in_progress',
        family_to__isnull=True,
        exclude_from_followup=False,
        deals__status='in_progress',
    ).distinct().prefetch_related(
        Prefetch('interviews', queryset=Interview.objects.order_by('-date'))
    )
    missed = []
    for customer in candidates:
        interviews_cache = list(customer.interviews.all())
        last_interview = interviews_cache[0] if interviews_cache else None
        days_since = (today - last_interview.date).days if last_interview else None
        score_threshold = SCORE_FOLLOWUP_DAYS.get(customer.prospect_score, threshold)
        if last_interview is None or days_since >= score_threshold:
            customer.days_since = days_since
            customer.score_threshold = score_threshold
            missed.append(customer)
    return missed


def _upcoming_followups(today, user):
    """Interview.next_schedule_date（次回面談の約束）を先読みし、
    ①FOLLOWUP_LOOKAHEAD_DAYS日以内に迫った予定、②過去日のまま更新されていない
    「約束したのに放置」を検出する。Googleカレンダーに対応する予定が見当たらなければ
    calendar_checked=True, on_calendar=False として警告フラグを立てる
    （連携なし/取得失敗時は calendar_checked=False としてバッジ自体を出さない）。"""
    window_end = today + timedelta(days=FOLLOWUP_LOOKAHEAD_DAYS)
    candidates = Customer.objects.filter(
        status='in_progress',
        family_to__isnull=True,
        exclude_from_followup=False,
    ).prefetch_related(
        Prefetch('interviews', queryset=Interview.objects.order_by('-date'))
    )

    rows = []
    for customer in candidates:
        interviews_cache = list(customer.interviews.all())
        if not interviews_cache:
            continue
        last_interview = interviews_cache[0]
        if last_interview.next_schedule_type != 'scheduled' or not last_interview.next_schedule_date:
            continue
        next_date = last_interview.next_schedule_date
        if next_date > window_end:
            continue
        customer.next_schedule_date = next_date
        days_until = (next_date - today).days
        customer.days_until = days_until
        customer.is_overdue = days_until < 0
        customer.days_overdue = -days_until if days_until < 0 else None
        customer.last_interview = last_interview
        rows.append(customer)

    rows.sort(key=lambda c: c.next_schedule_date)

    events, cal_error = get_upcoming_events(user, days=FOLLOWUP_LOOKAHEAD_DAYS)
    for customer in rows:
        if events is None:
            customer.calendar_checked = False
            customer.on_calendar = None
            continue
        customer.calendar_checked = True
        name_norm = _normalize_name(customer.name)
        customer.on_calendar = any(
            abs((event['date'] - customer.next_schedule_date).days) <= CALENDAR_MATCH_TOLERANCE_DAYS
            and name_norm and name_norm in _normalize_name(event['title'])
            for event in events
        )

    return rows


def dashboard(request):
    today = date.today()
    today_plan = _today_plan(today)
    settings = SystemSettings.get()
    threshold = settings.followup_threshold_days

    overdue_tasks = Task.objects.filter(due_date__lt=today).exclude(
        status__in=['completed', 'cancelled']
    ).select_related('customer')

    month_deals = _get_month_deals(today.year, today.month)
    agg = _aggregate_deals(month_deals)
    monthly_ac_actual = agg['total_ac']

    monthly_interview_actual = Interview.objects.filter(
        date__year=today.year,
        date__month=today.month,
    ).count()

    prospect_deals = Deal.objects.filter(
        status='in_progress'
    ).select_related('customer', 'company', 'product').order_by('expected_close_month')

    # フォロー漏れ・送信トレイは「フォロー」ページに集約。ダッシュボードは件数バッジのみ表示
    followup_missed_total = len(_followup_missed(today, threshold))
    pending_line_drafts_total = (
        FollowUpSuggestion.objects.filter(status='pending').count()
        if django_settings.PERSONAL_FEATURES else 0
    )

    # 月別目標（MonthlyTargetが設定されていればそちらを優先）
    monthly_target_obj = MonthlyTarget.objects.filter(year=today.year, month=today.month).first()
    if monthly_target_obj and monthly_target_obj.ac_target:
        ac_target = monthly_target_obj.ac_target
    else:
        ac_target = settings.monthly_ac_target or None
    if monthly_target_obj and monthly_target_obj.interview_target:
        interview_target = monthly_target_obj.interview_target
    else:
        interview_target = settings.monthly_interview_target or None

    ac_progress = 0
    if ac_target and ac_target > 0:
        ac_progress = min(int(monthly_ac_actual / ac_target * 100), 100)

    # 先月同期間AC
    first_of_month = today.replace(day=1)
    last_month_last = first_of_month - timedelta(days=1)
    last_month_start = last_month_last.replace(day=1)
    last_month_same_day = last_month_start.replace(day=min(today.day, last_month_last.day))
    last_month_deals = Deal.objects.filter(
        application_date__gte=last_month_start,
        application_date__lte=last_month_same_day,
        status__in=['in_progress', 'contracted'],
    ).select_related('company', 'customer__consultation_route')
    last_month_ac = _aggregate_deals(last_month_deals)['total_ac']
    if last_month_ac > 0:
        ac_vs_last = int((monthly_ac_actual - last_month_ac) / last_month_ac * 100)
    else:
        ac_vs_last = None

    # 年度累計AC（年初から今月まで）
    ytd_deals = Deal.objects.filter(
        application_date__year=today.year,
        status__in=['in_progress', 'contracted'],
    ).select_related('company', 'customer__consultation_route')
    ytd_agg = _aggregate_deals(ytd_deals)
    ytd_ac = ytd_agg['total_ac']
    ytd_ac_life = ytd_agg['ac_life']  # MDRT進捗は生保ACのみで計算

    # MDRT進捗（年間設定から基準額を取得・生保ACのみ）
    annual_setting = AnnualSetting.get_for_year(today.year)
    mdrt_base = annual_setting.mdrt_base or Decimal('0')
    mdrt_goal_level = settings.mdrt_goal_level  # 'mdrt' / 'cot' / 'tot'
    goal_target = settings.mdrt_goal_target(mdrt_base)  # 選択レベルの目標額（Noneの場合あり）
    mdrt_progress = min(int(ytd_ac_life / goal_target * 100), 999) if goal_target else None
    # 各レベルの閾値（プログレスバー上のマーカー位置計算用）
    cot_base = mdrt_base * 3
    tot_base = mdrt_base * 6
    # バー上のマーカー位置（目標レベルの100%を基準に）
    if goal_target and goal_target > 0:
        mdrt_marker_pct = min(int(mdrt_base / goal_target * 100), 100)
        cot_marker_pct  = min(int(cot_base  / goal_target * 100), 100)
        tot_marker_pct  = min(int(tot_base  / goal_target * 100), 100)
    else:
        mdrt_marker_pct = cot_marker_pct = tot_marker_pct = 0
    # 現在到達しているレベル
    reached_level = None
    if mdrt_base > 0:
        ratio = ytd_ac_life / mdrt_base
        if ratio >= 6:
            reached_level = 'TOT'
        elif ratio >= 3:
            reached_level = 'COT'
        elif ratio >= 1:
            reached_level = 'MDRT'

    # 面談数進捗率（widthratio二重計算を回避）
    interview_progress = 0
    if interview_target and interview_target > 0:
        interview_progress = min(int(monthly_interview_actual / interview_target * 100), 100)

    # 生保/損保/証券の目標に対する進捗（横棒グラフ用）
    ac_total = agg['total_ac']
    def _bar_pct(val):
        if not ac_total:
            return 0
        return min(int(val / ac_total * 100), 100)

    return render(request, 'dashboard/index.html', {
        'today': today,
        'today_plan': today_plan,
        'top_tasks': _top_tasks(today, limit=5, exclude_ids=[t.pk for t in today_plan]),
        'meeting_prep': _today_meeting_prep(request.user),
        'upcoming_followups': _upcoming_followups(today, request.user),
        'followup_lookahead_days': FOLLOWUP_LOOKAHEAD_DAYS,
        'overdue_tasks': overdue_tasks,
        'monthly_ac_actual': monthly_ac_actual,
        'monthly_ac_target': ac_target,
        'ac_progress': ac_progress,
        'ac_vs_last': ac_vs_last,
        'last_month_ac': last_month_ac,
        'monthly_interview_actual': monthly_interview_actual,
        'monthly_interview_target': interview_target,
        'interview_progress': interview_progress,
        'ac_life_pct': _bar_pct(agg['ac_life']),
        'ac_non_life_pct': _bar_pct(agg['ac_non_life']),
        'ac_securities_pct': _bar_pct(agg['ac_securities']),
        'prospect_deals': prospect_deals,
        'followup_missed_total': followup_missed_total,
        'pending_line_drafts_total': pending_line_drafts_total,
        'threshold_days': threshold,
        'ac_life': agg['ac_life'],
        'ac_non_life': agg['ac_non_life'],
        'ac_securities': agg['ac_securities'],
        'chart_ac_json': json.dumps({
            'life': float(agg['ac_life']),
            'non_life': float(agg['ac_non_life']),
            'securities': float(agg['ac_securities']),
        }),
        'ytd_ac': ytd_ac_life,
        'mdrt_levels': settings.MDRT_LEVEL_CHOICES,
        'mdrt_base': mdrt_base,
        'goal_target': goal_target,
        'mdrt_goal_level': mdrt_goal_level,
        'mdrt_progress': mdrt_progress,
        'reached_level': reached_level,
        'mdrt_marker_pct': mdrt_marker_pct,
        'cot_marker_pct': cot_marker_pct,
        'tot_marker_pct': tot_marker_pct,
        'cot_base': cot_base,
        'tot_base': tot_base,
        'calendar_connected': GoogleCalendarToken.for_user(request.user).exists(),
        'week_calendar': _get_calendar_events(request.user),
    })


def followups(request):
    """フォローの集約ページ：送信待ちLINE（送信トレイ）＋フォロー漏れ顧客。
    ダッシュボードから外出しして、LINE文面が溜まる/アクセスできる場所にする。"""
    today = date.today()
    settings = SystemSettings.get()
    threshold = settings.followup_threshold_days

    pending_line_drafts = FollowUpSuggestion.objects.filter(
        status='pending'
    ).select_related('customer').order_by('-created_at')

    missed = _followup_missed(today, threshold)

    return render(request, 'dashboard/followups.html', {
        'today': today,
        'pending_line_drafts': pending_line_drafts,
        'followup_missed': missed,
        'followup_missed_total': len(missed),
        'threshold_days': threshold,
    })


@require_POST
def followup_suggestion_remove(request, pk):
    """送信トレイからLINE文面案を消す（送信済み／見送りのどちらも削除）。
    送信済みの実メッセージは週次LINEアーカイブが別途取り込むため、下書きは残さない。"""
    suggestion = get_object_or_404(FollowUpSuggestion, pk=pk)
    suggestion.delete()
    return redirect(request.POST.get('next_url') or 'dashboard:index')


def briefing_history(request):
    """朝/夜のLINEブリーフィング履歴＋未確認の面談ドラフト件数を見るページ。"""
    logs = BriefingLog.objects.all()[:30]
    pending_drafts_total = InterviewDraft.objects.filter(status='pending').count()
    return render(request, 'dashboard/briefing_history.html', {
        'logs': logs,
        'pending_drafts_total': pending_drafts_total,
    })


def _get_calendar_events(user):
    data, error = get_week_events(user)
    if error or data is None:
        return None
    return data


def _build_monthly_history(today, months=24):
    history = []
    year, month = today.year, today.month
    for _ in range(months):
        deals = _get_month_deals(year, month)
        agg = _aggregate_deals(deals)
        contracted = deals.filter(status__in=['contracted']).count()
        interviews = Interview.objects.filter(date__year=year, date__month=month).count()
        total_ac = agg['total_ac']
        unit_price = (total_ac / contracted) if contracted else Decimal('0')
        history.append({
            'year': year,
            'month': month,
            'label': f'{year}年{month}月',
            'interviews': interviews,
            'contracted': contracted,
            'ac_life': total_ac and agg['ac_life'],
            'ac_non_life': agg['ac_non_life'],
            'ac_securities': agg['ac_securities'],
            'total_ac': total_ac,
            'total_anp': agg['total_anp'],
            'unit_price': unit_price,
            'solo_count': agg['solo_count'],
            'joint_count': agg['joint_count'],
            'solo_ac': agg['solo_ac'],
            'joint_ac': agg['joint_ac'],
            'solo_anp': agg['solo_anp'],
            'joint_anp': agg['joint_anp'],
        })
        month -= 1
        if month == 0:
            month = 12
            year -= 1
    history.reverse()
    # attach MoM and YoY diffs (index after reverse: newest is last)
    for i, row in enumerate(history):
        prev = history[i - 1] if i > 0 else None
        yoy = next((h for h in history[:i] if h['year'] == row['year'] - 1 and h['month'] == row['month']), None)
        row['mom'] = _pct_diff(row['total_ac'], prev['total_ac'] if prev else None)
        row['yoy'] = _pct_diff(row['total_ac'], yoy['total_ac'] if yoy else None)
    return history


def _pct_diff(current, base):
    if base is None or base == 0:
        return None
    return int((current - base) / base * 100)


def _add_months(d, delta):
    month = d.month - 1 + delta
    year = d.year + month // 12
    month = month % 12 + 1
    return date(year, month, 1)


def weekly_report(request):
    period = request.GET.get('period') if request.GET.get('period') in ('week', 'month') else 'week'
    today = date.today()

    if period == 'month':
        try:
            year = int(request.GET.get('year', today.year))
            month = int(request.GET.get('month', today.month))
            period_start = date(year, month, 1)
        except (TypeError, ValueError):
            period_start = today.replace(day=1)
        period_end = period_start.replace(day=calendar.monthrange(period_start.year, period_start.month)[1])
        next_period_start = _add_months(period_start, 1)
        next_period_end = next_period_start.replace(
            day=calendar.monthrange(next_period_start.year, next_period_start.month)[1]
        )
        prev_period_start = _add_months(period_start, -1)
    else:
        period_start = today - timedelta(days=today.weekday())  # 月曜
        period_end = period_start + timedelta(days=6)             # 日曜
        next_period_start = period_start + timedelta(days=7)
        next_period_end = next_period_start + timedelta(days=6)

    period_interviews = Interview.objects.filter(
        date__gte=period_start, date__lte=period_end
    ).select_related('customer').order_by('date')

    period_deals = Deal.objects.filter(
        application_date__gte=period_start,
        application_date__lte=period_end,
        status__in=['in_progress', 'contracted'],
    ).select_related('company', 'customer__consultation_route', 'customer', 'product')
    period_agg = _aggregate_deals(period_deals)

    period_completed_tasks = Task.objects.filter(
        updated_at__date__gte=period_start,
        updated_at__date__lte=period_end,
        status='completed',
    ).select_related('customer').order_by('updated_at')

    new_customers = Customer.objects.filter(
        created_at__date__gte=period_start,
        created_at__date__lte=period_end,
    ).order_by('created_at')

    next_period_tasks = Task.objects.filter(
        due_date__gte=next_period_start,
        due_date__lte=next_period_end,
    ).exclude(status__in=['completed', 'cancelled']).select_related('customer').order_by('due_date')

    WEEKDAY_JA = ['月', '火', '水', '木', '金', '土', '日']

    def fmt_date(d):
        if period == 'month':
            return f'{d.month}月{d.day}日'
        return f'{d.month}月{d.day}日（{WEEKDAY_JA[d.weekday()]}）'

    context = {
        'today': today,
        'period': period,
        'period_label': '月' if period == 'month' else '週',
        'period_start': period_start,
        'period_end': period_end,
        'next_period_start': next_period_start,
        'next_period_end': next_period_end,
        'period_start_str': fmt_date(period_start),
        'period_end_str': fmt_date(period_end),
        'next_period_start_str': fmt_date(next_period_start),
        'next_period_end_str': fmt_date(next_period_end),
        'period_interviews': period_interviews,
        'period_deals': period_deals,
        'period_ac': period_agg['total_ac'],
        'period_anp': period_agg['total_anp'],
        'period_completed_tasks': period_completed_tasks,
        'new_customers': new_customers,
        'next_period_tasks': next_period_tasks,
    }
    if period == 'month':
        context['is_current_month'] = (period_start.year == today.year and period_start.month == today.month)
        context['prev_month_year'] = prev_period_start.year
        context['prev_month_month'] = prev_period_start.month
        context['next_month_year'] = next_period_start.year
        context['next_month_month'] = next_period_start.month
    return render(request, 'dashboard/weekly.html', context)


def analytics(request):
    today = date.today()
    month_deals = _get_month_deals(today.year, today.month)
    agg = _aggregate_deals(month_deals)
    contracted_this_month = month_deals.filter(status='contracted').count()

    history = _build_monthly_history(today, months=24)

    # Chart data: last 12 months
    chart_months = history[-12:]
    labels = [h['label'] for h in chart_months]
    chart_history_json = json.dumps({
        'labels': labels,
        'ac_life': [float(h['ac_life']) for h in chart_months],
        'ac_non_life': [float(h['ac_non_life']) for h in chart_months],
        'ac_securities': [float(h['ac_securities']) for h in chart_months],
        'interviews': [h['interviews'] for h in chart_months],
        'contracted': [h['contracted'] for h in chart_months],
    })

    chart_solicitation_json = json.dumps({
        'count': {'solo': agg['solo_count'], 'joint': agg['joint_count']},
        'ac': {'solo': float(agg['solo_ac']), 'joint': float(agg['joint_ac'])},
        'anp': {'solo': float(agg['solo_anp']), 'joint': float(agg['joint_anp'])},
    })

    def _pct_pair(a, b):
        total = a + b
        if not total:
            return (0, 0)
        return (round(a / total * 100), round(b / total * 100))

    trend_solicitation = {}
    for basis, solo_key, joint_key in [
        ('count', 'solo_count', 'joint_count'),
        ('ac', 'solo_ac', 'joint_ac'),
        ('anp', 'solo_anp', 'joint_anp'),
    ]:
        solo_vals = [float(h[solo_key]) for h in chart_months]
        joint_vals = [float(h[joint_key]) for h in chart_months]
        solo_pct, joint_pct = [], []
        for s, j in zip(solo_vals, joint_vals):
            sp, jp = _pct_pair(s, j)
            solo_pct.append(sp)
            joint_pct.append(jp)
        trend_solicitation[basis] = {
            'solo_pct': solo_pct,
            'joint_pct': joint_pct,
            'solo_val': [h[solo_key] for h in chart_months] if basis == 'count' else solo_vals,
            'joint_val': [h[joint_key] for h in chart_months] if basis == 'count' else joint_vals,
        }

    chart_solicitation_trend_json = json.dumps({
        'labels': labels,
        **trend_solicitation,
    })

    return render(request, 'dashboard/analytics.html', {
        'today': today,
        'monthly_ac_actual': agg['total_ac'],
        'ac_life': agg['ac_life'],
        'ac_non_life': agg['ac_non_life'],
        'ac_securities': agg['ac_securities'],
        'solo_count': agg['solo_count'],
        'joint_count': agg['joint_count'],
        'contracted_this_month': contracted_this_month,
        'history': list(reversed(history)),  # newest first for table
        'chart_history_json': chart_history_json,
        'chart_solicitation_json': chart_solicitation_json,
        'chart_solicitation_trend_json': chart_solicitation_trend_json,
    })
