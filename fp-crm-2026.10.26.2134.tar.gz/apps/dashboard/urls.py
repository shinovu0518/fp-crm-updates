from django.urls import path
from . import views, api
from apps.customers import api as customers_api
from apps.interviews import api as interviews_api
from apps.tasks import api as tasks_api
from apps.deals import api as deals_api

app_name = 'dashboard'

# 登録APIは各アプリの api.py に分散（責務分離）。URL（外部契約）は互換維持のためここに集約。
urlpatterns = [
    path('', views.dashboard, name='index'),
    path('analytics/', views.analytics, name='analytics'),
    path('weekly/', views.weekly_report, name='weekly'),
    path('followups/', views.followups, name='followups'),
    path('briefings/', views.briefing_history, name='briefing_history'),
    path('briefing/snapshot/', api.briefing_snapshot, name='briefing_snapshot'),
    path('followup-suggestions/<int:pk>/remove/', views.followup_suggestion_remove, name='followup_suggestion_remove'),
    path('api/customers/', customers_api.api_customers_list, name='api_customers'),
    path('api/customers/create/', customers_api.api_customer_create_or_find, name='api_customer_create'),
    path('api/customers/<int:customer_id>/update/', customers_api.api_customer_update, name='api_customer_update'),
    path('api/interviews/create/', interviews_api.api_interview_create, name='api_interview_create'),
    path('api/interviews/<int:pk>/update/', interviews_api.api_interview_update, name='api_interview_update'),
    path('api/interview-drafts/create/', interviews_api.api_interview_draft_create, name='api_interview_draft_create'),
    path('api/compliance/create/', interviews_api.api_compliance_create, name='api_compliance_create'),
    path('api/communications/create/', customers_api.api_communication_create, name='api_communication_create'),
    path('api/tasks/create/', tasks_api.api_task_create, name='api_task_create'),
    path('api/tasks/<int:pk>/update/', tasks_api.api_task_update, name='api_task_update'),
    path('api/deals/create/', deals_api.api_deal_create, name='api_deal_create'),
    path('api/followup-suggestions/create/', api.api_followup_suggestion_create, name='api_followup_suggestion_create'),
    path('api/briefing-logs/create/', api.api_briefing_log_create, name='api_briefing_log_create'),
]
