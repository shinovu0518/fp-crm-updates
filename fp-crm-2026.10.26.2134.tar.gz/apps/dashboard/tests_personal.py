"""個人用機能（PERSONAL_FEATURES）の切り替えのテスト。オフ＝外販版の姿。"""
from django.contrib.auth.models import User
from django.test import TestCase, override_settings

TOKEN = 'test-token'
PERSONAL_PATHS = [
    '/api/customers/',
    '/interviews/drafts/',
    '/followup-suggestions/1/remove/',
    '/briefings/',
    '/briefing/snapshot/',
    '/line/webhook/',
    '/api/planning/ask/',
]


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=['testserver'], PERSONAL_FEATURES=False)
class PersonalFeaturesOffTests(TestCase):
    def setUp(self):
        User.objects.create_user('fp', password='pw')
        self.client.login(username='fp', password='pw')

    def test_personal_paths_are_404(self):
        for path in PERSONAL_PATHS:
            with self.subTest(path=path):
                self.assertEqual(self.client.get(path, HTTP_X_API_TOKEN=TOKEN).status_code, 404)

    def test_menu_and_tray_are_hidden(self):
        res = self.client.get('/followups/')
        self.assertEqual(res.status_code, 200)
        self.assertNotContains(res, '面談ドラフト')
        self.assertNotContains(res, '送信待ちLINE')
        self.assertContains(res, 'フォロー漏れ顧客')

    def test_dashboard_renders(self):
        self.assertEqual(self.client.get('/').status_code, 200)


@override_settings(API_TOKEN=TOKEN, ALLOWED_HOSTS=['testserver'], PERSONAL_FEATURES=True)
class PersonalFeaturesOnTests(TestCase):
    def setUp(self):
        User.objects.create_user('fp', password='pw')
        self.client.login(username='fp', password='pw')

    def test_api_and_drafts_available(self):
        self.assertEqual(self.client.get('/api/customers/', HTTP_X_API_TOKEN=TOKEN).status_code, 200)
        self.assertEqual(self.client.get('/interviews/drafts/').status_code, 200)

    def test_menu_and_tray_are_shown(self):
        res = self.client.get('/followups/')
        self.assertContains(res, '面談ドラフト')
        self.assertContains(res, '送信待ちLINE')
