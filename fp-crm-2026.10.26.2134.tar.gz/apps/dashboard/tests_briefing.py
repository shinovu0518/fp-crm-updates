"""夜の報告（クラウド側）用の /briefing/snapshot/ のテスト。"""
import os
from datetime import date, timedelta
from unittest import mock

from django.test import TestCase, override_settings

from apps.customers.models import Customer
from apps.tasks.models import Task

TOKEN = 'snap-token'


@override_settings(API_TOKEN='write-token', PERSONAL_FEATURES=True)
@mock.patch.dict(os.environ, {'BRIEFING_SNAPSHOT_TOKEN': TOKEN})
class BriefingSnapshotTests(TestCase):
    def setUp(self):
        c = Customer.objects.create(name='田中一郎')
        Task.objects.create(title='設計書送付', customer=c, due_date=date.today() - timedelta(days=1))

    def test_rejects_missing_or_wrong_token(self):
        self.assertEqual(self.client.get('/briefing/snapshot/').status_code, 401)
        self.assertEqual(self.client.get('/briefing/snapshot/', HTTP_AUTHORIZATION='Bearer x').status_code, 401)
        # 書き込み用APIトークンでは読めない
        self.assertEqual(self.client.get('/briefing/snapshot/', HTTP_X_API_TOKEN='write-token').status_code, 401)

    def test_returns_snapshot(self):
        resp = self.client.get('/briefing/snapshot/', HTTP_AUTHORIZATION=f'Bearer {TOKEN}')
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()['attention']['overdue_tasks'], ['田中一郎様 設計書送付'])

    def test_disabled_without_configured_token(self):
        with mock.patch.dict(os.environ, {'BRIEFING_SNAPSHOT_TOKEN': ''}):
            self.assertEqual(self.client.get('/briefing/snapshot/', HTTP_AUTHORIZATION='Bearer ').status_code, 401)
