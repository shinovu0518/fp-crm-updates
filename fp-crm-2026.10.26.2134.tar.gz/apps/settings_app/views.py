from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.contrib import messages
from decimal import Decimal
from .models import SystemSettings, MonthlyTarget, AnnualSetting
from .forms import SystemSettingsForm
from apps.deals.models import InsuranceCompany, InsuranceProduct
import json as _json
from django.conf import settings as django_settings
from django.http import Http404, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods, require_POST
from apps.customers.models import ConsultationRoute, CoRecruiter, RouteCompanyCode


def settings_index(request):
    instance = SystemSettings.get()
    if request.method == 'POST':
        form = SystemSettingsForm(request.POST, instance=instance)
        if form.is_valid():
            form.save()
            messages.success(request, '設定を保存しました。')
            return redirect('settings_app:index')
    else:
        form = SystemSettingsForm(instance=instance)
    context = {'form': form}
    if django_settings.SERVE_FILES:  # Mac用アプリとして動いている時だけ、バックアップと終了の欄を出す
        from config.backup import backup_root, list_backups
        from config.updates import current_version
        context.update(app_mode=True, data_dir=str(django_settings.DATA_DIR), app_version=current_version(),
                       backup_dir=str(backup_root()), backups=[p.name for p in list_backups()[:7]])
    return render(request, 'settings_app/index.html', context)


@require_POST
def backup_now(request):
    if not django_settings.SERVE_FILES:
        raise Http404
    from config.backup import run_backup
    dest = run_backup(force=True)
    messages.success(request, f'バックアップを取りました（{dest.name}）')
    return redirect('settings_app:index')


def set_mdrt_level(request):
    """ダッシュボードのMDRT目標レベルをワンクリックで切り替え"""
    if request.method == 'POST':
        level = request.POST.get('level', 'mdrt')
        if level in ('mdrt', 'cot', 'tot'):
            settings = SystemSettings.get()
            settings.mdrt_goal_level = level
            settings.save(update_fields=['mdrt_goal_level'])
    next_url = request.POST.get('next_url', '/')
    return redirect(next_url)


def company_list(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        category = request.POST.get('category', 'life')
        order = request.POST.get('order', 0)
        if name:
            InsuranceCompany.objects.get_or_create(name=name, defaults={'category': category, 'order': order})
            messages.success(request, f'「{name}」を追加しました。')
        return redirect('settings_app:companies')
    companies = InsuranceCompany.objects.prefetch_related('products')
    category_choices = InsuranceCompany.CATEGORY_CHOICES
    return render(request, 'settings_app/companies.html', {
        'companies': companies,
        'category_choices': category_choices,
    })


def company_delete(request, pk):
    company = get_object_or_404(InsuranceCompany, pk=pk)
    if request.method == 'POST':
        name = company.name
        company.delete()
        messages.success(request, f'「{name}」を削除しました。')
    return redirect('settings_app:companies')


def product_list(request):
    if request.method == 'POST':
        company_id = request.POST.get('company')
        name = request.POST.get('name', '').strip()
        order = request.POST.get('order', 0)
        trust_fee = request.POST.get('trust_fee') or None
        purchase_fee = request.POST.get('purchase_fee') or None
        retention_fee = request.POST.get('retention_fee') or None
        if company_id and name:
            company = get_object_or_404(InsuranceCompany, pk=company_id)
            InsuranceProduct.objects.get_or_create(
                company=company, name=name,
                defaults={
                    'order': order,
                    'trust_fee': trust_fee,
                    'purchase_fee': purchase_fee,
                    'retention_fee': retention_fee,
                }
            )
            messages.success(request, f'「{name}」を追加しました。')
        return redirect('settings_app:products')
    companies = InsuranceCompany.objects.prefetch_related('products')
    return render(request, 'settings_app/products.html', {'companies': companies})


def product_edit(request, pk):
    product = get_object_or_404(InsuranceProduct, pk=pk)
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        if name:
            product.name = name
        product.order = request.POST.get('order') or 0
        product.trust_fee = request.POST.get('trust_fee') or None
        product.purchase_fee = request.POST.get('purchase_fee') or None
        product.retention_fee = request.POST.get('retention_fee') or None
        product.save()
        messages.success(request, f'「{product.name}」を更新しました。')
    return redirect('settings_app:products')


def product_delete(request, pk):
    product = get_object_or_404(InsuranceProduct, pk=pk)
    if request.method == 'POST':
        name = product.name
        product.delete()
        messages.success(request, f'「{name}」を削除しました。')
    return redirect('settings_app:products')


# ── 相談経路 ──────────────────────────────────────────

def route_list(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        solicitation_type = request.POST.get('solicitation_type', 'solo')
        joint_years = request.POST.get('joint_years') or 0
        co_recruiter_name = request.POST.get('co_recruiter_name', '').strip()
        recruiter_code = request.POST.get('recruiter_code', '').strip()
        codes_memo = request.POST.get('codes_memo', '').strip()
        notes = request.POST.get('notes', '').strip()
        order = request.POST.get('order', 0)
        if name:
            route = ConsultationRoute.objects.create(
                name=name,
                solicitation_type=solicitation_type,
                joint_years=joint_years,
                co_recruiter_name=co_recruiter_name,
                recruiter_code=recruiter_code,
                codes_memo=codes_memo,
                notes=notes,
                order=order,
            )
            messages.success(request, f'「{name}」を追加しました。')
            return redirect(reverse('settings_app:route_list') + f'?route={route.pk}')
        return redirect('settings_app:route_list')
    routes = ConsultationRoute.objects.order_by('order', 'name')
    selected_pk = request.GET.get('route')
    import json
    routes_json = json.dumps([{
        'pk': r.pk,
        'name': r.name,
        'solicitation_type': r.solicitation_type,
        'solicitation_label': r.get_solicitation_type_display(),
        'joint_years': r.joint_years,
        'co_recruiter_name': r.co_recruiter_name,
        'recruiter_code': r.recruiter_code,
        'codes_memo': r.codes_memo,
        'notes': r.notes,
    } for r in routes], ensure_ascii=False)
    return render(request, 'settings_app/routes.html', {
        'routes': routes,
        'routes_json': routes_json,
        'selected_pk': selected_pk,
        'solicitation_choices': ConsultationRoute.SOLICITATION_CHOICES,
    })


def route_edit(request, pk):
    route = get_object_or_404(ConsultationRoute, pk=pk)
    if request.method == 'POST':
        route.name = request.POST.get('name', '').strip()
        route.solicitation_type = request.POST.get('solicitation_type', 'solo')
        route.joint_years = request.POST.get('joint_years') or 0
        route.co_recruiter_name = request.POST.get('co_recruiter_name', '').strip()
        route.recruiter_code = request.POST.get('recruiter_code', '').strip()
        route.codes_memo = request.POST.get('codes_memo', '').strip()
        route.notes = request.POST.get('notes', '').strip()
        route.order = request.POST.get('order', 0)
        route.save()
        messages.success(request, f'「{route.name}」を更新しました。')
        return redirect('settings_app:route_list')
    return render(request, 'settings_app/route_edit.html', {
        'route': route,
        'solicitation_choices': ConsultationRoute.SOLICITATION_CHOICES,
    })


def route_delete(request, pk):
    route = get_object_or_404(ConsultationRoute, pk=pk)
    if request.method == 'POST':
        name = route.name
        route.delete()
        messages.success(request, f'「{name}」を削除しました。')
    return redirect('settings_app:route_list')


# ── 共同募集人 ────────────────────────────────────────

def corecruiter_list(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        code = request.POST.get('code', '').strip()
        if name:
            CoRecruiter.objects.create(name=name, code=code)
            messages.success(request, f'「{name}」を追加しました。')
        return redirect('settings_app:corecruiter_list')
    corecruiters = CoRecruiter.objects.order_by('name')
    return render(request, 'settings_app/corecruiters.html', {
        'corecruiters': corecruiters,
    })


def corecruiter_edit(request, pk):
    recruiter = get_object_or_404(CoRecruiter, pk=pk)
    if request.method == 'POST':
        recruiter.name = request.POST.get('name', '').strip()
        recruiter.code = request.POST.get('code', '').strip()
        recruiter.memo = request.POST.get('memo', '').strip()
        recruiter.save()
        messages.success(request, f'「{recruiter.name}」を更新しました。')
        return redirect('settings_app:corecruiter_list')
    return render(request, 'settings_app/corecruiter_edit.html', {'recruiter': recruiter})


def corecruiter_delete(request, pk):
    recruiter = get_object_or_404(CoRecruiter, pk=pk)
    if request.method == 'POST':
        name = recruiter.name
        recruiter.delete()
        messages.success(request, f'「{name}」を削除しました。')
    return redirect('settings_app:corecruiter_list')


def corecruiter_company_code_save(request, corecruiter_pk):
    # 旧ビュー（互換性のために残す）
    return redirect('settings_app:corecruiter_list')


def corecruiter_company_code_delete(request, pk):
    # 旧ビュー（互換性のために残す）
    return redirect('settings_app:corecruiter_list')


@require_http_methods(["POST"])
def route_company_code_save(request, route_pk):
    route = get_object_or_404(ConsultationRoute, pk=route_pk)
    company_id = request.POST.get('company_id')
    code = request.POST.get('code', '').strip()
    if company_id:
        RouteCompanyCode.objects.update_or_create(
            route=route, company_id=company_id,
            defaults={'code': code}
        )
    return redirect(reverse('settings_app:route_list') + f'?route={route_pk}')


@require_http_methods(["POST"])
def route_company_code_delete(request, pk):
    rcc = RouteCompanyCode.objects.filter(pk=pk).select_related('route').first()
    route_pk = rcc.route_id if rcc else None
    if rcc:
        rcc.delete()
    if route_pk:
        return redirect(reverse('settings_app:route_list') + f'?route={route_pk}')
    return redirect('settings_app:route_list')


@csrf_exempt
@require_http_methods(["POST"])
def company_reorder(request):
    ids = _json.loads(request.body).get('ids', [])
    for i, pk in enumerate(ids):
        InsuranceCompany.objects.filter(pk=pk).update(order=i)
    return JsonResponse({'ok': True})


@csrf_exempt
@require_http_methods(["POST"])
def product_reorder(request):
    ids = _json.loads(request.body).get('ids', [])
    for i, pk in enumerate(ids):
        InsuranceProduct.objects.filter(pk=pk).update(order=i)
    return JsonResponse({'ok': True})


def annual_targets(request):
    from datetime import date
    today = date.today()
    try:
        year = int(request.GET.get('year', today.year))
    except (ValueError, TypeError):
        year = today.year

    annual = AnnualSetting.get_for_year(year)

    if request.method == 'POST':
        # MDRT基準額
        mdrt_val = request.POST.get('mdrt_base', '').replace(',', '').strip()
        annual.mdrt_base = Decimal(mdrt_val) if mdrt_val else None
        annual.save()
        # 月別目標
        for m in range(1, 13):
            ac_val = request.POST.get(f'ac_{m}', '').replace(',', '').strip()
            iv_val = request.POST.get(f'iv_{m}', '').strip()
            obj, _ = MonthlyTarget.objects.get_or_create(year=year, month=m)
            obj.ac_target = Decimal(ac_val) if ac_val else None
            obj.interview_target = int(iv_val) if iv_val else None
            obj.save()
        messages.success(request, f'{year}年の目標を保存しました。')
        return redirect(f'{request.path}?year={year}')

    targets = {t.month: t for t in MonthlyTarget.objects.filter(year=year)}
    months = []
    for m in range(1, 13):
        t = targets.get(m)
        months.append({
            'month': m,
            'ac_target': t.ac_target if t else None,
            'interview_target': t.interview_target if t else None,
        })

    return render(request, 'settings_app/annual_targets.html', {
        'year': year,
        'prev_year': year - 1,
        'next_year': year + 1,
        'today_year': today.year,
        'today_month': today.month,
        'months': months,
        'annual': annual,
    })
