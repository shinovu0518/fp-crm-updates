from django.urls import path
from . import views

app_name = 'settings_app'

urlpatterns = [
    path('', views.settings_index, name='index'),
    path('backup/', views.backup_now, name='backup_now'),
    path('companies/', views.company_list, name='companies'),
    path('companies/<int:pk>/delete/', views.company_delete, name='company_delete'),
    path('products/', views.product_list, name='products'),
    path('products/<int:pk>/edit/', views.product_edit, name='product_edit'),
    path('products/<int:pk>/delete/', views.product_delete, name='product_delete'),
    path('routes/', views.route_list, name='route_list'),
    path('routes/<int:pk>/edit/', views.route_edit, name='route_edit'),
    path('routes/<int:pk>/delete/', views.route_delete, name='route_delete'),
    path('corecruiters/', views.corecruiter_list, name='corecruiter_list'),
    path('corecruiters/<int:pk>/edit/', views.corecruiter_edit, name='corecruiter_edit'),
    path('corecruiters/<int:pk>/delete/', views.corecruiter_delete, name='corecruiter_delete'),
    path('corecruiters/<int:corecruiter_pk>/codes/save/', views.corecruiter_company_code_save, name='corecruiter_company_code_save'),
    path('corecruiters/codes/<int:pk>/delete/', views.corecruiter_company_code_delete, name='corecruiter_company_code_delete'),
    path('routes/<int:route_pk>/codes/save/', views.route_company_code_save, name='route_company_code_save'),
    path('routes/codes/<int:pk>/delete/', views.route_company_code_delete, name='route_company_code_delete'),
    path('companies/reorder/', views.company_reorder, name='company_reorder'),
    path('products/reorder/', views.product_reorder, name='product_reorder'),
    path('annual-targets/', views.annual_targets, name='annual_targets'),
    path('mdrt-level/', views.set_mdrt_level, name='set_mdrt_level'),
]
