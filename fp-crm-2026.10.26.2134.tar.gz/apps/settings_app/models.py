from django.db import models


class AnnualSetting(models.Model):
    year = models.IntegerField('年', unique=True)
    mdrt_base = models.DecimalField('MDRT基準額（円）', max_digits=14, decimal_places=0,
                                    null=True, blank=True,
                                    help_text='その年のMDRT基準額（COT=3倍、TOT=6倍で自動計算）')

    class Meta:
        verbose_name = '年間設定'
        ordering = ['-year']

    @classmethod
    def get_for_year(cls, year):
        obj, _ = cls.objects.get_or_create(year=year)
        return obj

    @property
    def cot_base(self):
        return self.mdrt_base * 3 if self.mdrt_base else None

    @property
    def tot_base(self):
        return self.mdrt_base * 6 if self.mdrt_base else None

    def __str__(self):
        return f'{self.year}年'


class MonthlyTarget(models.Model):
    year = models.IntegerField('年')
    month = models.IntegerField('月')
    ac_target = models.DecimalField('AC目標（円）', max_digits=12, decimal_places=0, null=True, blank=True)
    interview_target = models.IntegerField('面談数目標（件）', null=True, blank=True)

    class Meta:
        unique_together = [('year', 'month')]
        verbose_name = '月次目標'
        verbose_name_plural = '月次目標一覧'
        ordering = ['year', 'month']

    def __str__(self):
        return f'{self.year}年{self.month}月'


class SystemSettings(models.Model):
    followup_threshold_days = models.IntegerField('フォロー遅延閾値（日）', default=30)
    monthly_ac_target = models.DecimalField('月間AC目標（円）', max_digits=12, decimal_places=0, default=0)
    monthly_interview_target = models.IntegerField('月間面談数目標（件）', default=0)
    MDRT_LEVEL_CHOICES = [
        ('mdrt', 'MDRT'),
        ('cot',  'COT（3倍）'),
        ('tot',  'TOT（6倍）'),
    ]
    mdrt_goal_level = models.CharField('目標レベル', max_length=10,
                                        choices=MDRT_LEVEL_CHOICES, default='mdrt')

    class Meta:
        verbose_name = 'システム設定'

    @classmethod
    def get(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def mdrt_goal_target(self, mdrt_base):
        """選択した目標レベルに対応する年間目標金額"""
        if not mdrt_base:
            return None
        multiplier = {'mdrt': 1, 'cot': 3, 'tot': 6}.get(self.mdrt_goal_level, 1)
        return mdrt_base * multiplier
