"""Mac用アプリの更新（案内ファイル・入れ方・更新ボタン・起動役の戻し方）のテスト。"""
import hashlib
import importlib.util
import io
import os
import sqlite3
import tarfile
import tempfile
import time
from pathlib import Path
from unittest import mock

from django.conf import settings
from django.contrib.auth.models import User
from django.test import TestCase, override_settings

from config import updates

ROOT = Path(__file__).resolve().parents[2]


def _tar(files):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w:gz') as tar:
        for name, body in files.items():
            info = tarfile.TarInfo(name)
            info.size = len(body)
            tar.addfile(info, io.BytesIO(body))
    return buf.getvalue()


def _manifest(version, data, **kw):
    return {'version': version, 'url': 'https://example.test/u.tar.gz',
            'sha256': hashlib.sha256(data).hexdigest(), 'requires_launcher': 1, 'notes': '速くしました', **kw}


class UpdateTestBase(TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        db = self.data / 'db.sqlite3'
        sqlite3.connect(db).close()
        self.override = override_settings(
            SERVE_FILES=True, DATA_DIR=self.data, MEDIA_ROOT=self.data / 'media',
            DATABASES={**settings.DATABASES, 'default': {**settings.DATABASES['default'], 'NAME': db}})
        self.override.enable()
        self.env = mock.patch.dict(os.environ, {
            'FPCRM_UPDATE_URL': 'https://example.test/manifest.json',
            'FPCRM_CODE_VERSION': '2026.10.26.1000', 'FPCRM_LAUNCHER_API': '1'})
        self.env.start()
        updates._cache.update(at=0.0, manifest=None, error=None)

    def tearDown(self):
        self.env.stop()
        self.override.disable()
        self.tmp.cleanup()

    def set_manifest(self, m):
        updates._cache.update(at=time.time(), manifest=m, error=None)


class ManifestTests(UpdateTestBase):
    def test_newer_older_and_needs_new_app(self):
        data = _tar({'manage.py': b''})
        self.set_manifest(_manifest('2026.10.27.0900', data))
        self.assertEqual(updates.available_update()['version'], '2026.10.27.0900')
        self.set_manifest(_manifest('2026.10.26.0900', data))
        self.assertIsNone(updates.available_update())
        self.set_manifest(_manifest('2026.10.27.0900', data, requires_launcher=2))
        self.assertTrue(updates.available_update()['needs_new_app'])

    def test_version_that_failed_to_start_is_not_offered_again(self):
        data = _tar({'manage.py': b''})
        failed = self.data / 'versions' / '2026.10.27.0900'
        failed.mkdir(parents=True)
        (failed / '.tried').touch()
        self.set_manifest(_manifest('2026.10.27.0900', data))
        self.assertIsNone(updates.available_update())

    def test_disabled_without_url_or_outside_app(self):
        with mock.patch.dict(os.environ, {'FPCRM_UPDATE_URL': ''}):
            self.assertIsNone(updates.available_update())
        with override_settings(SERVE_FILES=False):
            self.assertIsNone(updates.available_update())

    def test_network_error_is_quiet(self):
        with mock.patch('config.updates._fetch', side_effect=OSError('offline')):
            self.assertIsNone(updates.available_update(wait=True))


class InstallTests(UpdateTestBase):
    def test_installs_and_keeps_previous(self):
        for v in ('2026.10.27.0900', '2026.10.28.0900', '2026.10.29.0900'):
            data = _tar({'manage.py': b'', 'VERSION': v.encode()})
            with mock.patch('config.updates._fetch', return_value=data):
                updates.install(_manifest(v, data))
        versions = self.data / 'versions'
        self.assertEqual((versions / 'current').read_text(), '2026.10.29.0900')
        self.assertEqual((versions / 'previous').read_text(), '2026.10.28.0900')
        self.assertEqual(sorted(p.name for p in versions.iterdir() if p.is_dir()), ['2026.10.28.0900', '2026.10.29.0900'])
        self.assertTrue(any((self.data / 'backups').iterdir()))  # 更新前にバックアップ

    def test_rejects_wrong_checksum(self):
        data = _tar({'manage.py': b''})
        bad = _manifest('2026.10.27.0900', data, sha256='0' * 64)
        with mock.patch('config.updates._fetch', return_value=data), self.assertRaises(updates.UpdateError):
            updates.install(bad)
        self.assertFalse((self.data / 'versions' / 'current').exists())

    def test_rejects_paths_outside_and_missing_crm(self):
        for files in ({'../evil.py': b'', 'manage.py': b''}, {'readme.txt': b''}):
            data = _tar(files)
            with mock.patch('config.updates._fetch', return_value=data), self.assertRaises(updates.UpdateError):
                updates.install(_manifest('2026.10.27.0900', data))
        self.assertFalse((self.data / 'evil.py').exists())


class UpdateButtonTests(UpdateTestBase):
    def setUp(self):
        super().setUp()
        User.objects.create_user('fp', password='pw')
        self.client.login(username='fp', password='pw')

    def test_banner_and_button(self):
        data = _tar({'manage.py': b''})
        self.set_manifest(_manifest('2026.10.27.0900', data))
        self.assertContains(self.client.get('/tasks/'), '更新があります（2026.10.27.0900）')
        with mock.patch('config.updates._fetch', return_value=data), \
                mock.patch('config.updates.restart_app') as restart:
            res = self.client.post('/app/update/', {'next': '/tasks/'})
        self.assertContains(res, '開き直しています')
        restart.assert_called_once()

    def test_failed_install_keeps_current(self):
        data = _tar({'manage.py': b''})
        self.set_manifest(_manifest('2026.10.27.0900', data, sha256='0' * 64))
        with mock.patch('config.updates._fetch', return_value=data), \
                mock.patch('config.updates.restart_app') as restart:
            res = self.client.post('/app/update/', {'next': '//evil.example/'}, follow=True)
        restart.assert_not_called()
        self.assertContains(res, '更新できませんでした')
        self.assertEqual(res.redirect_chain[0][0], '/')

    def test_no_banner_without_update(self):
        self.assertNotContains(self.client.get('/tasks/'), '更新があります')


class LauncherFallbackTests(TestCase):
    """起動役：更新版で起動できなかったら前の版、それも無ければアプリ同梱の版に戻す"""
    def setUp(self):
        spec = importlib.util.spec_from_file_location('fpcrm_launcher', ROOT / 'packaging' / 'macos' / 'launcher.py')
        self.launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.launcher)
        self.tmp = tempfile.TemporaryDirectory()
        self.launcher.VERSIONS = Path(self.tmp.name)
        self.launcher.alert = lambda msg: None
        for v in ('A', 'B'):
            (self.launcher.VERSIONS / v).mkdir()
            (self.launcher.VERSIONS / v / 'manage.py').touch()

    def tearDown(self):
        self.tmp.cleanup()

    def choose(self):
        with mock.patch.object(self.launcher.threading, 'Thread'):
            return self.launcher.choose_code_dir()

    def test_new_version_is_tried_then_kept_when_ok(self):
        v = self.launcher.VERSIONS
        (v / 'current').write_text('B')
        self.assertEqual(self.choose()[1], 'B')     # 初めての版は試す
        (v / 'B' / '.ok').touch()
        self.assertEqual(self.choose()[1], 'B')     # 起動できた版は使い続ける

    def test_failed_version_falls_back_to_previous_then_bundled(self):
        v = self.launcher.VERSIONS
        (v / 'current').write_text('B')
        (v / 'previous').write_text('A')
        (v / 'A' / '.ok').touch()
        (v / 'B' / '.tried').touch()                # 前回Bで起動できなかった
        self.assertEqual(self.choose()[1], 'A')
        self.assertEqual((v / 'current').read_text(), 'A')
        (v / 'A' / '.ok').unlink()
        (v / 'A' / '.tried').touch()
        code_dir, version = self.choose()
        self.assertIsNone(version)
        self.assertEqual(code_dir, self.launcher.BUNDLED_CODE)
        self.assertFalse((v / 'current').exists())
