from django import forms
from .models import SystemSettings


class SystemSettingsForm(forms.ModelForm):
    class Meta:
        model = SystemSettings
        fields = ['followup_threshold_days']
        help_texts = {
            'monthly_ac_target': '今月のAC（年間手数料）目標金額を入力してください',
            'monthly_interview_target': '今月の面談数目標件数を入力してください',
            'followup_threshold_days': '指定した日数以上、面談がない顧客をダッシュボードの「フォロー漏れ」に表示します',
        }
