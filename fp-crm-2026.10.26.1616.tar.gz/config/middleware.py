from django.conf import settings
from django.http import Http404, JsonResponse
from django.shortcuts import redirect

# 個人用機能（settings.PERSONAL_FEATURES がオフの時は404にするパス）
PERSONAL_PREFIXES = (
    "/api/",                    # DONNA（Claude Code）からの読み書きAPI・LINE返信の計画API
    "/interviews/drafts/",      # 面談ドラフト（AI下書き→承認）
    "/followup-suggestions/",   # 送信トレイ（LINE下書き）
    "/briefings/",              # 夜の報告の履歴
    "/briefing/snapshot/",      # 夜の報告（クラウド側）用
    "/line/webhook/",           # DONNAのLINE Webhook
)


class PersonalFeaturesMiddleware:
    """外販版（PERSONAL_FEATURES=オフ）では個人用機能のURLを存在しないものとして扱う。"""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not settings.PERSONAL_FEATURES and request.path.startswith(PERSONAL_PREFIXES):
            raise Http404
        return self.get_response(request)

# 未ログインでもアクセスを許可するパス
EXEMPT_PREFIXES = (
    "/accounts/login",
    "/accounts/password_reset",  # 再設定の申請・送信完了
    "/accounts/reset",           # メール内リンクからの再設定
    "/static/",
    "/media/",
    "/line/webhook/",           # LINEからのWebhook（署名で認証）
    "/briefing/snapshot/",      # 夜の報告（クラウド側）用。専用の読み取りトークンで認証
    "/setup/",                  # 初回の設定（ログインが1つも無い時だけ開ける）
)


class LoginRequiredMiddleware:
    """全ページをログイン必須にする。/api/ はAPIトークン（X-API-Token）でも許可。"""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path
        if request.user.is_authenticated or path.startswith(EXEMPT_PREFIXES):
            return self.get_response(request)

        if "/api/" in path:
            token = request.headers.get("X-API-Token", "")
            if settings.API_TOKEN and token == settings.API_TOKEN:
                return self.get_response(request)
            return JsonResponse({"error": "認証が必要です（X-API-Tokenヘッダー）"}, status=401)

        from config.setup import needs_setup
        if needs_setup():
            return redirect("/setup/")
        return redirect(f"{settings.LOGIN_URL}?next={path}")
