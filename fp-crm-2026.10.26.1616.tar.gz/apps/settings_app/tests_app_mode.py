"""初回の設定（ログイン作成）・自動バックアップ・アプリの終了のテスト。"""
import datetime
import tempfile
from pathlib import Path
from unittest import mock

from django.conf import settings
from django.contrib.auth.models import User
from django.test import TestCase, override_settings

from config import backup


class FirstRunSetupTests(TestCase):
    def test_redirects_to_setup_when_no_user(self):
        self.assertRedirects(self.client.get('/customers/'), '/setup/', fetch_redirect_response=False)
        self.assertContains(self.client.get('/setup/'), 'はじめての設定')

    def test_mismatched_or_weak_password_is_rejected(self):
        self.client.post('/setup/', {'username': 'fp', 'password1': 'Sakura-2026-ok', 'password2': 'Sakura-2026-ng'})
        self.client.post('/setup/', {'username': 'fp', 'password1': '1234', 'password2': '1234'})
        self.assertFalse(User.objects.exists())

    def test_creates_login_and_signs_in(self):
        res = self.client.post('/setup/', {'username': 'fp', 'password1': 'Sakura-2026-ok', 'password2': 'Sakura-2026-ok'})
        self.assertRedirects(res, '/', fetch_redirect_response=False)
        self.assertTrue(User.objects.get(username='fp').is_superuser)
        self.assertEqual(self.client.get('/customers/').status_code, 200)

    def test_setup_is_closed_once_a_user_exists(self):
        User.objects.create_user('someone', password='x')
        self.assertRedirects(self.client.get('/setup/'), '/accounts/login/', fetch_redirect_response=False)
        self.client.post('/setup/', {'username': 'intruder', 'password1': 'Sakura-2026-ok', 'password2': 'Sakura-2026-ok'})
        self.assertFalse(User.objects.filter(username='intruder').exists())
        self.assertRedirects(self.client.get('/customers/'), '/accounts/login/?next=/customers/', fetch_redirect_response=False)


class BackupTests(TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        (root / 'media' / 'docs').mkdir(parents=True)
        (root / 'media' / 'docs' / 'a.pdf').write_bytes(b'%PDF')
        db = root / 'src.sqlite3'
        import sqlite3
        con = sqlite3.connect(db)
        con.execute('create table t (x)')
        con.execute('insert into t values (1)')
        con.commit()
        con.close()
        self.override = override_settings(
            DATA_DIR=root, MEDIA_ROOT=root / 'media',
            DATABASES={**settings.DATABASES, 'default': {**settings.DATABASES['default'], 'NAME': db}})
        self.override.enable()
        self.root = root

    def tearDown(self):
        self.override.disable()
        self.tmp.cleanup()

    def test_daily_backup_copies_db_and_media_once_a_day(self):
        day = datetime.date(2026, 10, 26)
        dest = backup.run_backup(today=day)
        self.assertTrue((dest / 'db.sqlite3').exists())
        self.assertTrue((dest / 'media' / 'docs' / 'a.pdf').exists())
        self.assertIsNone(backup.run_backup(today=day))           # 同じ日は取らない
        self.assertIsNotNone(backup.run_backup(force=True, today=day))

    def test_keeps_30_days(self):
        start = datetime.date(2026, 9, 1)
        for i in range(32):
            (self.root / 'backups' / (start + datetime.timedelta(days=i)).isoformat()).mkdir(parents=True)
        (self.root / 'backups' / 'メモ').mkdir()
        backup.prune()
        names = [p.name for p in backup.list_backups()]
        self.assertEqual(len(names), 30)
        self.assertEqual(names[-1], '2026-09-03')
        self.assertTrue((self.root / 'backups' / 'メモ').exists())   # 日付以外は触らない


class AppModeTests(TestCase):
    def setUp(self):
        User.objects.create_user('fp', password='pw')
        self.client.login(username='fp', password='pw')

    def test_hidden_when_not_app(self):
        self.assertNotContains(self.client.get('/settings/'), 'バックアップと終了')
        self.assertEqual(self.client.post('/app/quit/').status_code, 404)
        self.assertEqual(self.client.post('/settings/backup/').status_code, 404)

    @override_settings(SERVE_FILES=True)
    def test_section_and_quit_in_app(self):
        self.assertContains(self.client.get('/settings/'), 'バックアップと終了')
        with mock.patch('config.setup.threading.Timer') as timer:
            res = self.client.post('/app/quit/')
        self.assertContains(res, '終了しました')
        timer.assert_called_once()
